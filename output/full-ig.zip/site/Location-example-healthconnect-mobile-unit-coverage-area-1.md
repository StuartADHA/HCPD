# HCPD Location Example: Mobile Unit Service Coverage Area - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Location Example: Mobile Unit Service Coverage Area**

## Example Location: HCPD Location Example: Mobile Unit Service Coverage Area

Last updated: 2025-09-01 14:45:30+0000

Profile: [HCPD Location](StructureDefinition-hcpd-location.md)

Sydney CBD Mobile Unit Service Area (Virtual) (LSPN: 876543)

-------

| | |
| :--- | :--- |
| Status: | Inactive |
| Description: | Coverage area served by the Sydney CBD Mobile Healthcare Unit, encompassing the central business district and surrounding areas. |
| Type: | Virtual |
| Contact Detail | * ph: (02) 1234 5678(Work)
* [info@sydneycentralmc.com.au](mailto:info@sydneycentralmc.com.au)
 |
| Managed By: | [null (National Organisation Identifier: 8003626566707032)](Organization-example-healthconnect-organization-1.md) |
| Part Of: | [Mobile Healthcare Unit - Sydney CBD (Mobile Unit, Community Location) (NATA Site Number: Australian National Association of Testing Authorities (NATA) Site Number#162899)](Location-example-healthconnect-mobile-healthcare-unit-1.md) |
| Other Ids: | * Organization identifier/8df1a0cf-f7aa-4306-98f1-115653885d78
* Resource Identifier/hcpd-SI-4244
 |
| Suppression Indicator for Visibility: | * suppressedBy: Organisation initiated
 |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "example-healthconnect-mobile-unit-coverage-area-1",
  "meta" : {
    "lastUpdated" : "2025-09-01T14:45:30Z",
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location"]
  },
  "extension" : [{
    "extension" : [{
      "url" : "suppressedBy",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
          "code" : "organisation-initiated"
        }]
      }
    }],
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed"
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org.au/CodeSystem/v2-0203",
        "code" : "LSPN",
        "display" : "Location Specific Practice Number"
      }],
      "text" : "LSPN"
    },
    "system" : "http://ns.electronichealth.net.au/id/location-specific-practice-number",
    "value" : "876543"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "XX",
        "display" : "Organization identifier"
      }]
    },
    "system" : "http://digitalhealth.gov.au/fhir/hcpd/id/hcpd-local-identifier",
    "value" : "8df1a0cf-f7aa-4306-98f1-115653885d78"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "RI",
        "display" : "Resource Identifier"
      }]
    },
    "system" : "http://example.org/fhir/identifier/location",
    "value" : "hcpd-SI-4244"
  }],
  "status" : "inactive",
  "name" : "Sydney CBD Mobile Unit Service Area",
  "description" : "Coverage area served by the Sydney CBD Mobile Healthcare Unit, encompassing the central business district and surrounding areas.",
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org.au/CodeSystem/location-type",
      "code" : "VI",
      "display" : "Virtual"
    }]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "(02) 1234 5678",
    "use" : "work"
  },
  {
    "system" : "email",
    "value" : "info@sydneycentralmc.com.au",
    "use" : "work"
  }],
  "managingOrganization" : {
    "reference" : "Organization/example-healthconnect-organization-1"
  },
  "partOf" : {
    "reference" : "Location/example-healthconnect-mobile-healthcare-unit-1"
  }
}

```
