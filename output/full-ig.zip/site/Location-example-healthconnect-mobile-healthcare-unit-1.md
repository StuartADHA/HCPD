# HCPD Location Example: Mobile Healthcare Unit - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Location Example: Mobile Healthcare Unit**

## Example Location: HCPD Location Example: Mobile Healthcare Unit

Last updated: 2025-09-01 14:45:30+0000

Profile: [HCPD Location](StructureDefinition-hcpd-location.md)

Mobile Healthcare Unit - Sydney CBD (Mobile Unit, Community Location) (NATA Site Number: Australian National Association of Testing Authorities (NATA) Site Number#162899)

-------

| | |
| :--- | :--- |
| Status: | Active |
| Alias: | CBD Mobile Unit |
| Type: | * Mobile Unit
* Community Location
 |
| Address: | Shop 8, 151 Castlereagh Street, SYDNEY NSW 2000 |
| Contact Detail | * ph: (02) 1234 5678(Work)
* [info@sydneycentralmc.com.au](mailto:info@sydneycentralmc.com.au)
* [https://www.example.com/sydneycentralmc](https://www.example.com/sydneycentralmc)
* fax: +61 2 9999 8888(Work)
 |
| Position: | -33.8688, 151.2093 |
| Managed By: | [null (National Organisation Identifier: 8003626566707032)](Organization-example-healthconnect-organization-1.md) |
| Other Ids: | * LSPN/123333
* Organization identifier/26ff4c29-692f-45c7-8df7-99cf6b5a8c09
* Resource Identifier/hcpd-SI-4243
 |
| [Amenity](StructureDefinition-amenity.md) | Wheelchair Access |
| [HCPD Alternate Postal Address](StructureDefinition-hcpd-alternate-postal-address.md) | PO Box 123, SYDNEY NSW 2000(work) |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "example-healthconnect-mobile-healthcare-unit-1",
  "meta" : {
    "lastUpdated" : "2025-09-01T14:45:30Z",
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location"]
  },
  "extension" : [{
    "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-alternate-postal-address",
    "valueAddress" : {
      "use" : "work",
      "type" : "postal",
      "text" : "PO Box 123, SYDNEY NSW 2000",
      "line" : ["PO Box 123"],
      "city" : "SYDNEY",
      "state" : "NSW",
      "postalCode" : "2000",
      "country" : "AU"
    }
  },
  {
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/amenity",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://healthterminologies.gov.au/fhir/CodeSystem/facility-amenity-1",
        "code" : "wheelchairAccess",
        "display" : "Wheelchair Access"
      }]
    }
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org.au/CodeSystem/v2-0203",
        "code" : "NATAS",
        "display" : "NATA Site Number"
      }],
      "text" : "NATA Site Number"
    },
    "system" : "http://hl7.org.au/id/nata-site",
    "value" : "162899"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org.au/CodeSystem/v2-0203",
        "code" : "LSPN",
        "display" : "Location Specific Practice Number"
      }],
      "text" : "LSPN"
    },
    "system" : "http://ns.electronichealth.net.au/id/location-specific-practice-number",
    "value" : "123333"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "XX",
        "display" : "Organization identifier"
      }]
    },
    "system" : "http://digitalhealth.gov.au/fhir/hcpd/id/hcpd-local-identifier",
    "value" : "26ff4c29-692f-45c7-8df7-99cf6b5a8c09"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "RI",
        "display" : "Resource Identifier"
      }]
    },
    "system" : "http://example.org/fhir/identifier/location",
    "value" : "hcpd-SI-4243"
  }],
  "status" : "active",
  "name" : "Mobile Healthcare Unit - Sydney CBD",
  "alias" : ["CBD Mobile Unit"],
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
      "code" : "MOBL",
      "display" : "Mobile Unit"
    }]
  },
  {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
      "code" : "COMM",
      "display" : "Community Location"
    }]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "(02) 1234 5678",
    "use" : "work"
  },
  {
    "system" : "email",
    "value" : "info@sydneycentralmc.com.au",
    "use" : "work"
  },
  {
    "system" : "url",
    "value" : "https://www.example.com/sydneycentralmc",
    "use" : "work"
  },
  {
    "system" : "fax",
    "value" : "+61 2 9999 8888",
    "use" : "work"
  }],
  "address" : {
    "extension" : [{
      "url" : "http://hl7.org.au/fhir/StructureDefinition/address-identifier",
      "valueIdentifier" : {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org.au/CodeSystem/v2-0203",
            "code" : "GNAF",
            "display" : "Geocoded National Address File Identifier"
          }],
          "text" : "G-NAF"
        },
        "system" : "http://hl7.org.au/id/gnafidentifier",
        "value" : "GANSW718473771"
      }
    }],
    "type" : "physical",
    "text" : "Shop 8, 151 Castlereagh Street, SYDNEY NSW 2000",
    "line" : ["Shop 8", "147-153 Castlereagh Street"],
    "city" : "SYDNEY",
    "state" : "NSW",
    "postalCode" : "2000",
    "country" : "AU"
  },
  "position" : {
    "longitude" : 151.2093,
    "latitude" : -33.8688
  },
  "managingOrganization" : {
    "reference" : "Organization/example-healthconnect-organization-1"
  }
}

```
