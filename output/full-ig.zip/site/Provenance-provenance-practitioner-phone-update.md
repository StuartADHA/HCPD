# HCPD Provenance Example: Practitioner Phone Amendment - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Provenance Example: Practitioner Phone Amendment**

## Example Provenance: HCPD Provenance Example: Practitioner Phone Amendment

Profile: [HCPD Provenance](StructureDefinition-hcpd-provenance.md)

Provenance for [Alex Smith (National provider identifier: 8003619900015717)](Practitioner-example-healthconnect-practitioner-1.md)

Summary

| | |
| :--- | :--- |
| Recorded | 2025-09-15 14:30:15+1000 |
| Activity | revise |

**Agents**

* **Type**: Author
  * **Role**: Amender
  * **who**: [null (National Organisation Identifier: 8003626566707032)](Organization-example-healthconnect-organization-1.md)

**Entities**

* **Role**: Source
  * **What**: [John Fryer (National provider identifier: 8003616566719020)](Practitioner-external-hcpd-practitioner-record.md)

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "Provenance",
  "id" : "provenance-practitioner-phone-update",
  "meta" : {
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-provenance"]
  },
  "target" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/targetPath",
      "valueString" : "telecom.where(system='phone').value"
    }],
    "reference" : "Practitioner/example-healthconnect-practitioner-1"
  }],
  "recorded" : "2025-09-15T14:30:15.123+10:00",
  "activity" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
      "code" : "UPDATE"
    }]
  },
  "agent" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
        "code" : "author"
      }]
    },
    "role" : [{
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/contractsignertypecodes",
        "code" : "AMENDER"
      }]
    }],
    "who" : {
      "reference" : "Organization/example-healthconnect-organization-1"
    }
  }],
  "entity" : [{
    "role" : "source",
    "what" : {
      "reference" : "Practitioner/external-hcpd-practitioner-record"
    }
  }]
}

```
