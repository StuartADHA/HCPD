# HCPD HealthcareService Example: Residential Aged Care - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD HealthcareService Example: Residential Aged Care**

## Example HealthcareService: HCPD HealthcareService Example: Residential Aged Care

Last updated: 2025-09-02 18:00:00+0000

Profile: [HCPD HealthcareService](StructureDefinition-hcpd-healthcareservice.md)

Healthcare service with Residential Aged Care service type (Geriatric evaluation and management service) by null (National Organisation Identifier: 8003626566707032) (Resource identifier: HS-PCA-001234)

-------

| | | | |
| :--- | :--- | :--- | :--- |
| Active: | true | Appointment Required: | true |
| Provided By: | [null (National Organisation Identifier: 8003626566707032)](Organization-example-healthconnect-organization-1.md) | | |
| Type: | Geriatric evaluation and management service | | |
| Location: | [Sydney Central Medical Centre (NATA Site Number: Australian National Association of Testing Authorities (NATA) Site Number#165432)](Location-example-healthconnect-medical-centre-location-1.md) | | |
| Coverage Area: | [Sydney CBD Mobile Unit Service Area (Virtual) (LSPN: 876543)](Location-example-healthconnect-mobile-unit-coverage-area-1.md) | | |
| Provision Conditions: | * Fees Apply
* No Fee
 | | |
| Eligibility: | Older adult 65+ years | | |
| Languages: | * Italian
* Chinese
 | | |
| Other Id: | Organization identifier/17fbd35e-ca2f-43a6-8ffc-9f0f95e65b4e | | |
| Contact Detail | ph: (02) 1234 5678(Work) | | |
| Availability: | * Monday, Tuesday, Wednesday, Thursday, Friday: 08:00:00 - 17:30:00
 | | |
| Endpoint: | [Sydney General Hospital FHIR Messaging Endpoint (HL7 FHIR Messaging (Endpoint Connection Type#hl7-fhir-msg)): https://example.org/smd-sydneyhospital/secure-messaging/endpoint](Endpoint-example-hcpd-endpoint-hl7-fhir-messaging.md) | | |
| [Referral Information for Referrer](StructureDefinition-referral-information-for-referrer.md) | **Referral required** from a GP or specialist.Please include:* Recent medical history
* Current medications
Referrals can be faxed to **(02) 1234 5679**. | | |
| [New Patient Availability](StructureDefinition-new-patient-availability.md) | Accepting new patients | | |
| [IAR Levels of Care](StructureDefinition-iar-levels-of-care.md) | Level 3 - Moderate intensity services | | |
| [Active Period](StructureDefinition-active-period.md) | 2022-01-01 --> 2025-12-31 | | |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "HealthcareService",
  "id" : "example-healthconnect-healthcareservice-1",
  "meta" : {
    "lastUpdated" : "2025-09-02T18:00:00Z",
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-healthcareservice"]
  },
  "extension" : [{
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/active-period",
    "valuePeriod" : {
      "start" : "2022-01-01",
      "end" : "2025-12-31"
    }
  },
  {
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/referral-information-for-referrer",
    "valueMarkdown" : "**Referral required** from a GP or specialist.\n\nPlease include:\n- Recent medical history\n- Current medications\n\nReferrals can be faxed to **(02) 1234 5679**."
  },
  {
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/iar-levels-of-care",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://healthterminologies.gov.au/fhir/CodeSystem/iar-levels-of-care-1",
        "code" : "level3",
        "display" : "Level 3 - Moderate intensity services"
      }]
    }
  },
  {
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/new-patient-availability",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://healthterminologies.gov.au/fhir/CodeSystem/new-patient-availability-1",
        "code" : "accepting",
        "display" : "Accepting new patients"
      }]
    }
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "RI"
      }]
    },
    "system" : "http://ns.electronichealth.net.au/id/source/pca",
    "value" : "HS-PCA-001234"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "XX",
        "display" : "Organization identifier"
      }]
    },
    "system" : "http://digitalhealth.gov.au/fhir/hcpd/id/hcpd-local-identifier",
    "value" : "17fbd35e-ca2f-43a6-8ffc-9f0f95e65b4e"
  }],
  "active" : true,
  "providedBy" : {
    "reference" : "Organization/example-healthconnect-organization-1"
  },
  "type" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "1584801000168109",
      "display" : "Geriatric evaluation and management service"
    }]
  }],
  "location" : [{
    "reference" : "Location/example-healthconnect-medical-centre-location-1"
  }],
  "name" : "Healthcare service with Residential Aged Care service type",
  "telecom" : [{
    "extension" : [{
      "url" : "http://hl7.org.au/fhir/StructureDefinition/contact-purpose",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/contactentity-type",
          "code" : "ADMIN",
          "display" : "Administrative"
        }]
      }
    }],
    "system" : "phone",
    "value" : "(02) 1234 5678",
    "use" : "work"
  }],
  "coverageArea" : [{
    "reference" : "Location/example-healthconnect-mobile-unit-coverage-area-1"
  }],
  "serviceProvisionCode" : [{
    "coding" : [{
      "system" : "http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/service-provision-cs",
      "code" : "FAP",
      "display" : "Fees Apply"
    }]
  },
  {
    "coding" : [{
      "system" : "http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/service-provision-cs",
      "code" : "NFE",
      "display" : "No Fee"
    }]
  }],
  "eligibility" : [{
    "code" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "933451001000036104",
        "display" : "Older adult 65+ years"
      }]
    }
  }],
  "communication" : [{
    "coding" : [{
      "system" : "urn:ietf:bcp:47",
      "code" : "it",
      "display" : "Italian"
    }]
  },
  {
    "coding" : [{
      "system" : "urn:ietf:bcp:47",
      "code" : "zh",
      "display" : "Chinese"
    }]
  }],
  "appointmentRequired" : true,
  "availableTime" : [{
    "daysOfWeek" : ["mon", "tue", "wed", "thu", "fri"],
    "allDay" : false,
    "availableStartTime" : "08:00:00",
    "_availableStartTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    },
    "availableEndTime" : "17:30:00",
    "_availableEndTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    }
  }],
  "endpoint" : [{
    "reference" : "Endpoint/example-hcpd-endpoint-hl7-fhir-messaging"
  }]
}

```
