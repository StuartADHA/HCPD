# Deactivated - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **Deactivated**

## Extension: Deactivated 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/deactivated | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:Deactivated |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

Identifies the party responsible for setting the parent resource to an inactive or suspended state. This extension is expected to be present whenever the resource's active or status element indicates it is no longer active, and provides audit metadata about the actor who initiated the change.

Captures who initiated a status or active-flag change on a Health Connect Provider Directory resource, enabling audit traceability and supporting cascade deactivation management across the provider directory hierarchy.

**Context of Use**

## Usage notes

This extension indicates whether a Health Connect Provider Directory resource has been deactivated and identifies the party responsible for initiating the status change. It carries coded information about the actor who initiated the deactivation and is applied to the `active` element (Organization, Practitioner, PractitionerRole, HealthcareService) or the `status` element (Location, Endpoint). This extension is expected to be present whenever that element indicates the resource is no longer active.

### Datatype and context

The DeactivatedBy extension is a simple extension with a single required CodeableConcept value. It is applied directly to the `active` or `status` element of the relevant HCPD resource profiles. The coded value is drawn from the [Responsible Party Type CodeSystem](http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type).

This extension is profiled on the following HCPD resource elements with fixed values:

* `Organization` — organisation-initiated only
* `Practitioner` — practitioner-initiated only
* `PractitionerRole` — either code permitted
* `HealthcareService` — organisation-initiated only
* `Location` — organisation-initiated only
* `Endpoint` — organisation-initiated only

### Deactivation scenarios

1. **Practitioner self-deactivation**:
* Practitioner sets their own `active = false`, carrying `practitioner-initiated` in DeactivatedBy
* This cascades to deactivate all their associated PractitionerRole resources

1. **Organisation-initiated deactivation**:
* An organisation administrator sets `active = false` (or `status` to a non-active value) on any of their resources, carrying `organisation-initiated` in DeactivatedBy
* When applied to an Organization, deactivation automatically cascades to all child HealthcareService, Location, PractitionerRole, and Endpoint resources

1. **PractitionerRole deactivation**:
* A PractitionerRole may be deactivated by either party; the code indicates which actor initiated the change without affecting the referenced Practitioner

### Relationship to the Suppressed extension

Both DeactivatedBy and the Suppressed extension follow the same cascade hierarchy. The key distinction is:

| | | |
| :--- | :--- | :--- |
| **Purpose** | Hides the resource from directory display while keeping it active in the system | Records who changed the`active`/`status`element to a non-active state |
| **Applied to** | The resource root | The`active`or`status`element directly |
| **Resource remains active?** | Yes — suppression is a visibility flag only | No — the resource is genuinely inactive |

### Cascade hierarchy

The deactivation cascade follows the same organisational hierarchy as suppression:

| | | |
| :--- | :--- | :--- |
| Organization | ✓ | ✗ |
| HealthcareService | ✓ | ✗ |
| Location | ✓ | ✗ |
| Endpoint | ✓ | ✗ |
| PractitionerRole | ✓ | ✓ |
| Practitioner | ✗ | ✓ |

**Usage info**

**Usages:**

* Use this Extension: [HCPD Endpoint](StructureDefinition-hcpd-endpoint.md), [HCPD HealthcareService](StructureDefinition-hcpd-healthcareservice.md), [HCPD Location](StructureDefinition-hcpd-location.md), [HCPD Organization](StructureDefinition-hcpd-organization.md)... Show 3 more, [HCPD Practitioner](StructureDefinition-hcpd-practitioner.md), [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md) and [HCPD Service Coverage Area](StructureDefinition-hcpd-service-coverage-area.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/au.gov.digitalhealth.fhir.hcpd|current/StructureDefinition/StructureDefinition-deactivated.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-deactivated.csv), [Excel](StructureDefinition-deactivated.xlsx), [Schematron](StructureDefinition-deactivated.sch) 

#### Terminology Bindings

#### Constraints

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "deactivated",
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/deactivated",
  "version" : "26.0.0",
  "name" : "Deactivated",
  "title" : "Deactivated",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "Identifies the party responsible for setting the parent resource to an inactive or suspended state. This extension is expected to be present whenever the resource's active or status element indicates it is no longer active, and provides audit metadata about the actor who initiated the change.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "purpose" : "Captures who initiated a status or active-flag change on a Health Connect Provider Directory resource, enabling audit traceability and supporting cascade deactivation management across the provider directory hierarchy.",
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Organization"
  },
  {
    "type" : "element",
    "expression" : "Practitioner"
  },
  {
    "type" : "element",
    "expression" : "PractitionerRole"
  },
  {
    "type" : "element",
    "expression" : "HealthcareService"
  },
  {
    "type" : "element",
    "expression" : "Location"
  },
  {
    "type" : "element",
    "expression" : "Endpoint"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Who initiated deactivation",
      "definition" : "When present on a resource, identifies the party responsible for setting the resource to inactive or suspended state. Uses the same coded values as the Suppressed extension to indicate whether a practitioner or an organisation administrator initiated the change.",
      "max" : "1"
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "min" : 1
    },
    {
      "id" : "Extension.extension:deactivatedBy",
      "path" : "Extension.extension",
      "sliceName" : "deactivatedBy",
      "short" : "Who initiated the deactivation",
      "definition" : "Identifies the actor who initiated the deactivation request (e.g., practitioner, organisation).",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Extension.extension:deactivatedBy.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:deactivatedBy.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "deactivatedBy"
    },
    {
      "id" : "Extension.extension:deactivatedBy.value[x]",
      "path" : "Extension.extension.value[x]",
      "min" : 1,
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Extension.extension:deactivatedBy.value[x].coding",
      "path" : "Extension.extension.value[x].coding",
      "min" : 1,
      "max" : "2",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://digitalhealth.gov.au/fhir/cc/ValueSet/responsible-party-type|26.0.0"
      }
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/deactivated"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "max" : "0"
    }]
  }
}

```
