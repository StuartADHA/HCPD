# Resource bulk-export-requester-actor-health-connect



## Resource Content

```json
{
  "resourceType" : "Basic",
  "id" : "bulk-export-requester-actor-health-connect",
  "extension" : [{
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.url",
    "valueUri" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.version",
    "valueString" : "26.0.0"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.name",
    "valueString" : "HealthConnectProviderDirectoryBulkExportRequesterActorHealthConnect"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.title",
    "valueString" : "Health Connect Provider Directory Bulk Export Requester Actor"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.status",
    "valueCode" : "active"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.experimental",
    "valueBoolean" : false
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.date",
    "valueDateTime" : "2026-10-19T13:36:04+10:00"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.publisher",
    "valueString" : "Australian Digital Health Agency"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.contact",
    "valueContactDetail" : {
      "name" : "Australian Digital Health Agency",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.digitalhealth.gov.au/"
      },
      {
        "system" : "email",
        "value" : "help@digitalhealth.gov.au"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.contact",
    "valueContactDetail" : {
      "name" : "Australian Digital Health Agency",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.digitalhealth.gov.au",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "mailto:help@digitalhealth.gov.au",
        "use" : "work"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.description",
    "valueMarkdown" : "The Health Connect Provider Directory Bulk Export Requester actor represents a system that initiates **bulk data export requests** from the Health Connect Provider Directory system. This actor is responsible for submitting properly formatted export parameters and processing the returned bulk data files."
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.jurisdiction",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "urn:iso:std:iso:3166",
        "code" : "AU",
        "display" : "Australia"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.copyright",
    "valueMarkdown" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.type",
    "valueCode" : "system"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.documentation",
    "valueMarkdown" : "- **SHALL** implement the [mandatory](conformance.html) requirements for the elements defined as such in this implementation guide.\n- **SHALL** implement the required bulk export operations and parameter handling as defined in the Health Connect Provider Directory Bulk Export Requester Capability Statement.\n- **SHALL** be able to retrieve Binary resources containing the exported bulk data files returned by the export operation.\n- **SHALL** respect the `suppressed` and `deactivated-by` extensions on returned resources, filtering these resources before displaying them to end consumers of the HCPD."
  }],
  "code" : {
    "coding" : [{
      "system" : "http://hl7.org/fhir/fhir-types",
      "code" : "ActorDefinition"
    }]
  }
}

```
