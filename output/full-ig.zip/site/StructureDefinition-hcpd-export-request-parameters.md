# HCPD Export Request Parameters - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Export Request Parameters**

## Resource Profile: HCPD Export Request Parameters 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-export-request-parameters | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:HCPD_Export_Request_Parameters |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

 
Defines a profile of a Parameters resource used to make bulk data export requests. It contains the standard FHIR bulk export parameters including _type, _typeFilter, _outputFormat, and _since for controlling the export scope and format. 

 
This profile addresses the business requirement for structured bulk data export requests to the Health Connect Provider Directory, ensuring consistent parameter usage across different export scenarios. 

## Scope

This section describes the structure and intended use for a HCPD Export Request Parameters resource. This resource is used **ONLY** within the context of the [Bulk Data Extract](bulk-data-extraction.md) capability of the HCPD system for submitting export requests. It contains the parameters that control the scope, format, and filtering of bulk data export operations.

The HCPD Export Request Parameters resource is used by [Client Requester Actors](ActorDefinition-requester-actor-health-connect.md) to specify their bulk data export requirements. This profile ensures consistent parameter usage across different export scenarios including geographical filtering, organization-centric extraction, and healthcare service type-centric extraction.

## Usage notes

The HCPD Export Request Parameters resource contains standard FHIR bulk export parameters that control the export operation. This profile enforces proper parameter usage and ensures that type and typeFilter parameters are synchronized.

### Standard FHIR Bulk Export parameters

* `_type` - Comma-separated list of resource types to include (Organization,Location,Practitioner,PractitionerRole,HealthcareService,Endpoint,Provenance)
* `_since` - Only resources updated since specified timestamp (ISO 8601 format)
* `_typeFilter` - Apply export criteria to specific resource types (e.g., `Location?address-state=NSW`)
* `_outputFormat` - Output format (mandatory, fixed to application/fhir+ndjson)

### Parameter synchronization

The profile includes invariant `hcpd-exp-1` which enforces that the number of `_typeFilter` parameters **SHALL** equal the number of resource types specified in the comma-separated `_type` parameter. This ensures that each resource type has a corresponding filter, maintaining consistent export behavior.

### Supported export scenarios

Based on the parameter combinations, the following export scenarios are supported:

#### Geographical filtering

* **State-based**: _typeFilter=Location?address-state=[STATE]
* **Postcode-based**: _typeFilter=Location?address-postalcode=[POSTCODE]
*  

| | | |
| :--- | :--- | :--- |
| **Proximity-based**: _typeFilter=Location?near=[LAT] | [LNG] | [DISTANCE] |

 
* **City/suburb**: _typeFilter=Location?address-city=[CITY]

#### Organization-centric extraction

*  

| | |
| :--- | :--- |
| **HPI-O identifier**: _typeFilter=Organization?identifier=http://ns.electronichealth.net.au/id/hi/hpio/1.0 | [HPIO] |

 
*  

| | |
| :--- | :--- |
| **ABN identifier**: _typeFilter=Organization?identifier=http://hl7.org.au/id/abn | [ABN] |

 
*  

| | |
| :--- | :--- |
| **ACN identifier**: _typeFilter=Organization?identifier=http://hl7.org.au/id/acn | [ACN] |

 
* **Organization name**: _typeFilter=Organization?name=[NAME]

#### Healthcare service type-centric extraction

*  

| | |
| :--- | :--- |
| **SNOMED-CT service types**: _typeFilter=HealthcareService?service-type=[SYSTEM] | [CODE] |

 

### Implementation requirements

Client Requester Actors **SHALL** use this profile structure when submitting bulk export requests to ensure consistent parameter formatting and validation. When using `_type` and `_typeFilter` parameters, the number of filter parameters **MUST** equal the number of resource types specified (enforced by invariant hcpd-exp-1).

### Parameter reference

| | | | |
| :--- | :--- | :--- | :--- |
| _outputFormat | 1..1 | string | Fixed to "application/fhir+ndjson" |
| _type | 1..* | string | Comma-separated resource types: Organization,Location,HealthcareService,Practitioner,PractitionerRole,Endpoint,Provenance |
| _typeFilter | 1..* | string | FHIR search parameters for filtering specific resource types (one entry per _type value) |
| _since | 0..1 | instant | ISO 8601 timestamp - only export resources updated since this date |

**Usages:**

* Examples for this Profile: [Parameters/example-hcpd-export-request-parameters-1](Parameters-example-hcpd-export-request-parameters-1.md) and [Parameters/example-hcpd-export-request-parameters-2](Parameters-example-hcpd-export-request-parameters-2.md)
* CapabilityStatements using this Profile: [Health Connect Provider Directory Bulk Export Requester](CapabilityStatement-health-connect-bulk-export-requester.md) and [Health Connect Provider Directory Responder](CapabilityStatement-health-connect-provider-directory-responder.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/au.gov.digitalhealth.fhir.hcpd|current/StructureDefinition/StructureDefinition-hcpd-export-request-parameters.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-hcpd-export-request-parameters.csv), [Excel](StructureDefinition-hcpd-export-request-parameters.xlsx), [Schematron](StructureDefinition-hcpd-export-request-parameters.sch) 

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "hcpd-export-request-parameters",
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-export-request-parameters",
  "version" : "26.0.0",
  "name" : "HCPD_Export_Request_Parameters",
  "title" : "HCPD Export Request Parameters",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "Defines a profile of a Parameters resource used to make bulk data export requests. It contains the standard FHIR bulk export parameters including _type, _typeFilter, _outputFormat, and _since for controlling the export scope and format.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "purpose" : "This profile addresses the business requirement for structured bulk data export requests to the Health Connect Provider Directory, ensuring consistent parameter usage across different export scenarios.",
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Parameters",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Parameters|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Parameters",
      "path" : "Parameters",
      "short" : "HCPD Bulk Export Request Parameters",
      "definition" : "Defines how a Parameters resource is represented for bulk data export requests within the HCPD system.",
      "constraint" : [{
        "key" : "hcpd-exp-1",
        "severity" : "error",
        "human" : "Number of _typeFilter parameters must equal the total number of resource types specified across all _type parameters",
        "expression" : "parameter.where(name='_typeFilter').count() = parameter.where(name='_type').valueString.select(split(',')).select($this.trim()).count()",
        "source" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-export-request-parameters|26.0.0"
      }]
    },
    {
      "id" : "Parameters.parameter",
      "path" : "Parameters.parameter",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "name"
        }],
        "description" : "Slice based on parameter name for different export control parameters",
        "rules" : "open"
      },
      "short" : "Export parameters to control bulk data extraction",
      "definition" : "Parameters that control the scope, format, and filtering of the bulk data export operation.",
      "min" : 3,
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:outputFormat",
      "path" : "Parameters.parameter",
      "sliceName" : "outputFormat",
      "short" : "Output format (fixed to application/fhir+ndjson)",
      "definition" : "Specifies the format of exported data files. Fixed to NDJSON format.",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:outputFormat.name",
      "path" : "Parameters.parameter.name",
      "fixedString" : "_outputFormat",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:outputFormat.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Parameters.parameter:outputFormat.value[x]:valueString",
      "path" : "Parameters.parameter.value[x]",
      "sliceName" : "valueString",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "fixedString" : "application/fhir+ndjson",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:type",
      "path" : "Parameters.parameter",
      "sliceName" : "type",
      "short" : "Resource types to include in export",
      "definition" : "Comma-separated list of resource types to include, or individual _type parameters for each resource type.",
      "min" : 1,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:type.name",
      "path" : "Parameters.parameter.name",
      "fixedString" : "_type",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:type.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Parameters.parameter:type.value[x]:valueString",
      "path" : "Parameters.parameter.value[x]",
      "sliceName" : "valueString",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:typeFilter",
      "path" : "Parameters.parameter",
      "sliceName" : "typeFilter",
      "short" : "Export criteria for specific resource types",
      "definition" : "Apply export criteria to specific resource types using FHIR search parameters. SHALL provide at least one _typeFilter for each resource type specified in _type parameters.",
      "min" : 1,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:typeFilter.name",
      "path" : "Parameters.parameter.name",
      "fixedString" : "_typeFilter",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:typeFilter.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Parameters.parameter:typeFilter.value[x]:valueString",
      "path" : "Parameters.parameter.value[x]",
      "sliceName" : "valueString",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:since",
      "path" : "Parameters.parameter",
      "sliceName" : "since",
      "short" : "Only resources updated since specified timestamp",
      "definition" : "Only resources updated since the specified timestamp (ISO 8601 format) will be included in the export.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:since.name",
      "path" : "Parameters.parameter.name",
      "fixedString" : "_since",
      "mustSupport" : true
    },
    {
      "id" : "Parameters.parameter:since.value[x]",
      "path" : "Parameters.parameter.value[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Parameters.parameter:since.value[x]:valueInstant",
      "path" : "Parameters.parameter.value[x]",
      "sliceName" : "valueInstant",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "instant"
      }],
      "mustSupport" : true
    }]
  }
}

```
