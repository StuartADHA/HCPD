# Sydney Private Clinic: FHIR Referral Endpoint - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **Sydney Private Clinic: FHIR Referral Endpoint**

## Example Endpoint: Sydney Private Clinic: FHIR Referral Endpoint

Information Source: [http://ns.electronichealth.net.au/id/source/pca](http://ns.electronichealth.net.au/id/source/pca)

Profile: [HCPD Endpoint](StructureDefinition-hcpd-endpoint.md)

Sydney Private Clinic – FHIR Referral Endpoint (HL7 FHIR (Endpoint Connection Type#hl7-fhir-rest)): https://fhir.sydneyprivateclinic.com.au/fhir

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | [https://fhir.sydneyprivateclinic.com.au/fhir](https://fhir.sydneyprivateclinic.com.au/fhir) |
| Connection Type: | [Endpoint Connection Type: hl7-fhir-rest](http://terminology.hl7.org/7.4.0/CodeSystem-endpoint-connection-type.html#endpoint-connection-type-hl7-fhir-rest)(HL7 FHIR) |
| Payload Type: | Any |
| Mime Type: | application/fhir+json |
| Contact Detail | [referrals@sydneyprivateclinic.com.au](mailto:referrals@sydneyprivateclinic.com.au) |
| Other Id: | Resource identifier/EP-NHSD-001234562501 |
| Suppression Indicator for Visibility: | * suppressedBy: Organisation initiated
 |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "example-hcpd-endpoint-referral",
  "meta" : {
    "source" : "http://ns.electronichealth.net.au/id/source/pca",
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-endpoint"]
  },
  "extension" : [{
    "extension" : [{
      "url" : "suppressedBy",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
          "code" : "organisation-initiated"
        }]
      }
    }],
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed"
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "XX"
      }]
    },
    "system" : "http://digitalhealth.gov.au/fhir/hcpd/id/hcpd-local-identifier",
    "value" : "e1000000-0000-4000-8000-000000000002"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "RI"
      }]
    },
    "system" : "http://ns.electronichealth.net.au/id/source/nhsd",
    "value" : "EP-NHSD-001234562501"
  }],
  "status" : "active",
  "connectionType" : {
    "system" : "http://terminology.hl7.org/CodeSystem/endpoint-connection-type",
    "code" : "hl7-fhir-rest",
    "display" : "HL7 FHIR"
  },
  "name" : "Sydney Private Clinic – FHIR Referral Endpoint",
  "contact" : [{
    "system" : "email",
    "value" : "referrals@sydneyprivateclinic.com.au",
    "use" : "work"
  }],
  "payloadType" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/endpoint-payload-type",
      "code" : "any",
      "display" : "Any"
    }]
  }],
  "payloadMimeType" : ["application/fhir+json"],
  "address" : "https://fhir.sydneyprivateclinic.com.au/fhir"
}

```
