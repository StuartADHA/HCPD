# HCPD Practitioner Example: Alice Anderson (Balmain) - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Practitioner Example: Alice Anderson (Balmain)**

## Example Practitioner: HCPD Practitioner Example: Alice Anderson (Balmain)

Last updated: 2026-09-10 00:00:00+0000

Profile: [HCPD Practitioner](StructureDefinition-hcpd-practitioner.md)

Alice Anderson (National provider identifier: 8003619900015717)

-------

| | |
| :--- | :--- |
| Alt. Name: | Alice Anderson (Official) |
| Qualification: | Medical Practitioner* Identifier: Australian Health Practitioner Regulation Agency Registration Number/MED0001111111
* Issued By: Ahpra
 |
| Suppression Indicator for Visibility: | * suppressedBy: Practitioner initiated
 |
| Person Recorded Sex Or Gender: | * value: Female
 |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "example-balmain-practitioner-1",
  "meta" : {
    "lastUpdated" : "2026-09-10T00:00:00Z",
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitioner"]
  },
  "extension" : [{
    "extension" : [{
      "url" : "value",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/administrative-gender",
          "code" : "female",
          "display" : "Female"
        }]
      }
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/individual-recordedSexOrGender"
  },
  {
    "extension" : [{
      "url" : "suppressedBy",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
          "code" : "practitioner-initiated"
        }]
      }
    }],
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed"
  }],
  "identifier" : [{
    "extension" : [{
      "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-services-identifier-status",
      "valueCoding" : {
        "system" : "http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/hi-services-identifier-status-cs",
        "code" : "A",
        "display" : "Active"
      }
    }],
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "NPI"
      }]
    },
    "system" : "http://ns.electronichealth.net.au/id/hi/hpii/1.0",
    "value" : "8003619900015717"
  }],
  "name" : [{
    "use" : "official",
    "family" : "Anderson",
    "given" : ["Alice"]
  },
  {
    "use" : "usual",
    "family" : "Anderson",
    "given" : ["Alice"]
  }],
  "qualification" : [{
    "identifier" : [{
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org.au/CodeSystem/v2-0203",
          "code" : "AHPRA"
        }]
      },
      "system" : "http://hl7.org.au/id/ahpra-registration-number",
      "value" : "MED0001111111"
    }],
    "code" : {
      "text" : "Medical Practitioner"
    },
    "issuer" : {
      "display" : "Ahpra"
    }
  }]
}

```
