# HCPD HealthcareService Example: Geriatric evaluation and management service - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD HealthcareService Example: Geriatric evaluation and management service**

## Example HealthcareService: HCPD HealthcareService Example: Geriatric evaluation and management service

Last updated: 2026-01-15 10:00:00+1000; 

Information Source: [http://ns.electronichealth.net.au/id/source/pca](http://ns.electronichealth.net.au/id/source/pca)

Profile: [HCPD HealthcareService](StructureDefinition-hcpd-healthcareservice.md)

Northside Community Health Centre – General Practice & Aged Care (Geriatric evaluation and management service) by null (National Organisation Identifier: 8003626566707032) (Resource identifier: HS-PCA-009876)

-------

| | | | |
| :--- | :--- | :--- | :--- |
| Active: | true | Appointment Required: | true |
| Provided By: | [null (National Organisation Identifier: 8003626566707032)](Organization-example-healthconnect-organization-1.md) | | |
| Type: | Geriatric evaluation and management service | | |
| Location: | [Sydney Central Medical Centre (NATA Site Number: Australian National Association of Testing Authorities (NATA) Site Number#165432)](Location-example-healthconnect-medical-centre-location-1.md) | | |
| Coverage Area: | [Sydney CBD Mobile Unit Service Area (Virtual) (LSPN: 876543)](Location-example-healthconnect-mobile-unit-coverage-area-1.md) | | |
| Comment: | Bulk-billing general practice with a specialist aged care program. Walk-ins welcome on weekday mornings. | | |
| Provision Conditions: | * Bulk Billing
* Mixed Billing
 | | |
| Eligibility: | Older adult 65+ yearsSpecialist aged care program for patients 65 and over. | | |
| Languages: | * English
* Chinese
* Vietnamese
 | | |
| Other Id: | Organization identifier/a3f1c802-2e4b-4d90-bef7-8a1234567890 | | |
| Contact Detail | * ph: (02) 9876 5432(Work)
* fax: (02) 9876 5433(Work)
* [appointments@northsidehealth.example.com.au](mailto:appointments@northsidehealth.example.com.au)
* [https://www.northsidehealth.example.com.au](https://www.northsidehealth.example.com.au)
 | | |
| Availability: | * Monday, Tuesday, Wednesday, Thursday, Friday: 08:00:00 - 18:00:00
* Saturday: 09:00:00 - 13:00:00
* Not available: Closed for Christmas and New Year public holidays (2026-12-25 --> 2026-12-28)
* Not available: Closed for Easter public holidays (2027-04-18 --> 2027-04-22)
 | | |
| Endpoint: | [Sydney Private Clinic – FHIR Referral Endpoint (HL7 FHIR (Endpoint Connection Type#hl7-fhir-rest)): https://fhir.sydneyprivateclinic.com.au/fhir](Endpoint-example-hcpd-endpoint-referral.md) | | |
| Suppression Indicator for Visibility: | * suppressedBy: Organisation initiated
 | | |
| [Referral Information for Referrer](StructureDefinition-referral-information-for-referrer.md) | GP referral **not required** for general practice appointments.For the aged care program, a referral from a GP or geriatrician is required.Please include:* Reason for referral
* Current medications list
* Relevant medical history summary
Send referrals via secure messaging to the SMD endpoint or fax to **(02) 9876 5433**. | | |
| [New Patient Availability](StructureDefinition-new-patient-availability.md) | Accepting new patients | | |
| [IAR Levels of Care](StructureDefinition-iar-levels-of-care.md) | * Level 1 - Self management
* Level 2 - Low intensity services
* Level 3 - Moderate intensity services
 | | |
| [Active Period](StructureDefinition-active-period.md) | 2024-01-01 --> 2027-12-31 | | |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "HealthcareService",
  "id" : "example-healthconnect-healthcareservice-2",
  "meta" : {
    "lastUpdated" : "2026-01-15T10:00:00+10:00",
    "source" : "http://ns.electronichealth.net.au/id/source/pca",
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-healthcareservice"]
  },
  "extension" : [{
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/active-period",
    "valuePeriod" : {
      "start" : "2024-01-01",
      "end" : "2027-12-31"
    }
  },
  {
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/iar-levels-of-care",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://healthterminologies.gov.au/fhir/CodeSystem/iar-levels-of-care-1",
        "code" : "level1",
        "display" : "Level 1 - Self management"
      }]
    }
  },
  {
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/iar-levels-of-care",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://healthterminologies.gov.au/fhir/CodeSystem/iar-levels-of-care-1",
        "code" : "level2",
        "display" : "Level 2 - Low intensity services"
      }]
    }
  },
  {
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/iar-levels-of-care",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://healthterminologies.gov.au/fhir/CodeSystem/iar-levels-of-care-1",
        "code" : "level3",
        "display" : "Level 3 - Moderate intensity services"
      }]
    }
  },
  {
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/new-patient-availability",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://healthterminologies.gov.au/fhir/CodeSystem/new-patient-availability-1",
        "code" : "accepting",
        "display" : "Accepting new patients"
      }]
    }
  },
  {
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/referral-information-for-referrer",
    "valueMarkdown" : "GP referral **not required** for general practice appointments.\n\nFor the aged care program, a referral from a GP or geriatrician is required.\n\nPlease include:\n- Reason for referral\n- Current medications list\n- Relevant medical history summary\n\nSend referrals via secure messaging to the SMD endpoint or fax to **(02) 9876 5433**."
  },
  {
    "extension" : [{
      "url" : "suppressedBy",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
          "code" : "organisation-initiated"
        }]
      }
    }],
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed"
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "RI"
      }]
    },
    "system" : "http://ns.electronichealth.net.au/id/source/pca",
    "value" : "HS-PCA-009876"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "XX",
        "display" : "Organization identifier"
      }]
    },
    "system" : "http://digitalhealth.gov.au/fhir/hcpd/id/hcpd-local-identifier",
    "value" : "a3f1c802-2e4b-4d90-bef7-8a1234567890"
  }],
  "active" : true,
  "providedBy" : {
    "reference" : "Organization/example-healthconnect-organization-1"
  },
  "type" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "1584801000168109",
      "display" : "Geriatric evaluation and management service"
    }]
  }],
  "location" : [{
    "reference" : "Location/example-healthconnect-medical-centre-location-1"
  }],
  "name" : "Northside Community Health Centre – General Practice & Aged Care",
  "comment" : "Bulk-billing general practice with a specialist aged care program. Walk-ins welcome on weekday mornings.",
  "telecom" : [{
    "extension" : [{
      "url" : "http://hl7.org.au/fhir/StructureDefinition/contact-purpose",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/contactentity-type",
          "code" : "ADMIN",
          "display" : "Administrative"
        }]
      }
    }],
    "system" : "phone",
    "value" : "(02) 9876 5432",
    "use" : "work"
  },
  {
    "extension" : [{
      "url" : "http://hl7.org.au/fhir/StructureDefinition/contact-purpose",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/contactentity-type",
          "code" : "ADMIN",
          "display" : "Administrative"
        }]
      }
    }],
    "system" : "fax",
    "value" : "(02) 9876 5433",
    "use" : "work"
  },
  {
    "extension" : [{
      "url" : "http://hl7.org.au/fhir/StructureDefinition/contact-purpose",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/contactentity-type",
          "code" : "PATINF",
          "display" : "Patient"
        }]
      }
    }],
    "system" : "email",
    "value" : "appointments@northsidehealth.example.com.au",
    "use" : "work"
  },
  {
    "system" : "url",
    "value" : "https://www.northsidehealth.example.com.au",
    "use" : "work"
  }],
  "coverageArea" : [{
    "reference" : "Location/example-healthconnect-mobile-unit-coverage-area-1"
  }],
  "serviceProvisionCode" : [{
    "coding" : [{
      "system" : "http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/service-provision-cs",
      "code" : "BB",
      "display" : "Bulk Billing"
    }]
  },
  {
    "coding" : [{
      "system" : "http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/service-provision-cs",
      "code" : "MIX",
      "display" : "Mixed Billing"
    }]
  }],
  "eligibility" : [{
    "code" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "933451001000036104",
        "display" : "Older adult 65+ years"
      }]
    },
    "comment" : "Specialist aged care program for patients 65 and over."
  }],
  "communication" : [{
    "coding" : [{
      "system" : "urn:ietf:bcp:47",
      "code" : "en",
      "display" : "English"
    }]
  },
  {
    "coding" : [{
      "system" : "urn:ietf:bcp:47",
      "code" : "zh",
      "display" : "Chinese"
    }]
  },
  {
    "coding" : [{
      "system" : "urn:ietf:bcp:47",
      "code" : "vi",
      "display" : "Vietnamese"
    }]
  }],
  "appointmentRequired" : true,
  "availableTime" : [{
    "daysOfWeek" : ["mon", "tue", "wed", "thu", "fri"],
    "allDay" : false,
    "availableStartTime" : "08:00:00",
    "_availableStartTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    },
    "availableEndTime" : "18:00:00",
    "_availableEndTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    }
  },
  {
    "daysOfWeek" : ["sat"],
    "allDay" : false,
    "availableStartTime" : "09:00:00",
    "_availableStartTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    },
    "availableEndTime" : "13:00:00",
    "_availableEndTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    }
  }],
  "notAvailable" : [{
    "description" : "Closed for Christmas and New Year public holidays",
    "during" : {
      "start" : "2026-12-25",
      "end" : "2026-12-28"
    }
  },
  {
    "description" : "Closed for Easter public holidays",
    "during" : {
      "start" : "2027-04-18",
      "end" : "2027-04-22"
    }
  }],
  "endpoint" : [{
    "reference" : "Endpoint/example-hcpd-endpoint-referral"
  }]
}

```
