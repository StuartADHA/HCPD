# Batch Request Status - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**Guidance**](guidance.md)
* [**Bulk Data Extraction**](bulk-data-extraction.md)
* **Batch Request Status**

## Batch Request Status

### Overview

This page describes step 2 of the Asynchronous Bulk Data Export Process Workflow - polling for the request status.

Status requests have four key components:

1. Preconditions
1. Request to server
1. Responses from server
1. Follow-up actions

### Preconditions

The following preconditions, as documented in the [submission function](BatchRequestSubmission.md), **SHALL** be met before polling the status of the request:

1. The client must have received a`202 Accepted`response from the initial batch request submission
1. The`Content-Location`header in the`202 Accepted`response must be stored for use in polling requests with the specific job ID value.

### Request to server

Clients poll the URL from the `Content-Location` header using a standard HTTP `GET` to check the job's status.

#### Example request

Request HTTP Method

```
GET [base url]/$export-poll-status?_jobId=5abb806c-043e-41e5-903f-5f2995576452
Accept: application/json

```

### Responses from server

#### Response headers

The server **SHALL** include the following headers in its response to polling requests:

* `Retry-After` (integer): indicates the number of seconds the client should wait before making the next polling request. Clients should use this information to inform the timing of future polling requests.
* `X-Progress` (string): provides a human-readable status message about the job's current progress. Clients can try to parse this value, display it to the user, or log it.

#### Response - in progress

While the job is still running, the server responds with `202 Accepted`.

Response HTTP header

```
HTTP/1.1 202 Accepted
Retry-After: 60
X-Progress: Search in progress - found 954 of 1,000 resources

```

Response HTTP body: absent

#### Response - completed

Example of a successful response manifest JSON:

```
{ "transactionTime": "2026-02-19T10:27:53.423+11:00", "request": "http://localhost:8080/fhir/$export", "requiresAccessToken": true, "output": [ { "type": "Organization", "url": "http://localhost:8080/fhir/Binary/fnQjLPLp7x3VpEAsJd4mZ9Fz5mLbZWkY" } ], "error": [] }

```

Example of unsuccessful response manifest JSON:

```
{ "transactionTime": "2026-02-19T10:23:53.417+11:00", "request": "http://localhost:8080/fhir/$export", "requiresAccessToken": true, "output": [], "error": [], "message": "Export complete, but no data to generate report for job instance: 7a75faaa-ac94-4380-a10f-bfb733dba09e" }

```

### Follow-up actions

Following successful request status polling, there are two possible follow-up actions:

#### Retrieving results

Once processing is complete, the server provides links to the generated bulk data files. Clients can use these links to download the results.

For full details, refer to the [Batch Request Results](BatchRequestResults.md) page.

#### Deleting a request

Clients can delete a batch request by sending a `DELETE` request to the URL provided in the `Content-Location` header.

For full details, refer to the [Batch Request Delete](BatchRequestDelete.md) page.

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.

