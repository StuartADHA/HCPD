# HCPD Service Coverage Area - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Service Coverage Area**

## Resource Profile: HCPD Service Coverage Area 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-service-coverage-area | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:HCPD_Service_Coverage_Area |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

 
This profile of Location represents an Australian geographic coverage area i.e. postcodes where this service is provided. For a healthcare service, that is provided through a physical location but have eligibility restrictions applicable in terms of only residents for certain postcodes/suburbs can receive this service, then the details of coverage area and eligibility should be provided here. 

No data is entered directly into Health Connect; all Directory content is sourced from authoritative systems including [PCA](https://developer.digitalhealth.gov.au/fhir/provider-connect-australia/current/index.html?src=/), HI-Service, and NHSD.

### Service coverage area in Health Connect

The address that defines the coverage area where the service is available is represented by this profile. The HCPD Service Coverage Area profile is applied to FHIR Location resources to describe an Australian geographic area (postcode, suburb, or region) in which a healthcare service is available.

This profile is referenced by the [HCPD HealthcareService](StructureDefinition-hcpd-healthcareservice.md) profile via the `coverageArea` element, allowing each healthcare service to specify one or more geographic areas where the service is offered. It may also be referenced by other profiles that need to describe service eligibility or restrictions based on geography.

### Usage notes

The coverage area that a service is intended for/available to can be represented as one or more instances of Location, where the address elements are populated depending on the type of coverage area to be defined.

To define an Australia-wide coverage area, only the following element shall be populated:

* address.country

To define a coverage area for a particular state, the following elements should be populated in addition to address.country:

* address.state

To define a coverage area for a particular suburb, the following elements should be populated in addition to address.country:

* address.city
* address.postalCode
* address.state

**Usages:**

* Refer to this Profile: [HCPD HealthcareService](StructureDefinition-hcpd-healthcareservice.md)
* Examples for this Profile: [Balmain Service Coverage Area](Location-example-healthconnect-service-coverage-area-balmain-1.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/au.gov.digitalhealth.fhir.hcpd|current/StructureDefinition/StructureDefinition-hcpd-service-coverage-area.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-hcpd-service-coverage-area.csv), [Excel](StructureDefinition-hcpd-service-coverage-area.xlsx), [Schematron](StructureDefinition-hcpd-service-coverage-area.sch) 

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "hcpd-service-coverage-area",
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-service-coverage-area",
  "version" : "26.0.0",
  "name" : "HCPD_Service_Coverage_Area",
  "title" : "HCPD Service Coverage Area",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "This profile of Location represents an Australian geographic coverage area i.e. postcodes where this service is provided.\r\nFor a healthcare service, that is provided through a physical location but have eligibility restrictions applicable in terms of only residents for certain postcodes/suburbs can receive this service, then the details of coverage area and eligibility should be provided here.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Location",
  "baseDefinition" : "http://hl7.org.au/fhir/core/StructureDefinition/au-core-location|2.0.0",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Location",
      "path" : "Location",
      "short" : "Australian geographic area in which a service is available.",
      "constraint" : [{
        "key" : "inv-01-address-postalcode-4-digits",
        "severity" : "error",
        "human" : "If present, postalCode shall be 4 digits",
        "expression" : "address.postalCode.empty() or address.postalCode.matches('^[0-9]{4}$')",
        "source" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-service-coverage-area|26.0.0"
      }]
    },
    {
      "id" : "Location.extension",
      "path" : "Location.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Location.extension:suppressed",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.extension",
      "sliceName" : "suppressed",
      "short" : "Indicates if Location service is suppressed",
      "definition" : "Indicates if Location service is suppressed.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Location.extension:suppressed.extension:suppressedBy",
      "path" : "Location.extension.extension",
      "sliceName" : "suppressedBy"
    },
    {
      "id" : "Location.extension:suppressed.extension:suppressedBy.value[x].coding",
      "path" : "Location.extension.extension.value[x].coding",
      "max" : "1",
      "fixedCoding" : {
        "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
        "code" : "organisation-initiated"
      },
      "mustSupport" : true
    },
    {
      "id" : "Location.extension:deactivated",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:ignore"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:ignore"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.extension",
      "sliceName" : "deactivated",
      "short" : "Indicates if service coverage area is suppressed",
      "definition" : "Indicates if service coverage area is suppressed.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/deactivated|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Location.extension:deactivated.extension:deactivatedBy",
      "path" : "Location.extension.extension",
      "sliceName" : "deactivatedBy"
    },
    {
      "id" : "Location.extension:deactivated.extension:deactivatedBy.value[x].coding",
      "path" : "Location.extension.extension.value[x].coding",
      "max" : "1",
      "fixedCoding" : {
        "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
        "code" : "organisation-initiated"
      },
      "mustSupport" : true
    },
    {
      "id" : "Location.address",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://hl7.org.au/fhir/core/StructureDefinition/au-core-location|2.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://hl7.org.au/fhir/core/StructureDefinition/au-core-location|2.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.address",
      "short" : "The address that defines the coverage area where the service is available",
      "min" : 1
    },
    {
      "id" : "Location.address.city",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.address.city",
      "short" : "Australian city, town or suburb",
      "definition" : "An Australian city, town or suburb where the service is available.",
      "mustSupport" : true
    },
    {
      "id" : "Location.address.state",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.address.state",
      "short" : "Australian state or territory",
      "definition" : "An Australian state or territory where the service is available.",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://healthterminologies.gov.au/fhir/ValueSet/australian-states-territories-2"
      }
    },
    {
      "id" : "Location.address.postalCode",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.address.postalCode",
      "mustSupport" : true
    },
    {
      "id" : "Location.address.country",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.address.country",
      "short" : "Australia as a 2 digit ISO 3166 code",
      "definition" : "The 2 digit ISO 3166 code for Australia (AU).",
      "min" : 1,
      "patternString" : "AU",
      "mustSupport" : true
    },
    {
      "id" : "Location.managingOrganization",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://hl7.org.au/fhir/core/StructureDefinition/au-core-location|2.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://hl7.org.au/fhir/core/StructureDefinition/au-core-location|2.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.managingOrganization",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-organization|26.0.0"]
      }]
    }]
  }
}

```
