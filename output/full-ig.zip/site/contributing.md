# Contributing - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**Change Log**](changelog.md)
* **Contributing**

## Contributing

Thank you for considering contributing! Your input helps improve this guide for the community.

The source for this IG is maintained on GitHub at [AuDigitalHealth/HCPD](https://github.com/AuDigitalHealth/HCPD).

### How to Contribute

* **Report Issues**: Use GitHub Issues to report bugs or suggest improvements.
* **Propose Changes**: 
* Fork the repository.
* Create a branch: `git checkout -b feature/your-change`
* Commit and push your changes.
* Submit a Pull Request.
 

### Coding Standards

* Follow HL7 FHIR IG Publisher conventions.
* Validate your IG locally before submitting.

### Legal Notice and Contributor Agreement

The Australian Digital Health Agency ("the Agency") makes the information and other material on this website available in good faith but without any representation or warranty as to its accuracy or completeness, for the purpose of disseminating information free of charge for the benefit of the public. The Agency cannot accept any responsibility for the consequences of any use or disclosure of the information. By contributing to and enhancing any of the code on this website, you agree that your work becomes part of this project and can be freely used, modified, and shared by the Agency.

### Review Process

* All PRs will be reviewed by maintainers.
* Once accepted, PRs will be merged into a holding branch until closer to the next milestone when they will be merged into main.

### Code of conduct

Before making a contribution, please read the [code of conduct](https://github.com/AuDigitalHealth/HCPD/blob/main/CODE_OF_CONDUCT.md).

### Contact us

You can alo raise a query about this code, by emailing: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au)

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.

