# Known Issues - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**Support**](support.md)
* **Known Issues**

## Known Issues

This table lists known issues with this specification at the time of publishing. We are working on solutions to these issues and encourage comments to help us develop these solutions.

* Reference: Example system URI
  * Description: An inherited example system (e.g.`http://www.acme.com/identifiers/patient`) erroneously infers patient context. Implementers must use their own namespace URIs. The affected identifier profile is Endpoint (hcpd-EPI) - this profile includes the erroneous example `system` in their documentation.
* Reference: Dependency on current version of Australian Provider Directory IG (FHIR IG)
  * Description: The HCPD FHIR IG utilises[Australian Service Interfaces](https://hl7.org.au/fhir/pd/pd2/ValueSet-service-interfaces.html)and[Australian Endpoint Payload Types](https://hl7.org.au/fhir/pd/pd2/ValueSet-endpoint-payload-type.html)from the Australian Provider Directory FHIR IG. However, including a dependency on v2.0.1 of the HL7 AU PD FHIR IG results in a publisher error due to a FHIR version mismatch: the AU PD IG is built on FHIR version 4.0.0 while HCPD requires version 4.0.1.

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.

