# Security and Privacy - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* **Security and Privacy**

## Security and Privacy

### Security and Privacy

When implementing Health Connect Provider Directory (HCPD), implementers need to be aware of FHIR security and safety considerations and take appropriate measures to protect information privacy and prevent exploitation by malicious actors. In particular, implementers are advised to review:

* [FHIR Security Considerations](https://hl7.org/fhir/R4/security.html)
* [FHIR Implementer Safety Checklist](https://hl7.org/fhir/R4/safety.html)
* [AU Core Security and Privacy](https://build.fhir.org/ig/hl7au/au-fhir-core/security.html)

Implementers of Health Connect Provider Directory need to be aware of their obligations regarding security, privacy, and consent in Australia.

For HCPD, specific security requirements include:

* Systems **SHOULD** conform to [FHIR Communications Security](https://hl7.org/fhir/R4/security.html#http) requirements.
* Systems **SHALL** use TLS version 1.2 or higher for data exchange.
* Systems **SHOULD** use TLS version 1.3 for data exchange.
* Systems **SHOULD** use the Australian Cyber Security Centre (ACSC) [TLS configuration guidelines](https://www.cyber.gov.au/resources-business-and-government/maintaining-devices-and-systems/system-hardening-and-administration/web-hardening/implementing-certificates-tls-https-and-opportunistic-tls) that include recommendations for configuring protocol features and acceptable cipher suites when implementing TLS.

#### Data Removal and Privacy Controls

Organizations and Practitioners can elect to have their information removed from the Health Connect Provider Directory (HCPD) through [Provider Connect Australia (PCA)](https://www.digitalhealth.gov.au/healthcare-providers/initiatives-and-programs/provider-connect-australia).

For more information about data removal procedures, providers should consult the PCA documentation and contact the Australian Digital Health Agency directly.

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.

