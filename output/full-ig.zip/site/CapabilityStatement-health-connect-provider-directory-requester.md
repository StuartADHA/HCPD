# Health Connect Provider Directory Requester - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **Health Connect Provider Directory Requester**

## CapabilityStatement: Health Connect Provider Directory Requester 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/CapabilityStatement/health-connect-provider-directory-requester | *Version*:26.0.0 |
| Active as of 2026-09-10 | *Computable Name*:HealthConnectProviderDirectoryRequester |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

 
This [CapabilityStatement](https://hl7.org/fhir/R4/capabilitystatement.html) resource defines the expected capabilities of the [Health Connect Provider Directory Requester Actor](ActorDefinition-requester-actor-health-connect.md) when conforming to this implementation guide. The complete list of FHIR profiles, RESTful operations, and search parameters supported by Health Connect Provider Directory Requester Actor are defined in this CapabilityStatement. The requirements of the Health Connect Provider Directory Requester actor may also be impacted by the rules of local jurisdictions or other contextual requirements. 

 [Raw OpenAPI-Swagger Definition file](health-connect-provider-directory-requester.openapi.json) | [Download](health-connect-provider-directory-requester.openapi.json) 

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "health-connect-provider-directory-requester",
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/CapabilityStatement/health-connect-provider-directory-requester",
  "version" : "26.0.0",
  "name" : "HealthConnectProviderDirectoryRequester",
  "title" : "Health Connect Provider Directory Requester",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-10",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "This [CapabilityStatement](https://hl7.org/fhir/R4/capabilitystatement.html) resource defines the expected capabilities \r\nof the [Health Connect Provider Directory Requester Actor](ActorDefinition-requester-actor-health-connect.html) when conforming to this implementation guide. The complete \r\nlist of FHIR profiles, RESTful operations, and search parameters supported by Health Connect Provider Directory Requester Actor are defined in this CapabilityStatement. \r\nThe requirements of the Health Connect Provider Directory Requester actor may also be impacted by the rules of local jurisdictions or other contextual requirements.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "kind" : "requirements",
  "fhirVersion" : "4.0.1",
  "format" : ["json"],
  "_format" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
      "valueCode" : "SHALL"
    }]
  }],
  "rest" : [{
    "mode" : "client",
    "security" : {
      "service" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/restful-security-service",
          "code" : "OAuth",
          "display" : "OAuth"
        }]
      }],
      "description" : "All interactions SHOULD be secured using OAuth protocols. It SHOULD support authentication, authorisation, and audit logging in accordance with local policy and regulatory requirements."
    },
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHOULD"
      }],
      "type" : "Provenance",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-provenance|26.0.0",
      "documentation" : "This resource is used to track the provenance of data retrieved, updated, or verified from external systems of record for HC resources.",
      "interaction" : [{
        "code" : "read",
        "documentation" : "Read HCPD Provenance records to understand data lineage"
      },
      {
        "code" : "search-type",
        "documentation" : "Search for HCPD Provenance records by target resource"
      }],
      "versioning" : "versioned",
      "readHistory" : false,
      "searchInclude" : ["Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "target",
        "definition" : "http://hl7.org/fhir/SearchParameter/Provenance-target|4.0.1",
        "type" : "reference"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "Organization",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-organization|26.0.0",
      "documentation" : "This section defines the supported interactions by a Requester Actor for the HCPD Organization profile of the Organization resource type.",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type"
      }],
      "versioning" : "versioned",
      "searchInclude" : ["Organization:partOf"],
      "searchRevInclude" : ["Location:organization", "Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "identifier",
        "definition" : "http://hl7.org/fhir/SearchParameter/Organization-identifier|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "name",
        "definition" : "http://hl7.org/fhir/SearchParameter/Organization-name|4.0.1",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "type",
        "definition" : "http://hl7.org/fhir/SearchParameter/Organization-type|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "active",
        "definition" : "http://hl7.org/fhir/SearchParameter/Organization-active|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "suppressed",
        "definition" : "http://digitalhealth.gov.au/fhir/cc/SearchParameter/suppressed|26.0.0",
        "type" : "token"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHOULD"
      }],
      "type" : "Location",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0",
      "documentation" : "This section introduces the supported interactions by a Requester Actor for the HCPD Location profile.",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type"
      }],
      "versioning" : "versioned",
      "searchInclude" : ["Location:organization", "Location:endpoint"],
      "searchRevInclude" : ["HealthcareService:location", "Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "locmailaddress",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/location-locmailaddress|26.0.0",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "locationamenities",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/location-amenities|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "name",
        "definition" : "http://hl7.org/fhir/SearchParameter/Location-name|4.0.1",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "address",
        "definition" : "http://hl7.org/fhir/SearchParameter/Location-address|4.0.1",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "type",
        "definition" : "http://hl7.org/fhir/SearchParameter/Location-type|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "locationphysicaltype",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/location-physicaltype|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "near",
        "definition" : "http://hl7.org/fhir/SearchParameter/Location-near|4.0.1",
        "type" : "special"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "status",
        "definition" : "http://hl7.org/fhir/SearchParameter/Location-status|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "suppressed",
        "definition" : "http://digitalhealth.gov.au/fhir/cc/SearchParameter/suppressed|26.0.0",
        "type" : "token"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHOULD"
      }],
      "type" : "HealthcareService",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-healthcareservice|26.0.0",
      "documentation" : "This section introduces the supported interactions by a Requester Actor for the [HCPD Healthcare Service](StructureDefinition-hcpd-healthcareservice.html) profile.",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type"
      }],
      "searchInclude" : ["HealthcareService:location",
      "HealthcareService:organization",
      "HealthcareService:endpoint"],
      "searchRevInclude" : ["PractitionerRole:service", "Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "languages",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/languages|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "hsbilling",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/healthcareservice-billing|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "allday",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/allday|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "daysofweek",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/daysofweek|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "starttime",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/starttime|26.0.0",
        "type" : "number"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "endtime",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/endtime|26.0.0",
        "type" : "number"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "service-type",
        "definition" : "http://hl7.org/fhir/SearchParameter/HealthcareService-service-type|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "active",
        "definition" : "http://hl7.org/fhir/SearchParameter/HealthcareService-active|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "suppressed",
        "definition" : "http://digitalhealth.gov.au/fhir/cc/SearchParameter/suppressed|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "healthcareservice-type-display",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/healthcareservice-type-display|26.0.0",
        "type" : "string"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHOULD"
      }],
      "type" : "PractitionerRole",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitionerrole|26.0.0",
      "documentation" : "This section defines the supported interactions for the [HCPD Practitioner Role](StructureDefinition-hcpd-practitionerrole.html) profile of the PractitionerRole resource type. Each PractitionerRole resource conforming to the [HCPD Practitioner Role](StructureDefinition-hcpd-practitionerrole.html) profile describes a practitioner in a role at a healthcare service.",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type"
      }],
      "searchInclude" : ["PractitionerRole:practitioner",
      "PractitionerRole:service",
      "PractitionerRole:organization",
      "PractitionerRole:location",
      "PractitionerRole:endpoint"],
      "searchRevInclude" : ["Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "languages",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/languages|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "allday",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/allday|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "daysofweek",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/daysofweek|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "starttime",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/starttime|26.0.0",
        "type" : "number"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "endtime",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/endtime|26.0.0",
        "type" : "number"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "identifier",
        "definition" : "http://hl7.org/fhir/SearchParameter/PractitionerRole-identifier|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "role",
        "definition" : "http://hl7.org/fhir/SearchParameter/PractitionerRole-role|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "active",
        "definition" : "http://hl7.org/fhir/SearchParameter/PractitionerRole-active|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "suppressed",
        "definition" : "http://digitalhealth.gov.au/fhir/cc/SearchParameter/suppressed|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "practitionerrole-code-display",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/practitionerrole-code-display|26.0.0",
        "type" : "string"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "Practitioner",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitioner|26.0.0",
      "documentation" : "This section defines the supported interactions for the [HCPD Practitioner](StructureDefinition-hcpd-practitioner.html) profile of the Practitioner resource type.",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type"
      }],
      "searchRevInclude" : ["PractitionerRole:practitioner", "Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "identifier",
        "definition" : "http://hl7.org/fhir/SearchParameter/Practitioner-identifier|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "regprof",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/practitioner-regprof|26.0.0",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "rsg",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/practitioner-rsg|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "name",
        "definition" : "http://hl7.org/fhir/SearchParameter/Practitioner-name|4.0.1",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "identifier-r5",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/practitioner-identifier-r5|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "active",
        "definition" : "http://hl7.org/fhir/SearchParameter/Practitioner-active|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "suppressed",
        "definition" : "http://digitalhealth.gov.au/fhir/cc/SearchParameter/suppressed|26.0.0",
        "type" : "token"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHOULD"
      }],
      "type" : "Endpoint",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-endpoint|26.0.0",
      "documentation" : "This section defines the supported interactions for the [HCPD Endpoint](StructureDefinition-hcpd-endpoint.html) profile of the Endpoint resource type. Each Endpoint resource conforming to the [HCPD Endpoint](StructureDefinition-hcpd-endpoint.html) profile is a read-only proxy for a corresponding Endpoint resource published by the HCPD portal.",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type"
      }],
      "versioning" : "versioned",
      "searchRevInclude" : ["HealthcareService:endpoint",
      "Location:endpoint",
      "PractitionerRole:endpoint",
      "Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "epurl",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/endpoint-url|26.0.0",
        "type" : "uri"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "payloadmimetype",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/endpoint-payloadmimetype|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "hcepi",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/endpoint-hcepi|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "name",
        "definition" : "http://hl7.org/fhir/SearchParameter/Endpoint-name|4.0.1",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "connection-type",
        "definition" : "http://hl7.org/fhir/SearchParameter/Endpoint-connection-type|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "payload-type",
        "definition" : "http://hl7.org/fhir/SearchParameter/Endpoint-payload-type|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "status",
        "definition" : "http://hl7.org/fhir/SearchParameter/Endpoint-status|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "suppressed",
        "definition" : "http://digitalhealth.gov.au/fhir/cc/SearchParameter/suppressed|26.0.0",
        "type" : "token"
      }]
    }]
  }]
}

```
