# Terminology - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **Terminology**

## Terminology

The [value sets](http://hl7.org/fhir/R4/valueset.html) and [code systems](http://hl7.org/fhir/R4/codesystem.html) listed below are defined as part of this implementation guide.

**Note:** This IG consumes terminology from external dependencies where appropriate and also defines a set of IG-local terminology. The sections below list the external terminology this IG references (split by source) and the terminology defined within this IG.

### External Terminology

#### AU Provider Directory (AU PD)

The IG reuses terminology published in the AU Provider Directory (AU PD) implementation guide where applicable. Key AU PD artefacts referenced by this IG include:

ValueSets

* [service-interfaces](https://build.fhir.org/ig/hl7au/au-fhir-pd/ValueSet-service-interfaces.html) — http://hl7.org.au/fhir/pd/ValueSet/service-interfaces
* [endpoint-payload-type](https://build.fhir.org/ig/hl7au/au-fhir-pd/ValueSet-endpoint-payload-type.html) — http://hl7.org.au/fhir/pd/ValueSet/endpoint-payload-type

CodeSystems

* [smd-interfaces](https://build.fhir.org/ig/hl7au/au-fhir-pd/CodeSystem-smd-interfaces.html) — http://hl7.org.au/fhir/pd/CodeSystem/smd-interfaces
* [endpoint-payload-type (AU PD)](https://build.fhir.org/ig/hl7au/au-fhir-pd/CodeSystem-endpoint-payload-type.html) — http://hl7.org.au/fhir/pd/CodeSystem/endpoint-payload-type

#### National Clinical Terminology Service (NCTS)

CodeSystems

* [Facility Amenities](https://healthterminologies.gov.au/fhir/CodeSystem/facility-amenity-1)
* [New Patient Availability](https://www.healthterminologies.gov.au/integration/R4/fhir/CodeSystem/new-patient-availability-1)
* [Service Eligibility](https://healthterminologies.gov.au/fhir/CodeSystem/service-eligibility-2)
* [IAR Levels of Care](https://healthterminologies.gov.au/fhir/CodeSystem/iar-levels-of-care-1)

ValueSets

* [Facility Amenities](https://healthterminologies.gov.au/fhir/ValueSet/facility-amenity-1)
* [New Patient Availability](https://www.healthterminologies.gov.au/integration/R4/fhir/ValueSet/new-patient-availability-1)
* [Service Delivery Role Type](https://healthterminologies.gov.au/fhir/ValueSet/service-delivery-location-role-type-1)
* [Service Eligibility](https://healthterminologies.gov.au/fhir/ValueSet/service-eligibility-2)
* [IAR Levels of Care](https://healthterminologies.gov.au/fhir/ValueSet/iar-levels-of-care-1)

### IG defined Terminology

Terminology which has been defined internally within this IG is listed below. Use of these NCTS profiles is an Australian Digital Health Agency conformance requirement for terminology artefacts intended to create alignment with NCTS publication.

* [https://healthterminologies.gov.au/fhir/StructureDefinition/complete-code-system-4](https://healthterminologies.gov.au/fhir/StructureDefinition/complete-code-system-4)
* [https://healthterminologies.gov.au/fhir/StructureDefinition/composed-value-set-4](https://healthterminologies.gov.au/fhir/StructureDefinition/composed-value-set-4)

#### Value sets

* [HI Service Organization Classification ValueSet](ValueSet-hi-org-classification-vs.md)

* [HI Services Identifier Status Value Set](ValueSet-hi-services-identifier-status-vs.md)

* [Responsible Party Type](ValueSet-responsible-party-type.md)

* [Service Provision Code ValueSet](ValueSet-service-provision-code-vs.md)

#### Code systems

* [HI Service Organisation Classification CodeSystem](CodeSystem-hi-org-classification-cs.md)

* [HI Services Identifier Status Code System](CodeSystem-hi-services-identifier-status-cs.md)

* [Responsible Party Type](CodeSystem-responsible-party-type.md)

* [Service Provision CodeSystem](CodeSystem-service-provision-cs.md)

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.

