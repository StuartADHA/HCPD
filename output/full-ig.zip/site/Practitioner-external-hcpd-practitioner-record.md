# HCPD Practitioner Example: External Record (PRN) - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Practitioner Example: External Record (PRN)**

## Example Practitioner: HCPD Practitioner Example: External Record (PRN)

Profile: [HCPD Practitioner](StructureDefinition-hcpd-practitioner.md)

John Fryer (National provider identifier: 8003616566719020)

-------

| | |
| :--- | :--- |
| Active: | false |
| Alt. Name: | John Fryer (Official) |
| Contact Detail | * [+61 2 8555 0199](tel:+61285550199)
* [+61 2 7777 0199](tel:+61277770199)
 |
| Qualification: | Clinical Hypnotherapist* Identifier: Provider number/PRN-123456 (use: official)
* Issued By: Australian Clinical Hypnotherapy Association
 |
| Qualification: | Pathologist* Identifier: Provider number/PRN-2468 (use: official)
* Issued By: RCPA
 |
| Language: | Italian |
| Suppression Indicator for Visibility: | * suppressedBy: Practitioner initiated
 |
| Person Recorded Sex Or Gender: | * value: Male
 |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "external-hcpd-practitioner-record",
  "meta" : {
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitioner"]
  },
  "extension" : [{
    "extension" : [{
      "url" : "value",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/administrative-gender",
          "code" : "male",
          "display" : "Male"
        }]
      }
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/individual-recordedSexOrGender"
  },
  {
    "extension" : [{
      "url" : "suppressedBy",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
          "code" : "practitioner-initiated"
        }]
      }
    }],
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed"
  }],
  "identifier" : [{
    "extension" : [{
      "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-services-identifier-status",
      "valueCoding" : {
        "system" : "http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/hi-services-identifier-status-cs",
        "code" : "A",
        "display" : "Active"
      }
    }],
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "NPI"
      }]
    },
    "system" : "http://ns.electronichealth.net.au/id/hi/hpii/1.0",
    "value" : "8003616566719020"
  }],
  "active" : false,
  "name" : [{
    "use" : "official",
    "family" : "Fryer",
    "given" : ["John"],
    "prefix" : ["Dr"]
  },
  {
    "use" : "usual",
    "family" : "Fryer",
    "given" : ["John"]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "+61 2 8555 0199",
    "use" : "work"
  },
  {
    "system" : "phone",
    "value" : "+61 2 7777 0199",
    "use" : "home"
  }],
  "qualification" : [{
    "identifier" : [{
      "use" : "official",
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "PRN"
        }]
      },
      "system" : "http://example.org/fhir/identifier/acha-prn",
      "value" : "PRN-123456"
    }],
    "code" : {
      "text" : "Clinical Hypnotherapist"
    },
    "issuer" : {
      "display" : "Australian Clinical Hypnotherapy Association"
    }
  },
  {
    "identifier" : [{
      "use" : "official",
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "PRN"
        }]
      },
      "system" : "http://example.org/fhir/identifier/rcpa-prn",
      "value" : "PRN-2468"
    }],
    "code" : {
      "text" : "Pathologist"
    },
    "issuer" : {
      "display" : "RCPA"
    }
  }],
  "communication" : [{
    "coding" : [{
      "system" : "urn:ietf:bcp:47",
      "code" : "it",
      "display" : "Italian"
    }]
  }]
}

```
