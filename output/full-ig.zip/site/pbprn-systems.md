# PBPRN Supported Systems - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **PBPRN Supported Systems**

## PBPRN Supported Systems

### PBPRN Supported Peak Body Systems

The following table lists the professional associations and peak bodies whose registration numbers may be represented using the [Peak Body Professional Registration Number (PBPRN)](StructureDefinition-pbprn.md) identifier profile. The `system` URI must be used as the value of `identifier.system` when recording a registration number issued by the corresponding organisation.

| | | |
| :--- | :--- | :--- |
| AAFT | Australian Association of Family Therapy | `http://ns.electronichealth.net.au/id/peakbody/aaft/1.0` |
| AARPN | Australasian Association and Register of Practicing Nutritionists | `http://ns.electronichealth.net.au/id/peakbody/aarpn/1.0` |
| AASW | Australian Association of Social Workers | `http://ns.electronichealth.net.au/id/peakbody/aasw/1.0` |
| ACA | Australian Counselling Association | `http://ns.electronichealth.net.au/id/peakbody/aca/1.0` |
| ACAUD | Australian College of Audiology | `http://ns.electronichealth.net.au/id/peakbody/acaud/1.0` |
| ACCP | Australian Council for Clinical Physiologists | `http://ns.electronichealth.net.au/id/peakbody/accp/1.0` |
| ACP | Australasian College of Paramedicine | `http://ns.electronichealth.net.au/id/peakbody/acp/1.0` |
| ADEA | Australian Diabetes Educators Association | `http://ns.electronichealth.net.au/id/peakbody/adea/1.0` |
| AIPC | Australian Institute of Professional Counsellors | `http://ns.electronichealth.net.au/id/peakbody/aipc/1.0` |
| AIMS | Australian Institute of Medical and Clinical Scientists | `http://ns.electronichealth.net.au/id/peakbody/aims/1.0` |
| AMT | Association of Massage Therapists | `http://ns.electronichealth.net.au/id/peakbody/amt/1.0` |
| AMTA | Australian Music Therapy Association | `http://ns.electronichealth.net.au/id/peakbody/amta/1.0` |
| AAOS | Australasian Association of Supervision | `http://ns.electronichealth.net.au/id/peakbody/aaos/1.0` |
| ANTA | Australian Natural Therapists Association Ltd | `http://ns.electronichealth.net.au/id/peakbody/anta/1.0` |
| ANZACATA | The Australian New Zealand and Asian Creative Arts Therapies Association | `http://ns.electronichealth.net.au/id/peakbody/anzacata/1.0` |
| ANZCP | Australian and New Zealand College of Perfusionists | `http://ns.electronichealth.net.au/id/peakbody/anzcp/1.0` |
| ANZMHA | Australian and New Zealand Mental Health Association | `http://ns.electronichealth.net.au/id/peakbody/anzmha/1.0` |
| AOPA | Australian Orthotic Prosthetic Association | `http://ns.electronichealth.net.au/id/peakbody/aopa/1.0` |
| APA | Australian Physiotherapy Association | `http://ns.electronichealth.net.au/id/peakbody/apa/1.0` |
| APRB | Australian Pedorthist Registration Board | `http://ns.electronichealth.net.au/id/peakbody/aprb/1.0` |
| ASA | Australasian Sonographers Association | `http://ns.electronichealth.net.au/id/peakbody/asa/1.0` |
| ASAR | Australian Sonographer Accreditation Registry | `http://ns.electronichealth.net.au/id/peakbody/asar/1.0` |
| ASGC | Australasian Society of Genetic Counsellors | `http://ns.electronichealth.net.au/id/peakbody/asgc/1.0` |
| ASORC | Australian Society of Rehabilitation Counsellors | `http://ns.electronichealth.net.au/id/peakbody/asorc/1.0` |
| ATEP | Association of Transpersonal and Experiential Psychotherapists Inc | `http://ns.electronichealth.net.au/id/peakbody/atep/1.0` |
| ATMS | Australian Traditional Medicine Society | `http://ns.electronichealth.net.au/id/peakbody/atms/1.0` |
| AUDA | Audiology Australia | `http://ns.electronichealth.net.au/id/peakbody/auda/1.0` |
| BAA | Bowen Association Australia | `http://ns.electronichealth.net.au/id/peakbody/baa/1.0` |
| CMA | Complementary Medicine Association | `http://ns.electronichealth.net.au/id/peakbody/cma/1.0` |
| DA | Dietitians Australia | `http://ns.electronichealth.net.au/id/peakbody/da/1.0` |
| ESSA | Exercise and Sports Science Australia | `http://ns.electronichealth.net.au/id/peakbody/essa/1.0` |
| HGSA | Human Genetics Society of Australasia | `http://ns.electronichealth.net.au/id/peakbody/hgsa/1.0` |
| HTA | Holistic Therapists Australia Inc | `http://ns.electronichealth.net.au/id/peakbody/hta/1.0` |
| IAHA | Indigenous Allied Health Australia | `http://ns.electronichealth.net.au/id/peakbody/iaha/1.0` |
| IICT | International Institute of Complementary Therapists | `http://ns.electronichealth.net.au/id/peakbody/iict/1.0` |
| MMA | Massage and Myotherapy Association | `http://ns.electronichealth.net.au/id/peakbody/mma/1.0` |
| MTAA | Medical Technology Association of Australia | `http://ns.electronichealth.net.au/id/peakbody/mtaa/1.0` |
| NCA | Nutrition Council Australia | `http://ns.electronichealth.net.au/id/peakbody/nca/1.0` |
| NHAA | National Herbalists Association of Australia | `http://ns.electronichealth.net.au/id/peakbody/nhaa/1.0` |
| OA | Orthoptics Australia | `http://ns.electronichealth.net.au/id/peakbody/oa/1.0` |
| PAA | Pedorthic Association of Australia | `http://ns.electronichealth.net.au/id/peakbody/paa/1.0` |
| PACFA | Psychotherapy and Counselling Federations of Australia | `http://ns.electronichealth.net.au/id/peakbody/pacfa/1.0` |
| PTPA | Play Therapy Practitioners Association | `http://ns.electronichealth.net.au/id/peakbody/ptpa/1.0` |
| RCAA | Rehabilitation Counselling Association of Australasia | `http://ns.electronichealth.net.au/id/peakbody/rcaa/1.0` |
| SPA | Speech Pathology Australia | `http://ns.electronichealth.net.au/id/peakbody/spa/1.0` |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.

