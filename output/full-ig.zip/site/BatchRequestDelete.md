# Batch Request Delete - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**Guidance**](guidance.md)
* [**Bulk Data Extraction**](bulk-data-extraction.md)
* **Batch Request Delete**

## Batch Request Delete

### Overview

This page describes the option to delete an Asynchronous Bulk Data Export request.

Deleting requests has 3 key components:

1. Preconditions
1. Request to server
1. Responses from server

### Preconditions

The following preconditions, as documented in the [status polling function](BatchRequestStatus.md), **SHALL** be met before deleting a bulk data export request:

1. The client must have received a`202 Accepted`response from the initial batch request submission

### Request to server

After a successful request has been made to the server, a client MAY send a http `DELETE` request to the URL provided in the `Content-Location` header to cancel the request.

#### Example request

Request HTTP header

```
DELETE [base]/$export-poll-status?_jobId=a5a60ba8-5bdc-4d2d-a7ef-13f905205b01

```

Request HTTP body: absent

### Responses from server

#### Success response

The server responds with a `202 Accepted` status code.

Response HTTP header

```
HTTP/1.1 202 Accepted

```

Response HTTP body: absent

Subsequent polls to this URL MUST return `404 Not Found`.

#### Error response

If the server rejects the request, it returns:

* a `400 Bad Request` error
* a FHIR OperationOutcome resource identifying the issue

**Example Error Response:**

```
HTTP/1.1 400 Bad Request

```

```
{
  "resourceType": "OperationOutcome",
  "issue": [
    {
      "severity": "error",
      "code": "invalid",
      "diagnostics": "Endpoint artefact not found for the provided job ID."
    }
  ]
}

```

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.

