# HCPD Source Identifier (HCPD-SI) - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Source Identifier (HCPD-SI)**

## Data Type Profile: HCPD Source Identifier (HCPD-SI) 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-source-identifier | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:HCPD_Source_Identifier |
| **Copyright/Legal**: Copyright © 2025 Australian Digital Health Agency - All rights reserved. This content is licensed under a Creative Commons Attribution 4.0 International License. See https://creativecommons.org/licenses/by/4.0/. | |

 
This profile of Identifier defines a HCPD Source Identifier (HCPD-SI). 

### HCPD Source Identifier (HCPD-SI)

The `HCPD-SI` is the primary external identifier assigned by a publisher to a `HCPD` instance for identification and integration with Health Connect. It is **mandatory** for all HealthcareService, Location, Endpoint & PractitionerRole `HCPD` resources published in the Health Connect directory.

* `identifier.type`: fixed to `RI` (resource identifier).
* `identifier.value`: the value defined by the source organisation.
* `identifier.system`: populate with a stable URI to support authoritative reconciliation.

Guidance:

* The combination of system and value MUST be globally unique within Health Connect and **SHOULD** be stable over the lifecycle of the resource.
* Use `identifier.system` to record a canonical URI when organisations have a stable namespace for their identifiers.
* This identifier **SHALL** respect the value, type and system attributed by the source system from where the data was initially ingested.

**Usages:**

* Use this DataType Profile: [HCPD Endpoint](StructureDefinition-hcpd-endpoint.md), [HCPD HealthcareService](StructureDefinition-hcpd-healthcareservice.md), [HCPD Location](StructureDefinition-hcpd-location.md) and [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/au.gov.digitalhealth.fhir.hcpd|current/StructureDefinition/StructureDefinition-hcpd-source-identifier.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-hcpd-source-identifier.csv), [Excel](StructureDefinition-hcpd-source-identifier.xlsx), [Schematron](StructureDefinition-hcpd-source-identifier.sch) 

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "hcpd-source-identifier",
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-source-identifier",
  "version" : "26.0.0",
  "name" : "HCPD_Source_Identifier",
  "title" : "HCPD Source Identifier (HCPD-SI)",
  "status" : "active",
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "This profile of Identifier defines a HCPD Source Identifier (HCPD-SI).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "Copyright © 2025 Australian Digital Health Agency - All rights reserved. This content is licensed under a Creative Commons Attribution 4.0 International License. See https://creativecommons.org/licenses/by/4.0/.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "type" : "Identifier",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Identifier|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Identifier",
      "path" : "Identifier",
      "short" : "HCPD Source Identifier (HCPD-SI)",
      "definition" : "The HCPD Source Identifier (HCPD-SI) is issued by the source of data ingestion and then respected by each HCPD instance."
    },
    {
      "id" : "Identifier.type",
      "path" : "Identifier.type",
      "short" : "Coded identifier type for HCPD Source identifier",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "RI"
        }]
      }
    },
    {
      "id" : "Identifier.system",
      "path" : "Identifier.system",
      "short" : "HCPD Source Identifier system. Not fixed to receive individual source systems.",
      "definition" : "Canonical system for HCPD Source Identifiers (HCPD-SI).",
      "min" : 1
    },
    {
      "id" : "Identifier.value",
      "path" : "Identifier.value",
      "short" : "Vendor Directory Identifier",
      "min" : 1
    }]
  }
}

```
