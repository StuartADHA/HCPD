# HCPD PractitionerRole Example: Ahpra-Only General Practitioner (Balmain) - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD PractitionerRole Example: Ahpra-Only General Practitioner (Balmain)**

## Example PractitionerRole: HCPD PractitionerRole Example: Ahpra-Only General Practitioner (Balmain)

Last updated: 2026-01-29 00:00:00+0000

Profile: [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md)

Alice Anderson (National provider identifier: 8003619900015717): General practitioner at null (National Organisation Identifier: 8003626566707032) (Resource identifier: PR-PCA-009875)

-------

| | | | |
| :--- | :--- | :--- | :--- |
| Active: | true | Valid Period: | 2024-07-01 --> 2027-06-30 |
| Practitioner: | [Alice Anderson (National provider identifier: 8003619900015717)](Practitioner-example-balmain-practitioner-1.md) | | |
| Organization: | [null (National Organisation Identifier: 8003626566707032)](Organization-example-healthconnect-organization-1.md) | | |
| Role: | General practitioner | | |
| Location: | [Sydney Central Medical Centre (NATA Site Number: Australian National Association of Testing Authorities (NATA) Site Number#165432)](Location-example-healthconnect-medical-centre-location-1.md) | | |
| Healthcare Service: | [Healthcare service with Residential Aged Care service type (Geriatric evaluation and management service) by null (National Organisation Identifier: 8003626566707032) (Resource identifier: HS-PCA-001234)](HealthcareService-example-healthconnect-healthcareservice-1.md) | | |
| Other Ids: | * Organization identifier/a2c71f90-3b8e-4c1d-9f65-2d7890abcdef
* Australian Health Practitioner Regulation Agency Registration Number/MED0001111111
 | | |
| Contact Detail | ph: 0298765432(Work) | | |
| Availability: | * Tuesday: 08:30:00 - 17:00:00
* Thursday: 08:30:00 - 17:00:00
* Friday: 08:30:00 - 12:30:00
* Not available: Annual leave — not available over Christmas/New Year period (2026-12-22 --> 2027-01-09)
 | | |
| Endpoint: | [Sydney Private Clinic – FHIR Referral Endpoint (HL7 FHIR (Endpoint Connection Type#hl7-fhir-rest)): https://fhir.sydneyprivateclinic.com.au/fhir](Endpoint-example-hcpd-endpoint-referral.md) | | |
| Suppression Indicator for Visibility: | * suppressedBy: Organisation initiated
 | | |
| [Alternate Name](StructureDefinition-alternate-name.md) | Ali Anderson | | |
| [Practitioner Role Communication](StructureDefinition-practitioner-role-communication.md) | English | | |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "PractitionerRole",
  "id" : "example-healthconnect-practitionerrole-2",
  "meta" : {
    "lastUpdated" : "2026-01-29T00:00:00Z",
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitionerrole"]
  },
  "extension" : [{
    "extension" : [{
      "url" : "suppressedBy",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
          "code" : "organisation-initiated"
        }]
      }
    }],
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed"
  },
  {
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/practitioner-role-communication",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "urn:ietf:bcp:47",
        "code" : "en",
        "display" : "English"
      },
      {
        "system" : "urn:ietf:bcp:47",
        "code" : "zh",
        "display" : "Chinese"
      }]
    }
  },
  {
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/alternate-name",
    "valueHumanName" : {
      "use" : "usual",
      "family" : "Anderson",
      "given" : ["Ali"]
    }
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "RI"
      }]
    },
    "system" : "http://ns.electronichealth.net.au/id/source/pca",
    "value" : "PR-PCA-009875"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "XX",
        "display" : "Organization identifier"
      }]
    },
    "system" : "http://digitalhealth.gov.au/fhir/hcpd/id/hcpd-local-identifier",
    "value" : "a2c71f90-3b8e-4c1d-9f65-2d7890abcdef"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org.au/CodeSystem/v2-0203",
        "code" : "AHPRA"
      }]
    },
    "system" : "http://hl7.org.au/id/ahpra-registration-number",
    "value" : "MED0001111111"
  }],
  "active" : true,
  "period" : {
    "start" : "2024-07-01",
    "end" : "2027-06-30"
  },
  "practitioner" : {
    "reference" : "Practitioner/example-balmain-practitioner-1"
  },
  "organization" : {
    "reference" : "Organization/example-healthconnect-organization-1"
  },
  "code" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "62247001",
      "display" : "General practitioner"
    }]
  }],
  "location" : [{
    "reference" : "Location/example-healthconnect-medical-centre-location-1"
  }],
  "healthcareService" : [{
    "reference" : "HealthcareService/example-healthconnect-healthcareservice-1"
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "0298765432",
    "use" : "work"
  }],
  "availableTime" : [{
    "daysOfWeek" : ["tue"],
    "allDay" : false,
    "availableStartTime" : "08:30:00",
    "_availableStartTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    },
    "availableEndTime" : "17:00:00",
    "_availableEndTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    }
  },
  {
    "daysOfWeek" : ["thu"],
    "allDay" : false,
    "availableStartTime" : "08:30:00",
    "_availableStartTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    },
    "availableEndTime" : "17:00:00",
    "_availableEndTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    }
  },
  {
    "daysOfWeek" : ["fri"],
    "allDay" : false,
    "availableStartTime" : "08:30:00",
    "_availableStartTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    },
    "availableEndTime" : "12:30:00",
    "_availableEndTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    }
  }],
  "notAvailable" : [{
    "description" : "Annual leave — not available over Christmas/New Year period",
    "during" : {
      "start" : "2026-12-22",
      "end" : "2027-01-09"
    }
  }],
  "endpoint" : [{
    "reference" : "Endpoint/example-hcpd-endpoint-referral"
  }]
}

```
