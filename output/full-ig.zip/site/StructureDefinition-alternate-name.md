# Alternate Name - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **Alternate Name**

## Extension: Alternate Name 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/cc/StructureDefinition/alternate-name | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:Alternate_Name |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

This extension applies to PractitionerRole, and represents a name by which a practitioner chooses to be known in the context of the delivery of a specific healthcare service.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md)
* Examples for this Extension: [PractitionerRole/example-healthconnect-practitionerrole-1](PractitionerRole-example-healthconnect-practitionerrole-1.md) and [PractitionerRole/example-healthconnect-practitionerrole-2](PractitionerRole-example-healthconnect-practitionerrole-2.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/au.gov.digitalhealth.fhir.hcpd|current/StructureDefinition/StructureDefinition-alternate-name.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-alternate-name.csv), [Excel](StructureDefinition-alternate-name.xlsx), [Schematron](StructureDefinition-alternate-name.sch) 

#### Terminology Bindings

#### Constraints

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "alternate-name",
  "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/alternate-name",
  "version" : "26.0.0",
  "name" : "Alternate_Name",
  "title" : "Alternate Name",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "This extension applies to PractitionerRole, and represents a name by which a practitioner chooses to be known in the context of the delivery of a specific healthcare service.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "PractitionerRole"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Alternate name for practitioner in role context",
      "definition" : "A name by which a practitioner chooses to be known in the context of the delivery of a specific healthcare service. This may differ from their registered legal name."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/alternate-name"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "short" : "Alternate name",
      "definition" : "The alternate name by which the practitioner wishes to be known in this role context.",
      "min" : 1,
      "type" : [{
        "code" : "HumanName"
      }]
    },
    {
      "id" : "Extension.value[x].use",
      "path" : "Extension.value[x].use",
      "mustSupport" : true
    },
    {
      "id" : "Extension.value[x].family",
      "path" : "Extension.value[x].family",
      "mustSupport" : true
    },
    {
      "id" : "Extension.value[x].given",
      "path" : "Extension.value[x].given",
      "mustSupport" : true
    }]
  }
}

```
