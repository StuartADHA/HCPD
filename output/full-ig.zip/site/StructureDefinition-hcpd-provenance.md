# HCPD Provenance - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Provenance**

## Resource Profile: HCPD Provenance 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-provenance | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:HCPD_Provenance |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

 
This profile of Provenance is used to track activities related to provider directory data, recording when specific data elements of a HCPD Organization or HCPD Practitioner resource have been retrieved, updated or verified. 

No data is entered directly into Health Connect; all Directory content is sourced from authoritative systems including [PCA](https://developer.digitalhealth.gov.au/fhir/provider-connect-australia/current/index.html?src=/), HI-Service, and NHSD.

### Extensions

Extensions introduced in this profile:

* Provenance.target: [Target path](http://hl7.org/fhir/extensions/StructureDefinition-targetPath.html)

### Usage notes

The guidance below is organised by system role to clarify the different responsibilities for systems that create provenance records versus those that consume them.

#### Provenance resource utilisation patterns

The HCPD Provenance profile supports two distinct patterns of use:

**Resource-level provenance** tracks changes to an entire FHIR resource. In this pattern:

* The `target` element references the complete resource that was created, updated, or verified (constrained to HCPD profile types: HCPD_Organization, HCPD_Practitioner, etc.)
* The `activity` element categorizes the type of operation using codes from the Provenance Activity Type value set (CREATE, UPDATE, DELETE, VERIFY, etc.)
* The `recorded` element provides a timestamp indicating when the provenance event was recorded by the source system
* The `agent.who` element identifies the actor (organization, practitioner, or system) responsible for performing the activity
* The `entity` element, when present, references source records or systems that provided the data, with entity.role typically set to "source"

**Atomic element-level provenance** tracks changes to specific data elements within a resource. This more granular approach uses the [Target path](http://hl7.org/fhir/extensions/StructureDefinition-targetPath.html) extension (introduced in this profile) to enable precise tracking:

* The `target` element to reference the resource containing the changed elements
* The `target.extension[targetPath]` to specify exactly which data elements were affected using FHIRPath expressions, enabling atomic-level tracking
* Multiple targetPath extensions can be included to track changes to multiple elements in a single provenance record
* The same `activity`, `recorded`, `agent.who`, and `entity` elements as resource-level provenance

The atomic element-level approach is particularly valuable in Health Connect's context where Directory data may be selectively updated from different authoritative sources. For example, a practitioner's contact details might be updated from one source while their qualifications are verified from another, with separate provenance records documenting each specific change.

#### Systems consuming/auditing Provenance resources (searching systems)

* Systems that query or audit Provenance resources can use the FHIRPath expressions in `target.extension[targetPath].valueString` to identify the exact data elements that were changed.
* When building reconciliation tools or audit trails, these FHIRPath expressions reference the changed elements in the target resource. For example, if a provenance record contains `target.extension[targetPath].valueString` = "telecom.where(system='phone').value", the consuming system knows that the practitioner's phone number was updated, and can use this path to highlight the specific changed field in an audit report.
* Note that the FHIRPath identifies which field changed but does not contain the actual values (old or new)
* To see the current value, the consuming system would need to evaluate the FHIRPath against the current target resource.
* When processing audit trails, ensure that FHIRPath expressions are valid and can be successfully evaluated against the referenced target resource.

##### Search include parameters

This implementation supports the following `_include` parameter when searching for Provenance resources:

* `_include=Provenance:target` - Include the target resources (Organization, Location, HealthcareService, PractitionerRole, Practitioner, or Endpoint) that this Provenance resource tracks

This IG also supports the R4 SearchParameters for Provenance, which are detailed [here](https://hl7.org/fhir/R4/provenance.html#search).

##### Example usage

```
GET /Provenance?agent.who=Organization/12345&_include=Provenance:target

```

This query searches for all provenance records where Organization/12345 was the agent performing the activity, and includes the actual resources (practitioners, locations, etc.) whose changes are documented by these provenance records.

**Usages:**

* Examples for this Profile: [Provenance/provenance-practitioner-name-update](Provenance-provenance-practitioner-name-update.md) and [Provenance/provenance-practitioner-phone-update](Provenance-provenance-practitioner-phone-update.md)
* CapabilityStatements using this Profile: [Health Connect Provider Directory Requester](CapabilityStatement-health-connect-provider-directory-requester.md) and [Health Connect Provider Directory Responder](CapabilityStatement-health-connect-provider-directory-responder.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/au.gov.digitalhealth.fhir.hcpd|current/StructureDefinition/StructureDefinition-hcpd-provenance.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-hcpd-provenance.csv), [Excel](StructureDefinition-hcpd-provenance.xlsx), [Schematron](StructureDefinition-hcpd-provenance.sch) 

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "hcpd-provenance",
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-provenance",
  "version" : "26.0.0",
  "name" : "HCPD_Provenance",
  "title" : "HCPD Provenance",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "This profile of Provenance is used to track activities related to provider directory data, recording when specific data elements of a HCPD Organization or HCPD Practitioner resource have been retrieved, updated or verified.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w3c.prov",
    "uri" : "http://www.w3.org/ns/prov",
    "name" : "W3C PROV"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "fhirauditevent",
    "uri" : "http://hl7.org/fhir/auditevent",
    "name" : "FHIR AuditEvent Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Provenance",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Provenance|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Provenance",
      "path" : "Provenance",
      "short" : "Tracks activities related to provider directory data changes",
      "definition" : "Tracks activities related to provider directory data, recording when specific data elements of a HCPD Organization or HCPD Practitioner resource have been retrieved, updated or verified."
    },
    {
      "id" : "Provenance.target",
      "path" : "Provenance.target",
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-organization|26.0.0",
        "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitioner|26.0.0",
        "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitionerrole|26.0.0",
        "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-endpoint|26.0.0",
        "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-healthcareservice|26.0.0",
        "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Provenance.target.extension:targetPath",
      "path" : "Provenance.target.extension",
      "sliceName" : "targetPath",
      "short" : "FHIRPath of element(s) in the target resource affected by this provenance activity",
      "definition" : "Specifies one or more FHIRPath expressions pointing to the exact data element(s) within the referenced target resource that were sourced / updated / verified in this provenance event.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/targetPath|5.3.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Provenance.target.extension:targetPath.value[x]",
      "path" : "Provenance.target.extension.value[x]",
      "example" : [{
        "label" : "Example",
        "valueString" : "telecom.where(system='phone').value"
      }]
    },
    {
      "id" : "Provenance.recorded",
      "path" : "Provenance.recorded",
      "mustSupport" : true
    },
    {
      "id" : "Provenance.activity",
      "path" : "Provenance.activity",
      "short" : "Type of provenance activity (e.g. create, update, verify)",
      "definition" : "Categorises the provenance event. Required and bound to the Provenance Activity Type value set.",
      "mustSupport" : true,
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://hl7.org/fhir/ValueSet/provenance-activity-type|4.0.1"
      }
    },
    {
      "id" : "Provenance.agent.who",
      "path" : "Provenance.agent.who",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-organization|26.0.0",
        "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitioner|26.0.0",
        "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitionerrole|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Provenance.entity",
      "path" : "Provenance.entity",
      "mustSupport" : true
    },
    {
      "id" : "Provenance.entity.role",
      "path" : "Provenance.entity.role",
      "patternCode" : "source",
      "mustSupport" : true
    }]
  }
}

```
