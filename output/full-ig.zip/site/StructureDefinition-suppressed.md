# Suppression Indicator for Visibility - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **Suppression Indicator for Visibility**

## Extension: Suppression Indicator for Visibility 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:Suppressed |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

Indicates whether the parent resource should be hidden from display in the Provider Directory. Contains coded information about the actor who initiated the suppression and optional control flags.

This extension addresses the business requirement to control visibility of provider directory entries, enabling management of which practitioner roles, organizations, healthcare services, locations, or endpoints should be hidden from public directory searches while maintaining data in the system.

**Context of Use**

## Usage notes

This extension is used to convey whether the parent resource should be hidden from display in the Provider Directory. It carries coded information about the actor who initiated the suppression.

### Datatype and context

The Suppressed extension is a complex extension that contains information about suppression behaviour. It includes a required `suppressedBy` sub-extension (CodeableConcept) that indicates who initiated the suppression request. The coded values are drawn from the [HCPD Responsible Party Type CodeSystem](CodeSystem-responsible-party-type.md), and the extension also includes an optional `includeSelf` sub-extension (boolean) for Organization-specific behaviour.

This extension is profiled on the following HCPD resources: Organization, Practitioner, PractitionerRole, HealthcareService, Location, and Endpoint.

* Being an optional cardinality, when absent the resource is visible in Provider Directory listings
* When present, it indicates the resource is suppressed and identifies who initiated the suppression
* For Organization resources, the Suppressed extension includes an `includeSelf` sub-extension that controls whether the Organization itself is suppressed in addition to cascade suppression of child resources

### Suppression scenarios

This extension enables several suppression patterns:

1. **Practitioner self-suppression**:
* Practitioner with Suppressed extension (practitioner-initiated) automatically hides themselves and cascades to suppress all their roles

1. **Organization suppression with cascade control**:
* Organization with Suppressed extension (organisation-initiated) triggers cascade suppression to all child resources
* The nested `includeSelf` sub-extension controls whether the Organization itself is also hidden: 
* When true: Organization hides itself and automatically cascades to suppress everything related (locations, services, etc.)
* When false or missing: Organization remains visible in Provider Directory listings
 

1. **PractitionerRole specific suppression**:
* PractitionerRole with Suppressed extension is hidden without affecting the Practitioner profile
* Can be initiated by either practitioner-initiated or organisation-initiated codes

### Processing and client obligations

* The default state of this extension, being optional, is that it is not present on a profile and that resource is visible.
* When present, the Suppressed extension indicates the resource should be suppressed from Provider Directory listings.
* For Organization profiles, the nested `includeSelf` sub-extension controls whether the Organization itself is suppressed in addition to cascade suppression of child resources.
* Suppressed resources remain stored in the internal Health Connect Provider Directory system but are excluded from the external IG and API responses.
* Downstream vendors no longer receive the resources in API payloads but must still handle the consequences of suppression (i.e., missing expected resources).
* Client requester actors of the bulk data export service may receive suppressed resources when the client uses the `_since` parameter in their bulk export request.
* Client requester actors **SHALL** be required to cleanse their local systems of suppressed resources using the related identifiers.

### Hierarchical suppression model

The HCPD Provider Directory operates on a hierarchical model where certain resources are considered children of others. This hierarchy determines the cascading behaviour of suppression and which initiator codes are permitted on each resource type.

**Suppression cascade:**

* **Organization** (parent) → HealthcareService, Location, PractitionerRole, Endpoint (children) 
* When the Suppressed extension is present on an Organization, suppression automatically cascades to its child HealthcareService, Location, PractitionerRole, and Endpoint resources
 

The coded values in Suppressed indicate who has the authority to suppress a resource, with some resources having competing authorities due to their position in the hierarchy.

| | | | |
| :--- | :--- | :--- | :--- |
| Organization | ✓ | ✗ | ✗ |
| HealthcareService | ✓ | ✓ | ✗ |
| Location | ✓ | ✓ | ✗ |
| Endpoint | ✓ | ✓ | ✗ |
| PractitionerRole | ✓ | ✓ | ✓ |
| Practitioner | ✗ | ✗ | ✓ |

**Usage info**

**Usages:**

* Use this Extension: [HCPD Endpoint](StructureDefinition-hcpd-endpoint.md), [HCPD HealthcareService](StructureDefinition-hcpd-healthcareservice.md), [HCPD Location](StructureDefinition-hcpd-location.md), [HCPD Organization](StructureDefinition-hcpd-organization.md)... Show 3 more, [HCPD Practitioner](StructureDefinition-hcpd-practitioner.md), [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md) and [HCPD Service Coverage Area](StructureDefinition-hcpd-service-coverage-area.md)
* Examples for this Extension: [Sydney General Hospital FHIR Messaging Endpoint](Endpoint-example-hcpd-endpoint-hl7-fhir-messaging.md), [Sydney Private Clinic – FHIR Referral Endpoint](Endpoint-example-hcpd-endpoint-referral.md), [Northside Community Health Centre – General Practice & Aged Care](HealthcareService-example-healthconnect-healthcareservice-2.md), [Sydney Central Medical Centre](Location-example-healthconnect-medical-centre-location-1.md)... Show 7 more, [Sydney CBD Mobile Unit Service Area](Location-example-healthconnect-mobile-unit-coverage-area-1.md), [Balmain Service Coverage Area](Location-example-healthconnect-service-coverage-area-balmain-1.md), [Organization/example-healthconnect-organization-1](Organization-example-healthconnect-organization-1.md), [Practitioner/example-balmain-practitioner-1](Practitioner-example-balmain-practitioner-1.md), [Practitioner/example-healthconnect-practitioner-1](Practitioner-example-healthconnect-practitioner-1.md), [Practitioner/external-hcpd-practitioner-record](Practitioner-external-hcpd-practitioner-record.md) and [PractitionerRole/example-healthconnect-practitionerrole-2](PractitionerRole-example-healthconnect-practitionerrole-2.md)
* Search Parameters using this Extension: [SearchParameterSuppressed](SearchParameter-suppressed.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/au.gov.digitalhealth.fhir.hcpd|current/StructureDefinition/StructureDefinition-suppressed.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-suppressed.csv), [Excel](StructureDefinition-suppressed.xlsx), [Schematron](StructureDefinition-suppressed.sch) 

#### Terminology Bindings

#### Constraints

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "suppressed",
  "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed",
  "version" : "26.0.0",
  "name" : "Suppressed",
  "title" : "Suppression Indicator for Visibility",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "Indicates whether the parent resource should be hidden from display in the Provider Directory. Contains coded information about the actor who initiated the suppression and optional control flags.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "purpose" : "This extension addresses the business requirement to control visibility of provider directory entries, enabling management of which practitioner roles, organizations, healthcare services, locations, or endpoints should be hidden from public directory searches while maintaining data in the system.",
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "PractitionerRole"
  },
  {
    "type" : "element",
    "expression" : "Organization"
  },
  {
    "type" : "element",
    "expression" : "Practitioner"
  },
  {
    "type" : "element",
    "expression" : "HealthcareService"
  },
  {
    "type" : "element",
    "expression" : "Location"
  },
  {
    "type" : "element",
    "expression" : "Endpoint"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Hide Resource in Directory",
      "definition" : "When present, indicates that the parent resource is suppressed. Contains information about who initiated the suppression and optional control flags for suppression behavior.",
      "max" : "1"
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "min" : 1
    },
    {
      "id" : "Extension.extension:suppressedBy",
      "path" : "Extension.extension",
      "sliceName" : "suppressedBy",
      "short" : "Who initiated the suppression",
      "definition" : "Identifies the actor who initiated the suppression request (e.g., practitioner, organisation).",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Extension.extension:suppressedBy.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:suppressedBy.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "suppressedBy"
    },
    {
      "id" : "Extension.extension:suppressedBy.value[x]",
      "path" : "Extension.extension.value[x]",
      "min" : 1,
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Extension.extension:suppressedBy.value[x].coding",
      "path" : "Extension.extension.value[x].coding",
      "min" : 1,
      "max" : "2",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://digitalhealth.gov.au/fhir/cc/ValueSet/responsible-party-type|26.0.0"
      }
    },
    {
      "id" : "Extension.extension:includeSelf",
      "path" : "Extension.extension",
      "sliceName" : "includeSelf",
      "short" : "Controls Organization self-suppression",
      "definition" : "When true, this Organization and all child resources (HealthcareService, Location, PractitionerRole, Endpoint) are suppressed via cascade. When false, this Organization remains visible while child resources are suppressed via cascade. Only applies to Organization resources.",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Extension.extension:includeSelf.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:includeSelf.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "includeSelf"
    },
    {
      "id" : "Extension.extension:includeSelf.value[x]",
      "path" : "Extension.extension.value[x]",
      "type" : [{
        "code" : "boolean"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "max" : "0"
    }]
  }
}

```
