# HCPD Organization Example: Aged Care Facility - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Organization Example: Aged Care Facility**

## Example Organization: HCPD Organization Example: Aged Care Facility

Last updated: 2025-08-30 09:15:00+0000

Profile: [HCPD Organization](StructureDefinition-hcpd-organization.md)

null (National Organisation Identifier: 8003626566707032)

-------

| | |
| :--- | :--- |
| Active: | true |
| Alias: | Ye old Example Aged Care |
| Other Ids: | * ABN/41824753556
* ACN/123456789
 |
| Contact Detail | * ph: (03) 5550 4075(Work)
* ph: (03) 5550 4076(Work)
* [reception@example.com.au](mailto:reception@example.com.au)
* [admin@example.com.au](mailto:admin@example.com.au)
* [https://www.example.com/mocklocation](https://www.example.com/mocklocation)
* fax: +61 2 6666 7777(Work)
* 175 Liverpool Street Sydney NSW 2000 AU 
 |
| Suppression Indicator for Visibility: | * suppressedBy: Organisation initiated
* includeSelf: true
 |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "example-healthconnect-organization-1",
  "meta" : {
    "lastUpdated" : "2025-08-30T09:15:00Z",
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-organization"]
  },
  "extension" : [{
    "extension" : [{
      "url" : "suppressedBy",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
          "code" : "organisation-initiated"
        }]
      }
    },
    {
      "url" : "includeSelf",
      "valueBoolean" : true
    }],
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed"
  }],
  "identifier" : [{
    "extension" : [{
      "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-services-identifier-status",
      "valueCoding" : {
        "system" : "http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/hi-services-identifier-status-cs",
        "code" : "A",
        "display" : "Active"
      }
    },
    {
      "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-org-classification",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/hi-org-classification-cs",
          "code" : "network",
          "display" : "Network"
        }]
      }
    }],
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org.au/CodeSystem/v2-0203",
        "code" : "NOI"
      }]
    },
    "system" : "http://ns.electronichealth.net.au/id/hi/hpio/1.0",
    "value" : "8003626566707032"
  },
  {
    "type" : {
      "text" : "ABN"
    },
    "system" : "http://hl7.org.au/id/abn",
    "value" : "41824753556"
  },
  {
    "type" : {
      "text" : "ACN"
    },
    "system" : "http://hl7.org.au/id/acn",
    "value" : "123456789"
  }],
  "active" : true,
  "_name" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
      "valueCode" : "masked"
    }]
  },
  "alias" : ["Ye old Example Aged Care"],
  "telecom" : [{
    "system" : "phone",
    "value" : "(03) 5550 4075",
    "use" : "work"
  },
  {
    "system" : "phone",
    "value" : "(03) 5550 4076",
    "use" : "work"
  },
  {
    "system" : "email",
    "value" : "reception@example.com.au",
    "use" : "work"
  },
  {
    "system" : "email",
    "value" : "admin@example.com.au",
    "use" : "work"
  },
  {
    "system" : "url",
    "value" : "https://www.example.com/mocklocation",
    "use" : "work"
  },
  {
    "system" : "fax",
    "value" : "+61 2 6666 7777",
    "use" : "work"
  }],
  "address" : [{
    "type" : "physical",
    "line" : ["175 Liverpool Street"],
    "city" : "Sydney",
    "state" : "NSW",
    "postalCode" : "2000",
    "country" : "AU"
  }]
}

```
