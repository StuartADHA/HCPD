# HCPD Export Request Parameters Example: Cardiology Services in Balmain - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Export Request Parameters Example: Cardiology Services in Balmain**

## Example Parameters: HCPD Export Request Parameters Example: Cardiology Services in Balmain

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "example-hcpd-export-request-parameters-1",
  "meta" : {
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-export-request-parameters"]
  },
  "parameter" : [{
    "name" : "_outputFormat",
    "valueString" : "application/fhir+ndjson"
  },
  {
    "name" : "_type",
    "valueString" : "Location,HealthcareService,Organization,PractitionerRole,Practitioner"
  },
  {
    "name" : "_typeFilter",
    "valueString" : "Location?address-city=Balmain&address-postalcode=2041&near=-33.8607|151.1803|100"
  },
  {
    "name" : "_typeFilter",
    "valueString" : "HealthcareService?service-type=http://snomed.info/sct|789718008&location.address-city=Balmain&location.address-postalcode=2041"
  },
  {
    "name" : "_typeFilter",
    "valueString" : "Organization?_has:HealthcareService:organization:service-type=http://snomed.info/sct|789718008"
  },
  {
    "name" : "_typeFilter",
    "valueString" : "PractitionerRole?location.address-city=Balmain&location.address-postalcode=2041"
  },
  {
    "name" : "_typeFilter",
    "valueString" : "Practitioner?_has:PractitionerRole:practitioner:location.address-city=Balmain"
  }]
}

```
