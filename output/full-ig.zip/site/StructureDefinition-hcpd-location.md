# HCPD Location - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Location**

## Resource Profile: HCPD Location 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:HCPD_Location |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

 
This profile defines a Health Connect Provider Directory entry for a healthcare location where services are provided. 

 
This profile addresses the business need to standardise location information in the Health Connect Provider Directory, enabling consistent representation of physical, mobile, and virtual healthcare service delivery sites for directory search and service location purposes. 

No data is entered directly into Health Connect; all Directory content is sourced from authoritative systems including [PCA](https://developer.digitalhealth.gov.au/fhir/provider-connect-australia/current/index.html?src=/), HI-Service, and NHSD.

### Extensions

Extensions introduced in this profile:

* Location: [Amenity](StructureDefinition-amenity.md)
* Location: [HCPD Alternate Postal Address](StructureDefinition-hcpd-alternate-postal-address.md)
* Location: [Suppressed](StructureDefinition-suppressed.md)
* Location: [Deactivated](StructureDefinition-deactivated.md)

### Visibility and Suppression

The HCPD Location profile supports the [Suppressed](StructureDefinition-suppressed.md) extension, however its application is conceptually driven by organizational visibility decisions. When an [HCPD Organization](StructureDefinition-hcpd-organization.md) elects to hide their visibility from those searching the Health Connect Provider Directory system by applying the suppressed extension with an `organisation-initiated` code, all associated Location resources are automatically suppressed and excluded from Provider Directory listings. This cascading suppression ensures that when an organization chooses to hide their visibility, related locations "come for the ride" and are similarly hidden from display, maintaining consistency across the directory.

### Usage notes

Publishing guidance:

A HC Location resource may also have additional identifiers specific to other business partners, and their identifier systems may or may not match other identifier slices defined in [AU Core Location](https://build.fhir.org/ig/hl7au/au-fhir-core/StructureDefinition-au-core-location.html).

#### Identifiers

Beyond the identifiers already defined in AU Core the HC Location profile explicitly supports the following identifier slice (as indicated by the must support flag):

* [HCPD Local Identifier (hcpd-LI)](StructureDefinition-hcpd-local-identifier.md) - Unique identifier attributed by the HCPD system.

#### Type

The usage notes of the AU Base Location profile provide guidance for Locations that may form part of defining a mobile or remotely delivered service. The HCPD Location profile formalises this guidance as mandatory requirements (via invariants). The requirements are summarised below:

A HCPD Location for a mobile service **shall** have:

* type=’MOBL’ plus at least one of the following codes: 'PTRES', 'SCHOOL', 'WORK', 'COMM' or 'AMB', to further qualify where the mobile service is offered.

A HCPD Location for a virtually delivered service **shall** have:

* type=’VI’

##### PhysicalType

When a Location is to be represented as a physical type, the `physicalType` element is used to carry an applicable code from the [Location Type (Physical) - AU Extended ValueSet](https://hl7.org.au/fhir/6.0.0-ballot/ValueSet-au-location-physical-type-extended.html).

The `physicalType` element can be used to express more specific details about the physical nature of a Location (for example: ward, building, dwelling).

#### Organization reference

The **managingOrganization** element must contain a relative reference to an existing [HC Organization](StructureDefinition-hcpd-organization.md).

#### Invariants

##### Invariant: hcpd-alternate-postal-address

Description: If the alternate postal address extension is present on an address then that address must be of type 'postal'.

Implementation note: The profile enforces this rule so that the `hcpd-alternate-postal-address` extension is only used to carry postal/mailing addresses (for example PO Boxes). Publishing systems SHOULD only set the extension on addresses whose `type` is `postal`.

##### Invariant: inv-01-address-requirement

Description: If a location's `type` is `VI` or `MOBL` then an address does not need to be present. For all other location types an `address` MUST be present.

Implementation note: This invariant ensures that physical locations provide a postal/physical address, while virtual or mobile services (for example telehealth, mobile clinics, ambulance services) may omit a fixed address.

##### Invariant: inv-02-type-mobl-requires-modifier

Description: If a location's `type` includes the `MOBL` code then it is recommended that an additional modifier coding is provided to describe the mobile service (either `PTRES`, `SCHOOL`, `WORK`, `COMM`, `AMB`) but not `VI`.

Implementation note: This rule is a **warning** - it does not block publishing but encourages publishers to provide additional context about where the mobile service operates. Implementers should supply a secondary `type.coding` entry when describing mobile services to improve discoverability.

##### Invariant: inv-03-type-vi-should-not-have-modifier

Description: If a location's `type` includes the `VI` code then no additional modifier codings should be present.

Implementation note: This rule is a **warning** - virtual locations should be clearly identified as virtual-only and not include additional modifiers that suggest physical or mobile subtypes. If a virtual service also has a physical component, model those as separate Location resources.

##### Invariant: inv-04-type-or-physicaltype-present

Description: A Location resource MUST include either a `type` or a `physicalType` element.

Implementation note: This rule is enforced as an error - every Location must be classified either by `type` (logical role such as `MOBL`, `VI`, etc.) or by `physicalType` (when the Location represents a specific physical characteristic). Implementers MUST populate at least one of these elements when creating Location resources.

##### Invariant: inv-05-status-values

Description: Location.`status` must be `active` or `inactive`. The `suspended` status is not used in HCPD.

Implementation note: This rule is enforced as an error - HCPD only recognises active and inactive states for a Location. Publishing systems MUST NOT set `status` to `suspended`. When a Location is no longer available it should be set to `inactive`.

**Usages:**

* Refer to this Profile: [HCPD HealthcareService](StructureDefinition-hcpd-healthcareservice.md), [HCPD Location](StructureDefinition-hcpd-location.md), [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md) and [HCPD Provenance](StructureDefinition-hcpd-provenance.md)
* Examples for this Profile: [Sydney Central Medical Centre](Location-example-healthconnect-medical-centre-location-1.md), [Mobile Healthcare Unit - Sydney CBD](Location-example-healthconnect-mobile-healthcare-unit-1.md), [Sydney CBD Mobile Unit Service Area](Location-example-healthconnect-mobile-unit-coverage-area-1.md) and [Virtual Telehealth Service](Location-example-healthconnect-virtual-telehealth-service-1.md)
* CapabilityStatements using this Profile: [Health Connect Provider Directory Requester](CapabilityStatement-health-connect-provider-directory-requester.md) and [Health Connect Provider Directory Responder](CapabilityStatement-health-connect-provider-directory-responder.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/au.gov.digitalhealth.fhir.hcpd|current/StructureDefinition/StructureDefinition-hcpd-location.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-hcpd-location.csv), [Excel](StructureDefinition-hcpd-location.xlsx), [Schematron](StructureDefinition-hcpd-location.sch) 

### Notes:

### Search parameters

This IG defines and introduces several search parameters in addition to those inherited from R4, that make it easier to find and filter `HC Location` resources in Health Connect implementations.

#### Search parameters defined in this IG

The following search parameters are **defined by this IG** and **SHOULD** be supported:

* [`locmailaddress`](SearchParameter-location-locmailaddress.md) (Location.extension where url = HC preferred postal address extension). Supports `:contains` modifier. 
* Search locations by the hcpd-preferred postal address stored in the location's hcpd-specific extension.
* Example (string-only): `GET /Location?locmailaddress=PO%20Box%20123`
 
* [`locationamenities`](SearchParameter-location-amenities.md) (Location.extension where url = HC amenity extension) 
* Search for locations by their amenities using the HC amenity extension. Use token semantics for coded amenity values.
* Example (display text): `GET /Location?locationamenities=WheelchairAccess`
 
* [`locationphysicaltype`](SearchParameter-location-physicaltype.md) (Location.physicalType) 
* Search for locations by their physicalType field. Use token semantics for coded physical type values from the Location Type (Physical) ValueSet.
* Example: `GET /Location?locationphysicaltype=http://terminology.hl7.org/CodeSystem/location-physical-type|wa`
 
* [`suppressed`](SearchParameter-suppressed.md) (Location.extension where url = suppressedBy extension) 
* Search for locations by their suppression status. Use token semantics with a code from the [Responsible Party Type CodeSystem](CodeSystem-responsible-party-type.md).
* Example (system|code): `GET /Location?suppressed=http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type|practitioner-initiated`
* Example (code only): `GET /Location?suppressed=practitioner-initiated`
* Example (system only): `GET /Location?suppressed=http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type|`
 

#### Search parameters from R4

The following search parameters are **inherited from FHIR R4** and have been deemed useful for implementation within this IG. They **SHOULD** be supported:

* [`name (R4)`](https://hl7.org/fhir/R4/searchparameter-registry.html#name) (Location.name and Location.alias) 
* Search for locations by name and alias (partial searches supported).
* Example: `GET /Location?name:contains=Telehealth`
 
* [`address (R4)`](https://hl7.org/fhir/R4/searchparameter-registry.html#address) (Location.address) 
* Search for locations by address (partial searches supported).
* Example: `GET /Location?address=147-153%20Castlereagh%20Street`
 
* [`type (R4)`](https://hl7.org/fhir/R4/searchparameter-registry.html#type) (Location.type.coding) 
* Search for locations by their type using coded values. Use token semantics for precise code matching.
* Available codes = MOBL, PTRES, SCHOOL, WORK, COMM, AMB, VI from the NCTS Delivery Location Role Type ValueSet
* Example (code only): `GET /Location?type=MOBL`
 
* [`near`](https://hl7.org/fhir/R4/location.html#positional) (Location.position) 
*  

| | | |
| :--- | :--- | :--- |
| Search for locations by geographical proximity using latitude | longitude | distance format. |

 
* Results can be sorted by distance using the `_sort` parameter. Documented [here](https://hapifhir.io/hapi-fhir/docs/introduction/changelog_2023.html#section11) under GitHub issue [#4650](https://github.com/hapifhir/hapi-fhir/issues/4650).
* Sort modifiers: `_sort=near` (closest first), `_sort=-near` (furthest first).
* Example: `GET /Location?near=-33.8688|151.2093|0.5` (within 0.5km of Sydney CBD coordinates)
* Example with sorting: `GET /Location?near=-33.8688|151.2093|3&_sort=near` (closest locations first within 3km)
 
* [`status`](https://hl7.org/fhir/R4/location.html#search) 
* For HC Location records, implementers SHALL use only the following `Location.status` values: `active` or `inactive`. The `suspended` status is not used in HCPD.
* Example: `GET /Location?status=active`


  **Note:** Adding `?status=inactive` records that are inactive. Implementers should be aware that returned results MAY include records marked for suppression; it is the responsibility of the implementer that suppressed records SHALL be filtered out before display.
 

Implementation note: `Location.status` values are constrained to `active` or `inactive` only. The `suspended` status is not used in HCPD.

**Note:** Support for _id is mandatory for a responder and optional for a requester. Where the expectation for a search parameter differs between actors, the table below will reflect the stronger conformance requirement.

* Parameter(s): _id
  * Conformance: **SHOULD**
  * Type(s): `token`
  * Requirements (when used alone or in combination): 
* Parameter(s): name (R4)
  * Conformance: **SHOULD**
  * Type(s): `string`
  * Requirements (when used alone or in combination): 
* Parameter(s): address (R4)
  * Conformance: **SHOULD**
  * Type(s): `string`
  * Requirements (when used alone or in combination): 
* Parameter(s): locmailaddress
  * Conformance: **SHOULD**
  * Type(s): `string`
  * Requirements (when used alone or in combination): 
* Parameter(s): locationamenities
  * Conformance: **SHOULD**
  * Type(s): `token`
  * Requirements (when used alone or in combination): 
* Parameter(s): locationphysicaltype
  * Conformance: **SHOULD**
  * Type(s): `token`
  * Requirements (when used alone or in combination): 
* Parameter(s): suppressed
  * Conformance: **SHOULD**
  * Type(s): `token`
  * Requirements (when used alone or in combination): 
* Parameter(s): type (R4)
  * Conformance: **SHOULD**
  * Type(s): `token`
  * Requirements (when used alone or in combination): 
* Parameter(s): near (R4)
  * Conformance: **SHOULD**
  * Type(s): `special`
  * Requirements (when used alone or in combination): Geographical proximity search using latitude|longitude|distance format. Can be sorted by distance using _sort=near
* Parameter(s): status (R4)
  * Conformance: **SHOULD**
  * Type(s): `token`
  * Requirements (when used alone or in combination): 
* Parameter(s): name+type
  * Conformance: **SHOULD**
  * Type(s): `string`+`token`
  * Requirements (when used alone or in combination): 
* Parameter(s): name+locationphysicaltype
  * Conformance: **SHOULD**
  * Type(s): `string`+`token`
  * Requirements (when used alone or in combination): 
* Parameter(s): name+locationamenities
  * Conformance: **SHOULD**
  * Type(s): `string`+`token`
  * Requirements (when used alone or in combination): 
* Parameter(s): address+type
  * Conformance: **SHOULD**
  * Type(s): `string`+`token`
  * Requirements (when used alone or in combination): 
* Parameter(s): address+locationphysicaltype
  * Conformance: **SHOULD**
  * Type(s): `string`+`token`
  * Requirements (when used alone or in combination): 
* Parameter(s): address+locationamenities
  * Conformance: **SHOULD**
  * Type(s): `string`+`token`
  * Requirements (when used alone or in combination): 
* Parameter(s): locmailaddress+type
  * Conformance: **SHOULD**
  * Type(s): `string`+`token`
  * Requirements (when used alone or in combination): 
* Parameter(s): locmailaddress+locationphysicaltype
  * Conformance: **SHOULD**
  * Type(s): `string`+`token`
  * Requirements (when used alone or in combination): 
* Parameter(s): locmailaddress+locationamenities
  * Conformance: **SHOULD**
  * Type(s): `string`+`token`
  * Requirements (when used alone or in combination): 

### Search include parameters

This implementation supports the following `_include` parameters when searching for Location resources:

* `_include=Location:endpoint` - Include endpoint resources referenced by the `endpoint` element
* `_include=Location:organization` - Include organization resources referenced by the `managingOrganization` element

### Search reverse include parameters

This implementation supports the following `_revinclude` parameters when searching for Location resources:

* `_revinclude=HealthcareService:location` - Include HealthcareService resources that reference this Location
* `_revinclude=Provenance:target` - Include Provenance resources that track changes to this Location

#### Example usage

```
GET /Location/456?_include=Location:endpoint&_revinclude=HealthcareService:location

```

This query returns the Location resource, its associated Endpoints, and all HealthcareServices at this Location.

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "hcpd-location",
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location",
  "version" : "26.0.0",
  "name" : "HCPD_Location",
  "title" : "HCPD Location",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "This profile defines a Health Connect Provider Directory entry for a healthcare location where services are provided.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "purpose" : "This profile addresses the business need to standardise location information in the Health Connect Provider Directory, enabling consistent representation of physical, mobile, and virtual healthcare service delivery sites for directory search and service location purposes.",
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Location",
  "baseDefinition" : "http://hl7.org.au/fhir/core/StructureDefinition/au-core-location|2.0.0",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Location",
      "path" : "Location",
      "short" : "Australian Location Directory Entry",
      "constraint" : [{
        "key" : "inv-01-address-requirement",
        "severity" : "warning",
        "human" : "Physical locations (not virtual or mobile) must have an address present.",
        "expression" : "physicalType.exists() implies address.exists()",
        "source" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
      },
      {
        "key" : "inv-02-type-mobl-requires-modifier",
        "severity" : "warning",
        "human" : "If a location is marked as mobile (code 'MOBL') it is recommended that a modifier coding is provided to describe the mobile type",
        "expression" : "type.coding.where(code = 'MOBL').exists() implies type.coding.where(code = 'COMM' or code = 'AMB' or code = 'PTRES' or code = 'SCHOOL' or code = 'WORK').exists()",
        "source" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
      },
      {
        "key" : "inv-03-type-vi-should-not-have-modifier",
        "severity" : "warning",
        "human" : "If a location is marked as virtual (code 'VI') no additional modifier codings are needed",
        "expression" : "type.coding.where(code = 'VI').exists() implies type.coding.count() = 1",
        "source" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
      },
      {
        "key" : "inv-04-type-or-physicaltype-present",
        "severity" : "error",
        "human" : "A Location MUST have either a `type` or a `physicalType` value present",
        "expression" : "type.exists() or physicalType.exists()",
        "source" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
      },
      {
        "key" : "inv-05-status-values",
        "severity" : "error",
        "human" : "Location.status must be 'active' or 'inactive'. The 'suspended' status is not used in HCPD.",
        "expression" : "status = 'active' or status = 'inactive'",
        "source" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
      }]
    },
    {
      "id" : "Location.meta",
      "path" : "Location.meta",
      "short" : "Metadata on Location"
    },
    {
      "id" : "Location.extension",
      "path" : "Location.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Location.extension:suppressed",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.extension",
      "sliceName" : "suppressed",
      "short" : "Indicates if Location service is suppressed",
      "definition" : "Indicates if Location service is suppressed.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Location.extension:suppressed.extension:suppressedBy",
      "path" : "Location.extension.extension",
      "sliceName" : "suppressedBy"
    },
    {
      "id" : "Location.extension:suppressed.extension:suppressedBy.value[x].coding",
      "path" : "Location.extension.extension.value[x].coding",
      "max" : "1",
      "fixedCoding" : {
        "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
        "code" : "organisation-initiated"
      },
      "mustSupport" : true
    },
    {
      "id" : "Location.extension:amenity",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.extension",
      "sliceName" : "amenity",
      "short" : "Amenities or facilities available at or near the location.",
      "definition" : "Facilities or amenities available within, or in close proximity of, a location. Uses the NCTS Facility Amenity ValueSet (https://healthterminologies.gov.au/fhir/ValueSet/facility-amenity-1).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://digitalhealth.gov.au/fhir/cc/StructureDefinition/amenity|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Location.extension:hcpd-alternate-postal-address",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.extension",
      "sliceName" : "hcpd-alternate-postal-address",
      "short" : "Alternate postal address",
      "definition" : "Alternate postal/mailing address for correspondence (PO Box or mailing address) that is distinct from the registered physical address.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-alternate-postal-address|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Location.extension:deactivated",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:ignore"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:ignore"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.extension",
      "sliceName" : "deactivated",
      "short" : "Indicates if Location service is deactivated",
      "definition" : "When present, this extension marks the Location as deactivated, and deactivation automatically cascades to all child resources.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/deactivated|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Location.extension:deactivated.extension:deactivatedBy",
      "path" : "Location.extension.extension",
      "sliceName" : "deactivatedBy"
    },
    {
      "id" : "Location.extension:deactivated.extension:deactivatedBy.value[x].coding",
      "path" : "Location.extension.extension.value[x].coding",
      "max" : "1",
      "fixedCoding" : {
        "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
        "code" : "organisation-initiated"
      },
      "mustSupport" : true
    },
    {
      "id" : "Location.identifier",
      "path" : "Location.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "type"
        }],
        "description" : "Slice based on identifier system: must include at least one HCPD Location Identifier known to this profile",
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 2,
      "mustSupport" : true
    },
    {
      "id" : "Location.identifier:HCPD_Source_Identifier",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.identifier",
      "sliceName" : "HCPD_Source_Identifier",
      "short" : "Identifier attributed from source system. Source for Location: PCA",
      "definition" : "Unique identifier for the healthcare location attributed from source system. Not exposed externally but can be used for system reference or internal business logic.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-source-identifier|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Location.identifier:HCPD_Local_Identifier",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.identifier",
      "sliceName" : "HCPD_Local_Identifier",
      "short" : "Local Identifier for the location attributed by HC",
      "definition" : "Local Identifier for the Location attributed by Health Connect. Used for system reference and internal business logic.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-local-identifier|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Location.status",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.status",
      "short" : "Used to show if this location is in operation. Only locations with status ‘Active’ are exposed externally and discoverable/visible in the directory.",
      "definition" : "To ensure that only locations with status ‘Active’ are displayed & discoverable externally.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Location.name",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://hl7.org.au/fhir/core/StructureDefinition/au-core-location|2.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.name",
      "min" : 1
    },
    {
      "id" : "Location.alias",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.alias",
      "short" : "Alternative names for the location",
      "definition" : "Other names or aliases by which this location is known, such as abbreviations, former names, or local names.",
      "mustSupport" : true
    },
    {
      "id" : "Location.type",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://hl7.org.au/fhir/core/StructureDefinition/au-core-location|2.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.type",
      "short" : "Indicates whether the location is a virtual location or mobile service.",
      "definition" : "Indicates whether the location is a fixed physical place, virtual location or a mobile service. Used to identify the type of location that meets their patient's needs.",
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://healthterminologies.gov.au/fhir/ValueSet/service-delivery-location-role-type-1"
      }
    },
    {
      "id" : "Location.telecom",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.telecom",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "description" : "Slice based on telecom system: phone, email. Must have at least one of each.",
        "rules" : "open"
      },
      "mustSupport" : true
    },
    {
      "id" : "Location.telecom:phone",
      "path" : "Location.telecom",
      "sliceName" : "phone",
      "short" : "Phone number for the location.",
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Location.telecom:phone.system",
      "path" : "Location.telecom.system",
      "min" : 1,
      "patternCode" : "phone"
    },
    {
      "id" : "Location.telecom:email",
      "path" : "Location.telecom",
      "sliceName" : "email",
      "short" : "Email address for the location.",
      "min" : 0,
      "max" : "*",
      "mustSupport" : true
    },
    {
      "id" : "Location.telecom:email.system",
      "path" : "Location.telecom.system",
      "min" : 1,
      "patternCode" : "email"
    },
    {
      "id" : "Location.address",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://hl7.org.au/fhir/core/StructureDefinition/au-core-location|2.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.address",
      "short" : "Address where the service or practitioner role is located. Virtual and mobile locations may not have a fixed address."
    },
    {
      "id" : "Location.position",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.position",
      "mustSupport" : true
    },
    {
      "id" : "Location.managingOrganization",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://hl7.org.au/fhir/core/StructureDefinition/au-core-location|2.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.managingOrganization",
      "short" : "Reference to managing organisation with HPI-O.",
      "definition" : "A reference to the organisation that holds a HPI-O and manages or is responsible for this location entry in the Provider Directory.",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-organization|26.0.0"]
      }]
    },
    {
      "id" : "Location.partOf",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/snapshot-source",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.partOf",
      "type" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-hierarchy",
          "valueBoolean" : true
        }],
        "code" : "Reference",
        "targetProfile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Location.endpoint",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Location.endpoint",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-endpoint|26.0.0"]
      }],
      "mustSupport" : true
    }]
  }
}

```
