# HI Services Identifier Status Code System - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HI Services Identifier Status Code System**

## CodeSystem: HI Services Identifier Status Code System 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/hi-services-identifier-status-cs | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:HI_Services_Identifier_Status_CS |
| **Copyright/Legal**: Copyright © 2026 Australian Digital Health Agency - All rights reserved. This content is licensed under a Creative Commons Attribution 4.0 International License. See https://creativecommons.org/licenses/by/4.0/. | |

 
This code system defines concepts that identify the status of a Healthcare Services Identifier, i.e. HPII, HPIO or HSPO. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [HI Services Identifier Status Value Set](ValueSet-hi-services-identifier-status-vs.md)

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "hi-services-identifier-status-cs",
  "meta" : {
    "profile" : ["https://healthterminologies.gov.au/fhir/StructureDefinition/complete-code-system-4"]
  },
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/hi-services-identifier-status-cs",
  "version" : "26.0.0",
  "name" : "HI_Services_Identifier_Status_CS",
  "title" : "HI Services Identifier Status Code System",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "This code system defines concepts that identify the status of a Healthcare Services Identifier, i.e. HPII, HPIO or HSPO.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "Copyright © 2026 Australian Digital Health Agency - All rights reserved. This content is licensed under a Creative Commons Attribution 4.0 International License. See https://creativecommons.org/licenses/by/4.0/.",
  "caseSensitive" : true,
  "valueSet" : "http://digitalhealth.gov.au/fhir/hcpd/ValueSet/hi-services-identifier-status-vs",
  "compositional" : false,
  "versionNeeded" : true,
  "content" : "complete",
  "count" : 3,
  "concept" : [{
    "code" : "A",
    "display" : "Active",
    "definition" : "The Healthcare Services Identifier is currently active and operational."
  },
  {
    "code" : "D",
    "display" : "Deactivated",
    "definition" : "The Healthcare Services Identifier is currently deactivated and not operational."
  },
  {
    "code" : "R",
    "display" : "Retired",
    "definition" : "The Healthcare Services Identifier has been retired and is no longer in use."
  }]
}

```
