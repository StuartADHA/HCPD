# HCPD Organization Example: Home Care Support Service - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Organization Example: Home Care Support Service**

## Example Organization: HCPD Organization Example: Home Care Support Service

Last updated: 2025-09-15 14:20:00+0000

Profile: [HCPD Organization](StructureDefinition-hcpd-organization.md)

Caring Hands Home Support (http://ns.electronichealth.net.au/id/hi/hspo/1.0#8003641000000217)

-------

| | |
| :--- | :--- |
| Active: | false |
| Alias: | CHHS |
| Part Of: | [null (National Organisation Identifier: 8003626566707032)](Organization-example-healthconnect-organization-1.md) |
| Other Ids: | * ABN/98765432109
* ACN/987654321
 |
| Contact Detail | * ph: (02) 9555 1200(Work)
* ph: (02) 9555 1201(Work)
* [admin@caringhands.com.au](mailto:admin@caringhands.com.au)
* [support@caringhands.com.au](mailto:support@caringhands.com.au)
* [https://www.caringhands.com.au](https://www.caringhands.com.au)
* fax: +61 2 9555 1299(Work)
* Suite 15, 88 Liverpool Street Sydney NSW 2000 AU 
 |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "example-healthconnect-organization-2",
  "meta" : {
    "lastUpdated" : "2025-09-15T14:20:00Z",
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-organization"]
  },
  "identifier" : [{
    "extension" : [{
      "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-services-identifier-status",
      "valueCoding" : {
        "system" : "http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/hi-services-identifier-status-cs",
        "code" : "A",
        "display" : "Active"
      }
    },
    {
      "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-org-classification",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/hi-org-classification-cs",
          "code" : "seed",
          "display" : "Seed"
        }]
      }
    }],
    "system" : "http://ns.electronichealth.net.au/id/hi/hspo/1.0",
    "value" : "8003641000000217"
  },
  {
    "type" : {
      "text" : "ABN"
    },
    "system" : "http://hl7.org.au/id/abn",
    "value" : "98765432109"
  },
  {
    "type" : {
      "text" : "ACN"
    },
    "system" : "http://hl7.org.au/id/acn",
    "value" : "987654321"
  }],
  "active" : false,
  "name" : "Caring Hands Home Support",
  "alias" : ["CHHS"],
  "telecom" : [{
    "system" : "phone",
    "value" : "(02) 9555 1200",
    "use" : "work"
  },
  {
    "system" : "phone",
    "value" : "(02) 9555 1201",
    "use" : "work"
  },
  {
    "system" : "email",
    "value" : "admin@caringhands.com.au",
    "use" : "work"
  },
  {
    "system" : "email",
    "value" : "support@caringhands.com.au",
    "use" : "work"
  },
  {
    "system" : "url",
    "value" : "https://www.caringhands.com.au",
    "use" : "work"
  },
  {
    "system" : "fax",
    "value" : "+61 2 9555 1299",
    "use" : "work"
  }],
  "address" : [{
    "type" : "physical",
    "line" : ["Suite 15, 88 Liverpool Street"],
    "city" : "Sydney",
    "state" : "NSW",
    "postalCode" : "2000",
    "country" : "AU"
  }],
  "partOf" : {
    "reference" : "Organization/example-healthconnect-organization-1"
  }
}

```
