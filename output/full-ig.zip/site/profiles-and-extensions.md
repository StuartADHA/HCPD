# Profiles and Extensions - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **Profiles and Extensions**

## Profiles and Extensions

### Profiles

The following profiles and extensions have been defined for this implementation guide.

#### Endpoint

* [HCPD Endpoint](StructureDefinition-hcpd-endpoint.md)

#### HealthcareService

* [HCPD HealthcareService](StructureDefinition-hcpd-healthcareservice.md)

#### Identifier

* [HCPD Healthcare Provider Identifier (HCPD HPI-I)](StructureDefinition-hcpd-hpii.md)
* [HCPD Healthcare Provider Identifier - Organisation (HCPD HPI-O)](StructureDefinition-hcpd-hpio.md)
* [HCPD Healthcare Support Service Provider - Organisation (HCPD HSP-O)](StructureDefinition-hcpd-hspo.md)
* [HCPD Local Identifier (HCPD-LI)](StructureDefinition-hcpd-local-identifier.md)
* [HCPD SMD Target Identifier (HCPD-SMDTI)](StructureDefinition-hcpd-smd-target-identifier.md)
* [HCPD Source Identifier (HCPD-SI)](StructureDefinition-hcpd-source-identifier.md)
* [Peak Body Professional Registration Number (PBPRN)](StructureDefinition-pbprn.md)

#### Location

* [HCPD Location](StructureDefinition-hcpd-location.md)
* [HCPD Service Coverage Area](StructureDefinition-hcpd-service-coverage-area.md)

#### Organization

* [HCPD Organization](StructureDefinition-hcpd-organization.md)

#### Parameters

* [HCPD Export Request Parameters](StructureDefinition-hcpd-export-request-parameters.md)

#### Practitioner

* [HCPD Practitioner](StructureDefinition-hcpd-practitioner.md)

#### PractitionerRole

* [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md)

#### Provenance

* [HCPD Provenance](StructureDefinition-hcpd-provenance.md)

### Extensions

The below extensions **EXCEPT FOR** HI Service Organisation Classification & HCPD Alternate Postal Address, will be abstracted to a Common Components FHIR IG. This IG will host common extensions used across Agency FHIR Implementation guides.

Because of this re-structure, implementers should note the difference in uri namespaces that result. This change has been made early, to prevent later breaking changes. Later releases of this HCPD IG will declare the Common Components IG as a dependency and the extension itself will reside there.

* [Active Period](StructureDefinition-active-period.md)
* [Alternate Name](StructureDefinition-alternate-name.md)
* [Amenity](StructureDefinition-amenity.md)
* [Deactivated](StructureDefinition-deactivated.md)
* [HCPD Alternate Postal Address](StructureDefinition-hcpd-alternate-postal-address.md)
* [HI Service Organisation Classification](StructureDefinition-hi-org-classification.md)
* [HI Services Identifier Status](StructureDefinition-hi-services-identifier-status.md)
* [IAR Levels of Care](StructureDefinition-iar-levels-of-care.md)
* [New Patient Availability](StructureDefinition-new-patient-availability.md)
* [Practitioner Role Communication](StructureDefinition-practitioner-role-communication.md)
* [Referral Information for Referrer](StructureDefinition-referral-information-for-referrer.md)
* [Suppression Indicator for Visibility](StructureDefinition-suppressed.md)

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.

