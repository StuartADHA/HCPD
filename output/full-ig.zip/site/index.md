# Home - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/ImplementationGuide/au.gov.digitalhealth.fhir.hcpd | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:HCPD_ImplementationGuide |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

## Scope

This Implementation Guide (IG) defines how a Health Connect Provider Directory Requester Actor (client) interacts with a Health Connect Provider Directory Responder Actor (server), specifying the expected behaviours for each. The Requester Actor is a read-only FHIR client: it may perform search and read operations, but does not create, update, or delete resources in Health Connect. The capability statements in this IG set out the minimum operations and behaviours that conformant implementations must support. For the Responder Actor, requirements are expressed as SHALL statements, indicating mandatory support. For the Requester Actor, requirements are a mix of SHALL (mandatory) and SHOULD (recommended) statements, as detailed in the relevant [capability statements](capability-statements.md) and [conformance statement](conformance.md) sections of this guide. For further detail please appraise both the [capability statements](capability-statements.md) and [conformance statement](conformance.md).

The intended downstream use case for conformant implementations is provider to provider discovery, enabling healthcare provider systems to discover accurate, up to date information about other healthcare providers, organisations, services, locations, and technical endpoints in order to support clinical, administrative, and interoperability workflow. The Health Connect Provider Directory FHIR Implementation Guide is an open specification, allowing implementers to extend it for their own use cases as long as they meet its conformance requirements. Feedback from the Australian FHIR Community Process (AFCP) strongly supported keeping the specification open, enabling a wider range of provider directory implementations and simplifying connectivity between systems.

## Introduction

Health Connect Australia is a national health information exchange program designed to enable the sharing of health information between healthcare participants quickly and securely. By integrating advanced digital infrastructure, standards, privacy protections and enabling real-time data sharing, Health Connect Australia will support multidisciplinary collaboration across care settings. As a key enabler of the [National Digital Health Strategy 2023–2028](https://www.digitalhealth.gov.au/national-digital-health-strategy) and the [National Healthcare Interoperability Plan 2023-2028](https://www.digitalhealth.gov.au/about-us/strategies-and-plans/national-healthcare-interoperability-plan), it ensures secure, connected digital solutions that improve access, efficiency and care quality-paving the way for a smarter, more integrated future in digital health. The program is being delivered in phases, beginning with foundational capabilities and expanding to support secure communication, record discovery, and value-added services for both providers and consumers.

The Directory and Authorisation Service Project is the first initiative under the Foundations phase. It enables healthcare providers to discover accurate, up-to-date information about other providers and the services they offer, while establishing a trust framework to support consistent and secure access to health information. By connecting provider data from multiple primary sources through a single access point and ensuring near real-time updates, the project lays the groundwork for broader interoperability and trusted information exchange across the national health ecosystem.

One of the key objectives of the Directory and Authorisation Service Project is to enable interoperability through contemporary standards such as FHIR APIs to ensure seamless integration across clinical and administrative systems. To support this, the project is establishing a centralised directory hosted on a FHIR repository, where provider and organisation data will be structured using HL7® FHIR® and terminology standards. To guide consistent implementation and promote national alignment, the project is developing a FHIR Implementation Guide that defines how provider information should be represented and exchanged. This guide will build on existing standards, including the HL7 Australia FHIR AU Core, and provide a clear reference for integrators and system vendors to support secure, scalable, and standards-compliant access to directory data.

## How to read this guide

This guide is divided into several pages which are listed at the top of each page in the menu bar.

* [Home](index.md): This page provides the introduction and scope for the implementation guide.
* [Conformance](conformance.md): This page describes the set of rules to claim conformance to this guide including capability statements and actor definitions.
* [Guidance](guidance.md): This page provides implementation guidance and best practices for using the Health Connect Provider Directory FHIR IG. 
* [General Guidance](general-guidance.md): This page provides implementation conventions for must support elements, actor obligations, and experimental dependencies in the Health Connect Provider Directory FHIR IG.
* [Bulk Data Extraction](bulk-data-extraction.md): This page provides asynchronous bulk export capabilities using FHIR Bulk Data Access specification for large-scale provider directory data extraction and synchronization.
 
* [Security and Privacy](security-and-privacy.md): This page provides Security requirements including TLS encryption standards, FHIR communications security, and privacy obligations for Health Connect Provider Directory implementations.
* [FHIR Artefacts](artifacts.md): These pages provide detailed descriptions and formal definitions for all the FHIR artefacts defined in this guide. 
* [Artifacts Summary](artifacts.md): This page provides a comprehensive summary of all FHIR artifacts defined in this implementation guide including profiles, extensions, terminology, and other conformance resources.
* [Profiles and Extensions](profiles-and-extensions.md): This page lists the FHIR profiles and extensions that are defined in this guide.
* [Terminology](terminology.md): This page lists the FHIR terminology that are defined in this guide.
* [Actor Definitions](actors.md): This page defines the Health Connect actors, Health Connect Provider Directory Requester and Health Connect Provider Directory Responder.
* [Capability Statements](capability-statements.md): This page defines the expected FHIR capabilities of Health Connect Provider Directory Requester and Health Connect Provider Directory Responder.
* [Search Parameters](artifacts.md#behavior-search-parameters): This page lists the FHIR search parameters that are defined in this guide.
 
* [Examples](examples.md): This page lists the sample instances of FHIR resources conforming to the FHIR profiles.
* [HCPD API](api-overview.md): This page defines operational behaviour for real-time search and read interactions in the Health Connect Provider Directory API.
* [Support](downloads.md): This section provides support resources for implementers. 
* [Known Issues](known-issues.md): This page lists known issues with this specification at the time of publishing along with their descriptions.
* [Downloads](downloads.md): This page provides links to downloadable artefacts including the Agency FHIR NPM package.
 
* [Change Log](changelog.md): This page documents the version history and changes made to this implementation guide across different releases.
* [License and Legal](legal.md): This page lists the licensing, copyright, and disclaimers under which this guide is issued.

## Document purpose and scope

The primary aim of this implementation guide is to support implementers integrating with the Directory services using [FHIR, Release 4 (v4.0.1) [HL7FHIR4]](#HL7FHIR4). It provides the technical specifications, FHIR profiles, and terminology definitions required for healthcare provider data exchange through Health Connect Provider Directory APIs.

This document describes specific system behaviours such as obligations, API HTTP response codes, and search parameters. Other system behavioural requirements such as the presentation of information and user experience are managed separately and must be met before systems can be assessed for conformance and granted access to Health Connect APIs.

Reference has been made to International and Australian Standards, and to Standards from HL7. The following standards are referred to in the text in such a way that some or all of its content constitutes requirements for the purposes of this specification:

* [FHIR, Release 4 (v4.0.1) [HL7FHIR4]](#HL7FHIR4)
* [Australian Base Profiles Implementation Guide [HL7AUBIG]](#HL7AUBIG)
* [Australian Core Profiles Implementation Guide [HL7AUCIG]](#HL7AUCIG)
* [FHIRPath Specification v2.0.0 [HL7FHIRPATH]](#HL7FHIRPATH)

Wherever possible, material in this specification is based on existing standards. All efforts have been made to minimise divergence from the HL7 Australia standards ([AU Core [HL7AUCIG]](#HL7AUCIG) and [AU Base [HL7AUBIG]](#HL7AUBIG)) to provide for system interoperability and compatibility with other profiles. Issues of an editorial nature in the source material (such as spelling or punctuation errors) are intentionally reproduced.

## Intended audience

This implementation guide is aimed at software development teams, architects, and designers that integrate with the Health Connect Provider Directory system.

This implementation guide and related artefacts are technical in nature and the audience is expected to be familiar with the language of health data specifications and to have some familiarity with health information standards and specifications, such as FHIR.

## Relationships with other work

This implementation guide builds on other specifications, helping ensure a consistent approach to data sharing that should ease adoption. The specific guides used, and the portions relevant from each of them are as follows:

## Cross version analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (au.gov.digitalhealth.fhir.hcpd.r4)](package.r4.tgz) and [R4B (au.gov.digitalhealth.fhir.hcpd.r4b)](package.r4b.tgz) are available.

### Global profiles

*There are no Global profiles defined*

### Data model overview

The Health Connect Provider Directory uses FHIR resources to represent healthcare providers, their roles, organisational affiliations, service locations, and the healthcare services they provide. The diagram below illustrates the key relationships between these FHIR resources:

* Organization - Healthcare organisations and facilities that employ or affiliate with practitioners
* Location - Physical or virtual locations where healthcare services are delivered
* HealthcareService - Specific services offered by organisations at locations
* Endpoint - Technical endpoints for digital service integration and communication
* PractitionerRole - Roles and responsibilities of practitioners within organizations, including availability
* Practitioner - Individual healthcare providers with their professional qualifications and identifiers

This model supports complex healthcare delivery scenarios while maintaining FHIR R4 compliance and enabling efficient provider directory searches and integrations.

### References

| | |
| :--- | :--- |
| [HL7AUBIG] | HL7 Australia, FHIR R4 standard for AU Base Implementation Guide, v6.0.0 |
|   | [https://hl7.org.au/fhir/6.0.0/index.html](https://hl7.org.au/fhir/6.0.0/index.html) |

| | |
| :--- | :--- |
| [HL7FHIR4] | Health Level Seven, Inc., 30 October 2019, FHIR R4. |
|   | [http://hl7.org/fhir/R4/](http://hl7.org/fhir/R4/) |

| | |
| :--- | :--- |
| [HL7AUCIG] | HL7 Australia, FHIR R4 standard for AU Core Implementation Guide, v2.0.0 |
|   | [https://hl7.org.au/fhir/core/2.0.0/index.html](https://hl7.org.au/fhir/core/2.0.0/index.html) |

| | |
| :--- | :--- |
| [HL7FHIRPATH] | HL7 International, FHIRPath Specification, v2.0.0 |
|   | [http://hl7.org/fhirpath](http://hl7.org/fhirpath) |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "au.gov.digitalhealth.fhir.hcpd",
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/ImplementationGuide/au.gov.digitalhealth.fhir.hcpd",
  "version" : "26.0.0",
  "name" : "HCPD_ImplementationGuide",
  "title" : "Health Connect Australia Provider Directory FHIR Implementation Guide",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "This Implementation Guide defines an Health Connect Australia Provider Directory within Australian context.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "packageId" : "au.gov.digitalhealth.fhir.hcpd",
  "license" : "CC-BY-4.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.4.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "hl7_fhir_au_base",
    "uri" : "http://hl7.org.au/fhir/ImplementationGuide/hl7.fhir.au.base",
    "packageId" : "hl7.fhir.au.base",
    "version" : "6.0.0"
  },
  {
    "id" : "hl7_fhir_au_core",
    "uri" : "http://hl7.org.au/fhir/core/ImplementationGuide/hl7.fhir.au.core",
    "packageId" : "hl7.fhir.au.core",
    "version" : "2.0.0"
  },
  {
    "id" : "hl7_fhir_au_pd",
    "uri" : "http://hl7.org.au/fhir/pd/ImplementationGuide/hl7.fhir.au.pd",
    "packageId" : "hl7.fhir.au.pd",
    "version" : "current"
  },
  {
    "id" : "hl7_fhir_uv_bulkdata",
    "uri" : "http://hl7.org/fhir/uv/bulkdata/ImplementationGuide/hl7.fhir.uv.bulkdata",
    "packageId" : "hl7.fhir.uv.bulkdata",
    "version" : "3.0.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/expansion-parameters",
      "valueReference" : {
        "reference" : "Parameters/expansion-parameters"
      }
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.3.0"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2026+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-expansion-params"
      },
      {
        "url" : "value",
        "valueString" : "../../input/_resources/exp-params.json"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "default-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "show-inherited-invariants"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "usage-stats-opt-out"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludexml"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludejson"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludettl"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludemap"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "tx"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "generate"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "init"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "progress"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-all"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/active-period"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/alternate-name"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/amenity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/iar-levels-of-care"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/new-patient-availability"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/practitioner-role-communication"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/referral-information-for-referrer"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://digitalhealth.gov.au/fhir/cc/ValueSet/responsible-party-type"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/pbprn"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://digitalhealth.gov.au/fhir/cc/SearchParameter/suppressed"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "http://digitalhealth.gov.au/fhir/hcpd/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-active-period.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/active-period"
      },
      "name" : "Active Period",
      "description" : "The period during which the HealthcareService is considered active.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-allday.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/allday"
      },
      "name" : "All Day Search Parameter",
      "description" : "Search HealthcareServices or PractitionerRoles by whether they are available all day.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-alternate-name.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/alternate-name"
      },
      "name" : "Alternate Name",
      "description" : "This extension applies to PractitionerRole, and represents a name by which a practitioner chooses to be known in the context of the delivery of a specific healthcare service.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-amenity.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/amenity"
      },
      "name" : "Amenity",
      "description" : "Physical features or amenities available within, or in close proximity of, a location. Uses the NCTS Facility Amenity ValueSet.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-daysofweek.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/daysofweek"
      },
      "name" : "Days of Week Search Parameter",
      "description" : "Search HealthcareServices or PractitionerRoles by days of week availability. Supports multiple days using OR logic.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-deactivated.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/deactivated"
      },
      "name" : "Deactivated",
      "description" : "Identifies the party responsible for setting the parent resource to an inactive or suspended state. This extension is expected to be present whenever the resource's active or status element indicates it is no longer active, and provides audit metadata about the actor who initiated the change.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-endtime.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/endtime"
      },
      "name" : "End Time Search Parameter",
      "description" : "Search HealthcareServices or PractitionerRoles by end time. Query values must use a four-digit numeric 24 hr time format (HHMM, e.g., 0830 for 8:30am). The end time is converted to an integer to enable prefix-based time searches (e.g., gt, lt, ge, le).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-endpoint-payloadmimetype.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/endpoint-payloadmimetype"
      },
      "name" : "Endpoint Payload Mime Type Search Parameter",
      "description" : "Search for Endpoint resources by payloadMimeType.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-endpoint-url.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/endpoint-url"
      },
      "name" : "Endpoint URL Search Parameter",
      "description" : "Search for Endpoint resources by address (URL).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-endpoint-hcepi.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/endpoint-hcepi"
      },
      "name" : "HC Local Endpoint Identifier Search Parameter",
      "description" : "Search an Endpoint record by its HC Local Identifier.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-alternate-postal-address.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-alternate-postal-address"
      },
      "name" : "HCPD Alternate Postal Address",
      "description" : "Alternate postal/mailing address for correspondence (PO Box or mailing address) that is distinct from the registered physical address.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-endpoint.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-endpoint"
      },
      "name" : "HCPD Endpoint",
      "description" : "This profile defines a Health Connect Provider Directory entry for a technical endpoint.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Endpoint"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Endpoint-example-hcpd-endpoint-hl7-fhir-messaging.html"
      }],
      "reference" : {
        "reference" : "Endpoint/example-hcpd-endpoint-hl7-fhir-messaging"
      },
      "name" : "HCPD Endpoint Example: HL7 FHIR Messaging",
      "description" : "An example Endpoint with HL7 FHIR Messaging Endpoint conforming to the HCPD Endpoint profile.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-endpoint|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-export-request-parameters.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-export-request-parameters"
      },
      "name" : "HCPD Export Request Parameters",
      "description" : "Defines a profile of a Parameters resource used to make bulk data export requests. It contains the standard FHIR bulk export parameters including _type, _typeFilter, _outputFormat, and _since for controlling the export scope and format.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Parameters-example-hcpd-export-request-parameters-1.html"
      }],
      "reference" : {
        "reference" : "Parameters/example-hcpd-export-request-parameters-1"
      },
      "name" : "HCPD Export Request Parameters Example: Cardiology Services in Balmain",
      "description" : "An example Parameters resource conforming to the HCPD Export Request Parameters profile, requesting export of all cardiology services in Balmain including organizations, locations, services, roles and practitioners.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-export-request-parameters|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Parameters-example-hcpd-export-request-parameters-2.html"
      }],
      "reference" : {
        "reference" : "Parameters/example-hcpd-export-request-parameters-2"
      },
      "name" : "HCPD Export Request Parameters Example: Delta Export Since Last Retrieval",
      "description" : "An example Parameters resource showing a delta export request with _since parameter for retrieving changes since a previous export.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-export-request-parameters|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-hpii.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-hpii"
      },
      "name" : "HCPD Healthcare Provider Identifier (HCPD HPI-I)",
      "description" : "This identifier profile extends the AU HPI-I profile to include status extensions similar to those available in AU IHI. A HPI-I is assigned under the Healthcare Identifiers (HI) Service to a Practitioner.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-hpio.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-hpio"
      },
      "name" : "HCPD Healthcare Provider Identifier - Organisation (HCPD HPI-O)",
      "description" : "This identifier profile extends the AU HPI-O profile to include an organization classification extension to indicate whether the organization is a 'seed' or 'network' type.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-hspo.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-hspo"
      },
      "name" : "HCPD Healthcare Support Service Provider - Organisation (HCPD HSP-O)",
      "description" : "This identifier profile defines a Healthcare Support Service Provider Organisation in an Australian context. An HSP-O is assigned under the HI Service to a service (in-home care support and personal care services) where healthcare is provided. A HSP-O can only be of 'seed' type. An Organization cannot be assigned both an HPI-O and an HSP-O; only one identifier is assigned by the HI Service.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-healthcareservice.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-healthcareservice"
      },
      "name" : "HCPD HealthcareService",
      "description" : "This profile defines a Health Connect Provider Directory entry for a healthcare service offered by an organisation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "HealthcareService"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "HealthcareService-example-healthconnect-healthcareservice-2.html"
      }],
      "reference" : {
        "reference" : "HealthcareService/example-healthconnect-healthcareservice-2"
      },
      "name" : "HCPD HealthcareService Example: Geriatric evaluation and management service",
      "description" : "A HealthcareService example demonstrating all elements defined in the HCPD HealthcareService profile, including all extensions, identifiers, availability windows, eligibility criteria, and telecoms.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-healthcareservice|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "HealthcareService"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "HealthcareService-example-healthconnect-healthcareservice-1.html"
      }],
      "reference" : {
        "reference" : "HealthcareService/example-healthconnect-healthcareservice-1"
      },
      "name" : "HCPD HealthcareService Example: Residential Aged Care",
      "description" : "A Residential Aged Care HealthcareService example conforming to the HCPD HealthcareService profile.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-healthcareservice|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-local-identifier.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-local-identifier"
      },
      "name" : "HCPD Local Identifier (HCPD-LI)",
      "description" : "This profile of Identifier defines a HCPD Local Identifier (HCPD-LI) used for system reference and internal business logic.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-location.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-location"
      },
      "name" : "HCPD Location",
      "description" : "This profile defines a Health Connect Provider Directory entry for a healthcare location where services are provided.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-example-healthconnect-medical-centre-location-1.html"
      }],
      "reference" : {
        "reference" : "Location/example-healthconnect-medical-centre-location-1"
      },
      "name" : "HCPD Location Example: Medical Centre (Physical Building)",
      "description" : "A physical medical centre location example with wheelchair access, conforming to the HCPD Location profile.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-example-healthconnect-mobile-healthcare-unit-1.html"
      }],
      "reference" : {
        "reference" : "Location/example-healthconnect-mobile-healthcare-unit-1"
      },
      "name" : "HCPD Location Example: Mobile Healthcare Unit",
      "description" : "A mobile healthcare unit location example with wheelchair access, conforming to the HCPD Location profile.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-example-healthconnect-mobile-unit-coverage-area-1.html"
      }],
      "reference" : {
        "reference" : "Location/example-healthconnect-mobile-unit-coverage-area-1"
      },
      "name" : "HCPD Location Example: Mobile Unit Service Coverage Area",
      "description" : "A virtual coverage area defining the geographical service boundary for the mobile healthcare unit.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-example-healthconnect-virtual-telehealth-service-1.html"
      }],
      "reference" : {
        "reference" : "Location/example-healthconnect-virtual-telehealth-service-1"
      },
      "name" : "HCPD Location Example: Virtual Telehealth Service",
      "description" : "A virtual telehealth service location example without physical address, conforming to the HCPD Location profile.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-organization.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-organization"
      },
      "name" : "HCPD Organization",
      "description" : "This profile defines a Health Connect Provider Directory entry for an organisation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-example-healthconnect-organization-1.html"
      }],
      "reference" : {
        "reference" : "Organization/example-healthconnect-organization-1"
      },
      "name" : "HCPD Organization Example: Aged Care Facility",
      "description" : "An Aged Care Facility example conforming to the HCPD Organization profile.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-organization|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-example-healthconnect-organization-2.html"
      }],
      "reference" : {
        "reference" : "Organization/example-healthconnect-organization-2"
      },
      "name" : "HCPD Organization Example: Home Care Support Service",
      "description" : "A Home Care Support Service example conforming to the HCPD Organization profile with HSP-O identifier.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-organization|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-practitioner.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-practitioner"
      },
      "name" : "HCPD Practitioner",
      "description" : "This profile defines a Health Connect Provider Directory entry for a healthcare practitioner.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-example-healthconnect-practitioner-1.html"
      }],
      "reference" : {
        "reference" : "Practitioner/example-healthconnect-practitioner-1"
      },
      "name" : "HCPD Practitioner Example: Alex Smith",
      "description" : "An example Practitioner (Alex Smith) conforming to the HCPD Practitioner profile.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitioner|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-example-balmain-practitioner-1.html"
      }],
      "reference" : {
        "reference" : "Practitioner/example-balmain-practitioner-1"
      },
      "name" : "HCPD Practitioner Example: Alice Anderson (Balmain)",
      "description" : "Practitioner serving Balmain examples.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitioner|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-external-hcpd-practitioner-record.html"
      }],
      "reference" : {
        "reference" : "Practitioner/external-hcpd-practitioner-record"
      },
      "name" : "HCPD Practitioner Example: External Record (PRN)",
      "description" : "An external practitioner record example (PRN identifier) conforming to the HCPD Practitioner profile.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitioner|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-practitionerrole.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-practitionerrole"
      },
      "name" : "HCPD PractitionerRole",
      "description" : "This profile defines a Health Connect Provider Directory entry for a practitioner role within an organisation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-example-healthconnect-practitionerrole-2.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/example-healthconnect-practitionerrole-2"
      },
      "name" : "HCPD PractitionerRole Example: Ahpra-Only General Practitioner (Balmain)",
      "description" : "An example PractitionerRole for a general practitioner registered with Ahpra only (no Medicare provider number), working part-time at the Balmain service location.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitionerrole|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-example-healthconnect-practitionerrole-1.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/example-healthconnect-practitionerrole-1"
      },
      "name" : "HCPD PractitionerRole Example: Medicare Provider",
      "description" : "An example PractitionerRole (Medicare) that conforms to the HCPD PractitionerRole profile.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitionerrole|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-provenance.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-provenance"
      },
      "name" : "HCPD Provenance",
      "description" : "This profile of Provenance is used to track activities related to provider directory data, recording when specific data elements of a HCPD Organization or HCPD Practitioner resource have been retrieved, updated or verified.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Provenance"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Provenance-provenance-practitioner-name-update.html"
      }],
      "reference" : {
        "reference" : "Provenance/provenance-practitioner-name-update"
      },
      "name" : "HCPD Provenance Example: Practitioner Name Amendment",
      "description" : "Demonstrates provenance tracking for a practitioner's name amendment, conforming to the HCPD Provenance profile.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-provenance|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Provenance"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Provenance-provenance-practitioner-phone-update.html"
      }],
      "reference" : {
        "reference" : "Provenance/provenance-practitioner-phone-update"
      },
      "name" : "HCPD Provenance Example: Practitioner Phone Amendment",
      "description" : "Demonstrates provenance tracking for a practitioner's phone number amendment, conforming to the HCPD Provenance profile.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-provenance|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-service-coverage-area.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-service-coverage-area"
      },
      "name" : "HCPD Service Coverage Area",
      "description" : "This profile of Location represents an Australian geographic coverage area i.e. postcodes where this service is provided.\r\nFor a healthcare service, that is provided through a physical location but have eligibility restrictions applicable in terms of only residents for certain postcodes/suburbs can receive this service, then the details of coverage area and eligibility should be provided here.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-example-healthconnect-service-coverage-area-balmain-1.html"
      }],
      "reference" : {
        "reference" : "Location/example-healthconnect-service-coverage-area-balmain-1"
      },
      "name" : "HCPD Service Coverage Area Example: Balmain (2041)",
      "description" : "A service coverage area representing the Balmain suburb postcode (2041), used to define the geographic eligibility boundary for a healthcare service.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-service-coverage-area|26.0.0"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-smd-target-identifier.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-smd-target-identifier"
      },
      "name" : "HCPD SMD Target Identifier (HCPD-SMDTI)",
      "description" : "This identifier profile defines a SMD target identifier allocated to a healthcare practitioner, in a Health Connect Provider Directory context.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hcpd-source-identifier.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hcpd-source-identifier"
      },
      "name" : "HCPD Source Identifier (HCPD-SI)",
      "description" : "This profile of Identifier defines a HCPD Source Identifier (HCPD-SI).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-health-connect-bulk-export-requester.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/health-connect-bulk-export-requester"
      },
      "name" : "Health Connect Provider Directory Bulk Export Requester",
      "description" : "This CapabilityStatement resource defines the expected capabilities of the [Health Connect Provider Directory Bulk Export Requester Actor](ActorDefinition-bulk-export-requester-actor-health-connect.html) when conforming to this implementation guide. This actor is specifically designed for bulk data export operations and does not support standard FHIR REST search interactions. The listed FHIR profiles and operations describe the capabilities required for initiating bulk exports and processing the returned data.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-bulk-export-requester-actor-health-connect.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/bulk-export-requester-actor-health-connect"
      },
      "name" : "Health Connect Provider Directory Bulk Export Requester Actor",
      "description" : "The Health Connect Provider Directory Bulk Export Requester actor represents a system that initiates **bulk data export requests** from the Health Connect Provider Directory system. This actor is responsible for submitting properly formatted export parameters and processing the returned bulk data files.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-health-connect-provider-directory-requester.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/health-connect-provider-directory-requester"
      },
      "name" : "Health Connect Provider Directory Requester",
      "description" : "This [CapabilityStatement](https://hl7.org/fhir/R4/capabilitystatement.html) resource defines the expected capabilities \r\nof the [Health Connect Provider Directory Requester Actor](ActorDefinition-requester-actor-health-connect.html) when conforming to this implementation guide. The complete \r\nlist of FHIR profiles, RESTful operations, and search parameters supported by Health Connect Provider Directory Requester Actor are defined in this CapabilityStatement. \r\nThe requirements of the Health Connect Provider Directory Requester actor may also be impacted by the rules of local jurisdictions or other contextual requirements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-requester-actor-health-connect.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/requester-actor-health-connect"
      },
      "name" : "Health Connect Provider Directory Requester Actor",
      "description" : "The Health Connect Provider Directory Requester actor represents a system that is requesting **Health Connect Provider Directory details** for a particular provider or resource from the\r\nHealth Connect Provider Directory system.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-health-connect-provider-directory-responder.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/health-connect-provider-directory-responder"
      },
      "name" : "Health Connect Provider Directory Responder",
      "description" : "This CapabilityStatement resource defines the expected capabilities of the [Health Connect Provider Directory Responder Actor](ActorDefinition-responder-actor-health-connect.html) when conforming to this implementation guide. The listed FHIR profiles, RESTful operations, and search parameters describe only those capabilities exposed for responding to Requester Actor requests. The Health Connect Provider Directory Responder supports additional internal and publishing operations that are not shown here; these are out of scope for this IG and are documented separately for publishing systems. The requirements of the Health Connect Provider Directory Responder may also be impacted by the rules of local jurisdictions or other contextual requirements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-responder-actor-health-connect.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/responder-actor-health-connect"
      },
      "name" : "Health Connect Provider Directory Responder Actor",
      "description" : "The Health Connect Provider Directory Responder actor represents the system that provides **Health Connect Provider Directory details**. It accepts requests for Directory information about practitioners or services and returns the requested information, or an error message if the request cannot be fulfilled.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-healthcareservice-type-display.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/healthcareservice-type-display"
      },
      "name" : "Healthcare Service Type Display Search Parameter",
      "description" : "Search HealthcareServices by the display name of the healthcare service type.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-healthcareservice-billing.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/healthcareservice-billing"
      },
      "name" : "HealthcareService Billing Search Parameter",
      "description" : "Search for HealthcareService resources by billing information.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hi-org-classification.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hi-org-classification"
      },
      "name" : "HI Service Organisation Classification",
      "description" : "Extension to record whether an organisation's HPIO is a 'seed' or 'network' type in the HI service.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-hi-org-classification-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/hi-org-classification-cs"
      },
      "name" : "HI Service Organisation Classification CodeSystem",
      "description" : "Internal code system that describes whether an organisation is a 'seed' or 'network' type in the HI Service.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-hi-org-classification-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/hi-org-classification-vs"
      },
      "name" : "HI Service Organization Classification ValueSet",
      "description" : "All codes in the HI Service Organization Classification CodeSystem code system.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hi-services-identifier-status.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hi-services-identifier-status"
      },
      "name" : "HI Services Identifier Status",
      "description" : "Indicates the status of the Australian Healthcare Services Identifier.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-hi-services-identifier-status-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/hi-services-identifier-status-cs"
      },
      "name" : "HI Services Identifier Status Code System",
      "description" : "This code system defines concepts that identify the status of a Healthcare Services Identifier, i.e. HPII, HPIO or HSPO.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-hi-services-identifier-status-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/hi-services-identifier-status-vs"
      },
      "name" : "HI Services Identifier Status Value Set",
      "description" : "All codes in the HI Services Identifier Status Code System code system.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-iar-levels-of-care.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/iar-levels-of-care"
      },
      "name" : "IAR Levels of Care",
      "description" : "Indicates the IAR (Initial Assessment and Referral) Levels of Care for a healthcare service.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-languages.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/languages"
      },
      "name" : "Languages Search Parameter",
      "description" : "Search HealthcareServices or PractitionerRoles by supported languages/communication methods. Shared across HealthcareService and PractitionerRole. Supports token based searching, i.e. `system|code` or just `code`",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-location-amenities.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/location-amenities"
      },
      "name" : "Location Amenities Search Parameter",
      "description" : "Search for Location resources by amenities.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-location-physicaltype.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/location-physicaltype"
      },
      "name" : "Location Physical Type Search Parameter",
      "description" : "Search for Location resources by physicalType field.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-location-locmailaddress.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/location-locmailaddress"
      },
      "name" : "Location Postal Address Search Parameter",
      "description" : "Search for Location resources by postal address components.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-new-patient-availability.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/new-patient-availability"
      },
      "name" : "New Patient Availability",
      "description" : "Indicates whether the healthcare service is accepting new patients. Patterned after PCA New Patient Availability extension.\n\nContext of Use: HealthcareService",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-pbprn.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/pbprn"
      },
      "name" : "Peak Body Professional Registration Number (PBPRN)",
      "description" : "This identifier profile defines a peak body (non-Ahpra) professional registration number allocated to a healthcare practitioner.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-practitioner-identifier-r5.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/practitioner-identifier-r5"
      },
      "name" : "Practitioner identifier (R5 mimic)",
      "description" : "Enables R5-style identifier searching across both Practitioner.identifier and Practitioner.qualification.identifier paths. This allows searching for practitioners by any identifier type including HPI-I, Ahpra and other peak body registration numbers. Works with `system|value` OR `system` OR `value`.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-practitioner-role-communication.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/practitioner-role-communication"
      },
      "name" : "Practitioner Role Communication",
      "description" : "Practitioner Role Communication. This extension captures communication preferences and capabilities for a practitioner in a given role.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-practitionerrole-code-display.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/practitionerrole-code-display"
      },
      "name" : "Practitioner Role Type Display Search Parameter",
      "description" : "Search PractitionerRoles by the display name of the practitioner role code.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-practitioner-rsg.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/practitioner-rsg"
      },
      "name" : "Practitioner's Recorded Sex or Gender Search Parameter",
      "description" : "Search a Practitioner record by their recorded sex or gender. This search parameter operates on the 'value' element of the individual-recordedSexOrGender extension (typically an administrative gender code). However, to fully understand the meaning and context of the recorded sex or gender, the complete extension structure returned in results should be examined, including metadata elements such as 'type' (category of what's recorded), 'source', 'sourceDocument', 'effectivePeriod', and other contextual information.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-practitioner-regprof.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/practitioner-regprof"
      },
      "name" : "Practitioner's Registered Profession Search Parameter",
      "description" : "Search a Practitioner record by their registered profession using string values.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-referral-information-for-referrer.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/referral-information-for-referrer"
      },
      "name" : "Referral Information for Referrer",
      "description" : "Referral instructions and information for healthcare service providers that may wish to refer patients / clients to the healthcare service.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-responsible-party-type.html"
      }],
      "reference" : {
        "reference" : "ValueSet/responsible-party-type"
      },
      "name" : "Responsible Party Type",
      "description" : "ValueSet containing codes that indicate the resource type of the party that is responsible for the current value of a data element.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-responsible-party-type.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/responsible-party-type"
      },
      "name" : "Responsible Party Type",
      "description" : "CodeSystem containing codes that indicate the resource type of the party that is responsible for the current value of a data element.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-service-provision-code-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/service-provision-code-vs"
      },
      "name" : "Service Provision Code ValueSet",
      "description" : "The Service Provision Code ValueSet includes values that may be used to identify the service provision condition of a healthcare service.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-service-provision-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/service-provision-cs"
      },
      "name" : "Service Provision CodeSystem",
      "description" : "The Service Provision CodeSystem defines a concept (in addition to those defined in [Service Provision Conditions Australian Concepts](https://hl7.org.au/fhir/4.1.0/CodeSystem-service-provision-conditions.html) that may be used to identify the service provision condition of a healthcare service in HCPD.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-starttime.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/starttime"
      },
      "name" : "Start Time Search Parameter",
      "description" : "Search HealthcareServices or PractitionerRoles by start time. Query values must use a four-digit numeric 24 hr time format (HHMM, e.g., 0830 for 8:30am). The start time is converted to an integer to enable prefix-based time searches (e.g., gt, lt, ge, le).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-suppressed.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/suppressed"
      },
      "name" : "Suppressed Search Parameter",
      "description" : "Search resources by suppression state using the Suppressed extension.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-suppressed.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/suppressed"
      },
      "name" : "Suppression Indicator for Visibility",
      "description" : "Indicates whether the parent resource should be hidden from display in the Provider Directory. Contains coded information about the actor who initiated the suppression and optional control flags.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Endpoint"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Endpoint-example-hcpd-endpoint-referral.html"
      }],
      "reference" : {
        "reference" : "Endpoint/example-hcpd-endpoint-referral"
      },
      "name" : "Sydney Private Clinic: FHIR Referral Endpoint",
      "description" : "FHIR REST endpoint for Sydney Private Clinic. Receives electronic referrals (ServiceRequest) for Dr. Emily Chen's gynaecology service. Selected via Provider Directory search: location Sydney, wait time <2 weeks.",
      "exampleCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-endpoint|26.0.0"
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "conformance.html"
        }],
        "nameUrl" : "conformance.html",
        "title" : "Conformance",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "guidance.html"
        }],
        "nameUrl" : "guidance.html",
        "title" : "Guidance",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "general-guidance.html"
          }],
          "nameUrl" : "general-guidance.html",
          "title" : "General Guidance",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "bulk-data-extraction.html"
          }],
          "nameUrl" : "bulk-data-extraction.html",
          "title" : "Bulk Data Extraction",
          "generation" : "markdown",
          "page" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "BatchRequestSubmission.html"
            }],
            "nameUrl" : "BatchRequestSubmission.html",
            "title" : "Batch Request Submission",
            "generation" : "markdown"
          },
          {
            "extension" : [{
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "BatchRequestStatus.html"
            }],
            "nameUrl" : "BatchRequestStatus.html",
            "title" : "Batch Request Status",
            "generation" : "markdown"
          },
          {
            "extension" : [{
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "BatchRequestResults.html"
            }],
            "nameUrl" : "BatchRequestResults.html",
            "title" : "Batch Request Results",
            "generation" : "markdown"
          },
          {
            "extension" : [{
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "BatchRequestDelete.html"
            }],
            "nameUrl" : "BatchRequestDelete.html",
            "title" : "Batch Request Delete",
            "generation" : "markdown"
          }]
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "security-and-privacy.html"
        }],
        "nameUrl" : "security-and-privacy.html",
        "title" : "Security and Privacy",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "artifacts.html"
        }],
        "nameUrl" : "artifacts.html",
        "title" : "FHIR Artefacts",
        "generation" : "html",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "profiles-and-extensions.html"
          }],
          "nameUrl" : "profiles-and-extensions.html",
          "title" : "Profiles and Extensions",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "pbprn-systems.html"
          }],
          "nameUrl" : "pbprn-systems.html",
          "title" : "PBPRN Supported Systems",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "terminology.html"
          }],
          "nameUrl" : "terminology.html",
          "title" : "Terminology",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "actors.html"
          }],
          "nameUrl" : "actors.html",
          "title" : "Actor Definitions",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "capability-statements.html"
          }],
          "nameUrl" : "capability-statements.html",
          "title" : "Capability Statements",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "search-parameters.html"
          }],
          "nameUrl" : "search-parameters.html",
          "title" : "Search Parameters",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "examples.html"
        }],
        "nameUrl" : "examples.html",
        "title" : "Examples",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "api-overview.html"
        }],
        "nameUrl" : "api-overview.html",
        "title" : "Health Connect Provider Directory API Overview",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "search-api.html"
          }],
          "nameUrl" : "search-api.html",
          "title" : "Search API Technical Specification",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "export-api.html"
          }],
          "nameUrl" : "export-api.html",
          "title" : "Export API Technical Specification",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "support.html"
        }],
        "nameUrl" : "support.html",
        "title" : "Support",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "known-issues.html"
          }],
          "nameUrl" : "known-issues.html",
          "title" : "Known Issues",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "downloads.html"
          }],
          "nameUrl" : "downloads.html",
          "title" : "Downloads",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "changelog.html"
        }],
        "nameUrl" : "changelog.html",
        "title" : "Change Log",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "contributing.html"
          }],
          "nameUrl" : "contributing.html",
          "title" : "Contributing",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "legal.html"
        }],
        "nameUrl" : "legal.html",
        "title" : "Licence and Legal",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/resources fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "input/pagecontent"
    },
    {
      "code" : "path-pages",
      "value" : "input/intro-notes"
    },
    {
      "code" : "path-pages",
      "value" : "fsh-generated/includes"
    },
    {
      "code" : "path-pages",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
