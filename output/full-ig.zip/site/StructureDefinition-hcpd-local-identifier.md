# HCPD Local Identifier (HCPD-LI) - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Local Identifier (HCPD-LI)**

## Data Type Profile: HCPD Local Identifier (HCPD-LI) 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-local-identifier | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:HCPD_Local_Identifier |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

 
This profile of Identifier defines a HCPD Local Identifier (HCPD-LI) used for system reference and internal business logic. 

### HCPD Local Identifier

Beyond the identifiers already defined in AU Core, the following HCPD resource profiles: Location, PractitionerRole, HealthcareService & Endpoint explicitly support a unique Health Connect Provider Directory attributed slice. The value of this identifier is uniquely assigned at creation, therefore this prevents duplications of values regardless of resource type.

Publishing guidance:

* The HCPD Local Identifier (HCPD-LI) is the canonical identifier for resources internally within the Health Connect Provider Directory system and **SHALL** be supplied when known. Publishing systems **SHALL NOT** manipulate the HCPD-LI value themselves — the HCPD service **SHALL** generate and manage this identifier.

**Usages:**

* Use this DataType Profile: [HCPD Endpoint](StructureDefinition-hcpd-endpoint.md), [HCPD HealthcareService](StructureDefinition-hcpd-healthcareservice.md), [HCPD Location](StructureDefinition-hcpd-location.md) and [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/au.gov.digitalhealth.fhir.hcpd|current/StructureDefinition/StructureDefinition-hcpd-local-identifier.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-hcpd-local-identifier.csv), [Excel](StructureDefinition-hcpd-local-identifier.xlsx), [Schematron](StructureDefinition-hcpd-local-identifier.sch) 

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "hcpd-local-identifier",
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-local-identifier",
  "version" : "26.0.0",
  "name" : "HCPD_Local_Identifier",
  "title" : "HCPD Local Identifier (HCPD-LI)",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "This profile of Identifier defines a HCPD Local Identifier (HCPD-LI) used for system reference and internal business logic.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "type" : "Identifier",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Identifier|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Identifier",
      "path" : "Identifier",
      "short" : "HCPD Local Identifier (HCPD-LI)",
      "definition" : "Local Identifier for HCPD Location."
    },
    {
      "id" : "Identifier.type",
      "path" : "Identifier.type",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "XX"
        }]
      }
    },
    {
      "id" : "Identifier.system",
      "path" : "Identifier.system",
      "short" : "HCPD Local Identifier system",
      "definition" : "Canonical system for HCPD Local Identifiers (HCPD-LI).",
      "min" : 1,
      "fixedUri" : "http://digitalhealth.gov.au/fhir/hcpd/id/hcpd-local-identifier"
    },
    {
      "id" : "Identifier.value",
      "path" : "Identifier.value",
      "short" : "HCPD-LI",
      "min" : 1
    }]
  }
}

```
