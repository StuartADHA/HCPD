# HCPD PractitionerRole Example: Medicare Provider - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD PractitionerRole Example: Medicare Provider**

## Example PractitionerRole: HCPD PractitionerRole Example: Medicare Provider

Last updated: 2025-09-03 01:23:45+0000

Profile: [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md)

Alex Smith (National provider identifier: 8003619900015717): Medical pathologist at null (National Organisation Identifier: 8003626566707032) (Resource identifier: PR-PCA-001234)

-------

| | | | |
| :--- | :--- | :--- | :--- |
| Active: | true | Valid Period: | 2023-01-01 --> (ongoing) |
| Practitioner: | [Alex Smith (National provider identifier: 8003619900015717)](Practitioner-example-healthconnect-practitioner-1.md) | | |
| Organization: | [null (National Organisation Identifier: 8003626566707032)](Organization-example-healthconnect-organization-1.md) | | |
| Role: | Medical pathologist | | |
| Location: | [Sydney Central Medical Centre (NATA Site Number: Australian National Association of Testing Authorities (NATA) Site Number#165432)](Location-example-healthconnect-medical-centre-location-1.md) | | |
| Healthcare Service: | [Healthcare service with Residential Aged Care service type (Geriatric evaluation and management service) by null (National Organisation Identifier: 8003626566707032) (Resource identifier: HS-PCA-001234)](HealthcareService-example-healthconnect-healthcareservice-1.md) | | |
| Other Ids: | * Organization identifier/16c83541-1b44-4f01-b032-7d5095ed1def
* Medicare Provider Number/2426621B
* Australian Health Practitioner Regulation Agency Registration Number/MED0000932945
 | | |
| Contact Detail | ph: 0255507777(Work) | | |
| Availability: | * Monday: 10:00:00 - 17:00:00
* Tuesday: 09:00:00 - 17:00:00
* Wednesday: 07:00:00 - 13:00:00
* Thursday: 09:00:00 - 17:00:00
* Friday: 10:00:00 - 16:00:00
 | | |
| [Alternate Name](StructureDefinition-alternate-name.md) | Dr. Alex Smith | | |
| [Practitioner Role Communication](StructureDefinition-practitioner-role-communication.md) | Italian | | |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "PractitionerRole",
  "id" : "example-healthconnect-practitionerrole-1",
  "meta" : {
    "lastUpdated" : "2025-09-03T01:23:45Z",
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitionerrole"]
  },
  "extension" : [{
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/practitioner-role-communication",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "urn:ietf:bcp:47",
        "code" : "it",
        "display" : "Italian"
      }]
    }
  },
  {
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/alternate-name",
    "valueHumanName" : {
      "use" : "usual",
      "family" : "Smith",
      "given" : ["Dr. Alex"],
      "prefix" : ["Dr"]
    }
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "RI"
      }]
    },
    "system" : "http://ns.electronichealth.net.au/id/source/pca",
    "value" : "PR-PCA-001234"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "XX",
        "display" : "Organization identifier"
      }]
    },
    "system" : "http://digitalhealth.gov.au/fhir/hcpd/id/hcpd-local-identifier",
    "value" : "16c83541-1b44-4f01-b032-7d5095ed1def"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org.au/CodeSystem/v2-0203",
        "code" : "UPIN",
        "display" : "Medicare Provider Number"
      }]
    },
    "system" : "http://ns.electronichealth.net.au/id/medicare-provider-number",
    "value" : "2426621B"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org.au/CodeSystem/v2-0203",
        "code" : "AHPRA"
      }]
    },
    "system" : "http://hl7.org.au/id/ahpra-registration-number",
    "value" : "MED0000932945"
  }],
  "active" : true,
  "period" : {
    "start" : "2023-01-01"
  },
  "practitioner" : {
    "reference" : "Practitioner/example-healthconnect-practitioner-1"
  },
  "organization" : {
    "reference" : "Organization/example-healthconnect-organization-1"
  },
  "code" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "61207006",
      "display" : "Medical pathologist"
    }]
  }],
  "location" : [{
    "reference" : "Location/example-healthconnect-medical-centre-location-1"
  }],
  "healthcareService" : [{
    "reference" : "HealthcareService/example-healthconnect-healthcareservice-1"
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "0255507777",
    "use" : "work"
  }],
  "availableTime" : [{
    "daysOfWeek" : ["mon"],
    "allDay" : false,
    "availableStartTime" : "10:00:00",
    "_availableStartTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    },
    "availableEndTime" : "17:00:00",
    "_availableEndTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    }
  },
  {
    "daysOfWeek" : ["tue"],
    "allDay" : false,
    "availableStartTime" : "09:00:00",
    "_availableStartTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    },
    "availableEndTime" : "17:00:00",
    "_availableEndTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    }
  },
  {
    "daysOfWeek" : ["wed"],
    "allDay" : false,
    "availableStartTime" : "07:00:00",
    "_availableStartTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    },
    "availableEndTime" : "13:00:00",
    "_availableEndTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    }
  },
  {
    "daysOfWeek" : ["thu"],
    "allDay" : false,
    "availableStartTime" : "09:00:00",
    "_availableStartTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    },
    "availableEndTime" : "17:00:00",
    "_availableEndTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    }
  },
  {
    "daysOfWeek" : ["fri"],
    "allDay" : false,
    "availableStartTime" : "10:00:00",
    "_availableStartTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    },
    "availableEndTime" : "16:00:00",
    "_availableEndTime" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/timezone",
        "valueCode" : "Australia/Sydney"
      }]
    }
  }]
}

```
