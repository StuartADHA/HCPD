# FHIR Artefacts - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* **FHIR Artefacts**

## FHIR Artefacts

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Requirements: Actor Definitions 

The following artifacts define the types of individuals and/or systems that will interact as part of the use cases covered by this implementation guide.

| | |
| :--- | :--- |
| [Health Connect Provider Directory Bulk Export Requester Actor](ActorDefinition-bulk-export-requester-actor-health-connect.md) | The Health Connect Provider Directory Bulk Export Requester actor represents a system that initiates **bulk data export requests** from the Health Connect Provider Directory system. This actor is responsible for submitting properly formatted export parameters and processing the returned bulk data files. |
| [Health Connect Provider Directory Requester Actor](ActorDefinition-requester-actor-health-connect.md) | The Health Connect Provider Directory Requester actor represents a system that is requesting **Health Connect Provider Directory details** for a particular provider or resource from the Health Connect Provider Directory system. |
| [Health Connect Provider Directory Responder Actor](ActorDefinition-responder-actor-health-connect.md) | The Health Connect Provider Directory Responder actor represents the system that provides **Health Connect Provider Directory details**. It accepts requests for Directory information about practitioners or services and returns the requested information, or an error message if the request cannot be fulfilled. |

### Behavior: Capability Statements 

The following artifacts define the specific capabilities that different types of systems are expected to have in order to comply with this implementation guide. Systems conforming to this implementation guide are expected to declare conformance to one or more of the following capability statements.

| | |
| :--- | :--- |
| [Health Connect Provider Directory Bulk Export Requester](CapabilityStatement-health-connect-bulk-export-requester.md) | This CapabilityStatement resource defines the expected capabilities of the [Health Connect Provider Directory Bulk Export Requester Actor](ActorDefinition-bulk-export-requester-actor-health-connect.md) when conforming to this implementation guide. This actor is specifically designed for bulk data export operations and does not support standard FHIR REST search interactions. The listed FHIR profiles and operations describe the capabilities required for initiating bulk exports and processing the returned data. |
| [Health Connect Provider Directory Requester](CapabilityStatement-health-connect-provider-directory-requester.md) | This [CapabilityStatement](https://hl7.org/fhir/R4/capabilitystatement.html) resource defines the expected capabilities of the [Health Connect Provider Directory Requester Actor](ActorDefinition-requester-actor-health-connect.md) when conforming to this implementation guide. The complete list of FHIR profiles, RESTful operations, and search parameters supported by Health Connect Provider Directory Requester Actor are defined in this CapabilityStatement. The requirements of the Health Connect Provider Directory Requester actor may also be impacted by the rules of local jurisdictions or other contextual requirements. |
| [Health Connect Provider Directory Responder](CapabilityStatement-health-connect-provider-directory-responder.md) | This CapabilityStatement resource defines the expected capabilities of the [Health Connect Provider Directory Responder Actor](ActorDefinition-responder-actor-health-connect.md) when conforming to this implementation guide. The listed FHIR profiles, RESTful operations, and search parameters describe only those capabilities exposed for responding to Requester Actor requests. The Health Connect Provider Directory Responder supports additional internal and publishing operations that are not shown here; these are out of scope for this IG and are documented separately for publishing systems. The requirements of the Health Connect Provider Directory Responder may also be impacted by the rules of local jurisdictions or other contextual requirements. |

### Behavior: Search Parameters 

These define the properties by which a RESTful server can be searched. They can also be used for sorting and including related resources.

| | |
| :--- | :--- |
| [All Day Search Parameter](SearchParameter-allday.md) | Search HealthcareServices or PractitionerRoles by whether they are available all day. |
| [Days of Week Search Parameter](SearchParameter-daysofweek.md) | Search HealthcareServices or PractitionerRoles by days of week availability. Supports multiple days using OR logic. |
| [End Time Search Parameter](SearchParameter-endtime.md) | Search HealthcareServices or PractitionerRoles by end time. Query values must use a four-digit numeric 24 hr time format (HHMM, e.g., 0830 for 8:30am). The end time is converted to an integer to enable prefix-based time searches (e.g., gt, lt, ge, le). |
| [Endpoint Payload Mime Type Search Parameter](SearchParameter-endpoint-payloadmimetype.md) | Search for Endpoint resources by payloadMimeType. |
| [Endpoint URL Search Parameter](SearchParameter-endpoint-url.md) | Search for Endpoint resources by address (URL). |
| [HC Local Endpoint Identifier Search Parameter](SearchParameter-endpoint-hcepi.md) | Search an Endpoint record by its HC Local Identifier. |
| [Healthcare Service Type Display Search Parameter](SearchParameter-healthcareservice-type-display.md) | Search HealthcareServices by the display name of the healthcare service type. |
| [HealthcareService Billing Search Parameter](SearchParameter-healthcareservice-billing.md) | Search for HealthcareService resources by billing information. |
| [Languages Search Parameter](SearchParameter-languages.md) | Search HealthcareServices or PractitionerRoles by supported languages/communication methods. Shared across HealthcareService and PractitionerRole. Supports token based searching, i.e. `system|code` or just `code` |
| [Location Amenities Search Parameter](SearchParameter-location-amenities.md) | Search for Location resources by amenities. |
| [Location Physical Type Search Parameter](SearchParameter-location-physicaltype.md) | Search for Location resources by physicalType field. |
| [Location Postal Address Search Parameter](SearchParameter-location-locmailaddress.md) | Search for Location resources by postal address components. |
| [Practitioner Role Type Display Search Parameter](SearchParameter-practitionerrole-code-display.md) | Search PractitionerRoles by the display name of the practitioner role code. |
| [Practitioner identifier (R5 mimic)](SearchParameter-practitioner-identifier-r5.md) | Enables R5-style identifier searching across both Practitioner.identifier and Practitioner.qualification.identifier paths. This allows searching for practitioners by any identifier type including HPI-I, Ahpra and other peak body registration numbers. Works with `system|value` OR `system` OR `value`. |
| [Practitioner's Recorded Sex or Gender Search Parameter](SearchParameter-practitioner-rsg.md) | Search a Practitioner record by their recorded sex or gender. This search parameter operates on the 'value' element of the individual-recordedSexOrGender extension (typically an administrative gender code). However, to fully understand the meaning and context of the recorded sex or gender, the complete extension structure returned in results should be examined, including metadata elements such as 'type' (category of what's recorded), 'source', 'sourceDocument', 'effectivePeriod', and other contextual information. |
| [Practitioner's Registered Profession Search Parameter](SearchParameter-practitioner-regprof.md) | Search a Practitioner record by their registered profession using string values. |
| [Start Time Search Parameter](SearchParameter-starttime.md) | Search HealthcareServices or PractitionerRoles by start time. Query values must use a four-digit numeric 24 hr time format (HHMM, e.g., 0830 for 8:30am). The start time is converted to an integer to enable prefix-based time searches (e.g., gt, lt, ge, le). |
| [Suppressed Search Parameter](SearchParameter-suppressed.md) | Search resources by suppression state using the Suppressed extension. |

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [HCPD Endpoint](StructureDefinition-hcpd-endpoint.md) | This profile defines a Health Connect Provider Directory entry for a technical endpoint. |
| [HCPD Export Request Parameters](StructureDefinition-hcpd-export-request-parameters.md) | Defines a profile of a Parameters resource used to make bulk data export requests. It contains the standard FHIR bulk export parameters including _type, _typeFilter, _outputFormat, and _since for controlling the export scope and format. |
| [HCPD HealthcareService](StructureDefinition-hcpd-healthcareservice.md) | This profile defines a Health Connect Provider Directory entry for a healthcare service offered by an organisation. |
| [HCPD Location](StructureDefinition-hcpd-location.md) | This profile defines a Health Connect Provider Directory entry for a healthcare location where services are provided. |
| [HCPD Organization](StructureDefinition-hcpd-organization.md) | This profile defines a Health Connect Provider Directory entry for an organisation. |
| [HCPD Practitioner](StructureDefinition-hcpd-practitioner.md) | This profile defines a Health Connect Provider Directory entry for a healthcare practitioner. |
| [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md) | This profile defines a Health Connect Provider Directory entry for a practitioner role within an organisation. |
| [HCPD Provenance](StructureDefinition-hcpd-provenance.md) | This profile of Provenance is used to track activities related to provider directory data, recording when specific data elements of a HCPD Organization or HCPD Practitioner resource have been retrieved, updated or verified. |
| [HCPD Service Coverage Area](StructureDefinition-hcpd-service-coverage-area.md) | This profile of Location represents an Australian geographic coverage area i.e. postcodes where this service is provided. For a healthcare service, that is provided through a physical location but have eligibility restrictions applicable in terms of only residents for certain postcodes/suburbs can receive this service, then the details of coverage area and eligibility should be provided here. |

### Structures: Data Type Profiles 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [HCPD Healthcare Provider Identifier (HCPD HPI-I)](StructureDefinition-hcpd-hpii.md) | This identifier profile extends the AU HPI-I profile to include status extensions similar to those available in AU IHI. A HPI-I is assigned under the Healthcare Identifiers (HI) Service to a Practitioner. |
| [HCPD Healthcare Provider Identifier - Organisation (HCPD HPI-O)](StructureDefinition-hcpd-hpio.md) | This identifier profile extends the AU HPI-O profile to include an organization classification extension to indicate whether the organization is a 'seed' or 'network' type. |
| [HCPD Healthcare Support Service Provider - Organisation (HCPD HSP-O)](StructureDefinition-hcpd-hspo.md) | This identifier profile defines a Healthcare Support Service Provider Organisation in an Australian context. An HSP-O is assigned under the HI Service to a service (in-home care support and personal care services) where healthcare is provided. A HSP-O can only be of 'seed' type. An Organization cannot be assigned both an HPI-O and an HSP-O; only one identifier is assigned by the HI Service. |
| [HCPD Local Identifier (HCPD-LI)](StructureDefinition-hcpd-local-identifier.md) | This profile of Identifier defines a HCPD Local Identifier (HCPD-LI) used for system reference and internal business logic. |
| [HCPD SMD Target Identifier (HCPD-SMDTI)](StructureDefinition-hcpd-smd-target-identifier.md) | This identifier profile defines a SMD target identifier allocated to a healthcare practitioner, in a Health Connect Provider Directory context. |
| [HCPD Source Identifier (HCPD-SI)](StructureDefinition-hcpd-source-identifier.md) | This profile of Identifier defines a HCPD Source Identifier (HCPD-SI). |
| [Peak Body Professional Registration Number (PBPRN)](StructureDefinition-pbprn.md) | This identifier profile defines a peak body (non-Ahpra) professional registration number allocated to a healthcare practitioner. |

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Active Period](StructureDefinition-active-period.md) | The period during which the HealthcareService is considered active. |
| [Alternate Name](StructureDefinition-alternate-name.md) | This extension applies to PractitionerRole, and represents a name by which a practitioner chooses to be known in the context of the delivery of a specific healthcare service. |
| [Amenity](StructureDefinition-amenity.md) | Physical features or amenities available within, or in close proximity of, a location. Uses the NCTS Facility Amenity ValueSet. |
| [Deactivated](StructureDefinition-deactivated.md) | Identifies the party responsible for setting the parent resource to an inactive or suspended state. This extension is expected to be present whenever the resource's active or status element indicates it is no longer active, and provides audit metadata about the actor who initiated the change. |
| [HCPD Alternate Postal Address](StructureDefinition-hcpd-alternate-postal-address.md) | Alternate postal/mailing address for correspondence (PO Box or mailing address) that is distinct from the registered physical address. |
| [HI Service Organisation Classification](StructureDefinition-hi-org-classification.md) | Extension to record whether an organisation's HPIO is a 'seed' or 'network' type in the HI service. |
| [HI Services Identifier Status](StructureDefinition-hi-services-identifier-status.md) | Indicates the status of the Australian Healthcare Services Identifier. |
| [IAR Levels of Care](StructureDefinition-iar-levels-of-care.md) | Indicates the IAR (Initial Assessment and Referral) Levels of Care for a healthcare service. |
| [New Patient Availability](StructureDefinition-new-patient-availability.md) | Indicates whether the healthcare service is accepting new patients. Patterned after PCA New Patient Availability extension.Context of Use: HealthcareService |
| [Practitioner Role Communication](StructureDefinition-practitioner-role-communication.md) | Practitioner Role Communication. This extension captures communication preferences and capabilities for a practitioner in a given role. |
| [Referral Information for Referrer](StructureDefinition-referral-information-for-referrer.md) | Referral instructions and information for healthcare service providers that may wish to refer patients / clients to the healthcare service. |
| [Suppression Indicator for Visibility](StructureDefinition-suppressed.md) | Indicates whether the parent resource should be hidden from display in the Provider Directory. Contains coded information about the actor who initiated the suppression and optional control flags. |

### Terminology: Value Sets 

These define sets of codes used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [HI Service Organization Classification ValueSet](ValueSet-hi-org-classification-vs.md) | All codes in the HI Service Organization Classification CodeSystem code system. |
| [HI Services Identifier Status Value Set](ValueSet-hi-services-identifier-status-vs.md) | All codes in the HI Services Identifier Status Code System code system. |
| [Responsible Party Type](ValueSet-responsible-party-type.md) | ValueSet containing codes that indicate the resource type of the party that is responsible for the current value of a data element. |
| [Service Provision Code ValueSet](ValueSet-service-provision-code-vs.md) | The Service Provision Code ValueSet includes values that may be used to identify the service provision condition of a healthcare service. |

### Terminology: Code Systems 

These define new code systems used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [HI Service Organisation Classification CodeSystem](CodeSystem-hi-org-classification-cs.md) | Internal code system that describes whether an organisation is a 'seed' or 'network' type in the HI Service. |
| [HI Services Identifier Status Code System](CodeSystem-hi-services-identifier-status-cs.md) | This code system defines concepts that identify the status of a Healthcare Services Identifier, i.e. HPII, HPIO or HSPO. |
| [Responsible Party Type](CodeSystem-responsible-party-type.md) | CodeSystem containing codes that indicate the resource type of the party that is responsible for the current value of a data element. |
| [Service Provision CodeSystem](CodeSystem-service-provision-cs.md) | The Service Provision CodeSystem defines a concept (in addition to those defined in [Service Provision Conditions Australian Concepts](https://hl7.org.au/fhir/4.1.0/CodeSystem-service-provision-conditions.html) that may be used to identify the service provision condition of a healthcare service in HCPD. |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [HCPD Endpoint Example: HL7 FHIR Messaging](Endpoint-example-hcpd-endpoint-hl7-fhir-messaging.md) | An example Endpoint with HL7 FHIR Messaging Endpoint conforming to the HCPD Endpoint profile. |
| [HCPD Export Request Parameters Example: Cardiology Services in Balmain](Parameters-example-hcpd-export-request-parameters-1.md) | An example Parameters resource conforming to the HCPD Export Request Parameters profile, requesting export of all cardiology services in Balmain including organizations, locations, services, roles and practitioners. |
| [HCPD Export Request Parameters Example: Delta Export Since Last Retrieval](Parameters-example-hcpd-export-request-parameters-2.md) | An example Parameters resource showing a delta export request with _since parameter for retrieving changes since a previous export. |
| [HCPD HealthcareService Example: Geriatric evaluation and management service](HealthcareService-example-healthconnect-healthcareservice-2.md) | A HealthcareService example demonstrating all elements defined in the HCPD HealthcareService profile, including all extensions, identifiers, availability windows, eligibility criteria, and telecoms. |
| [HCPD HealthcareService Example: Residential Aged Care](HealthcareService-example-healthconnect-healthcareservice-1.md) | A Residential Aged Care HealthcareService example conforming to the HCPD HealthcareService profile. |
| [HCPD Location Example: Medical Centre (Physical Building)](Location-example-healthconnect-medical-centre-location-1.md) | A physical medical centre location example with wheelchair access, conforming to the HCPD Location profile. |
| [HCPD Location Example: Mobile Healthcare Unit](Location-example-healthconnect-mobile-healthcare-unit-1.md) | A mobile healthcare unit location example with wheelchair access, conforming to the HCPD Location profile. |
| [HCPD Location Example: Mobile Unit Service Coverage Area](Location-example-healthconnect-mobile-unit-coverage-area-1.md) | A virtual coverage area defining the geographical service boundary for the mobile healthcare unit. |
| [HCPD Location Example: Virtual Telehealth Service](Location-example-healthconnect-virtual-telehealth-service-1.md) | A virtual telehealth service location example without physical address, conforming to the HCPD Location profile. |
| [HCPD Organization Example: Aged Care Facility](Organization-example-healthconnect-organization-1.md) | An Aged Care Facility example conforming to the HCPD Organization profile. |
| [HCPD Organization Example: Home Care Support Service](Organization-example-healthconnect-organization-2.md) | A Home Care Support Service example conforming to the HCPD Organization profile with HSP-O identifier. |
| [HCPD Practitioner Example: Alex Smith](Practitioner-example-healthconnect-practitioner-1.md) | An example Practitioner (Alex Smith) conforming to the HCPD Practitioner profile. |
| [HCPD Practitioner Example: Alice Anderson (Balmain)](Practitioner-example-balmain-practitioner-1.md) | Practitioner serving Balmain examples. |
| [HCPD Practitioner Example: External Record (PRN)](Practitioner-external-hcpd-practitioner-record.md) | An external practitioner record example (PRN identifier) conforming to the HCPD Practitioner profile. |
| [HCPD PractitionerRole Example: Ahpra-Only General Practitioner (Balmain)](PractitionerRole-example-healthconnect-practitionerrole-2.md) | An example PractitionerRole for a general practitioner registered with Ahpra only (no Medicare provider number), working part-time at the Balmain service location. |
| [HCPD PractitionerRole Example: Medicare Provider](PractitionerRole-example-healthconnect-practitionerrole-1.md) | An example PractitionerRole (Medicare) that conforms to the HCPD PractitionerRole profile. |
| [HCPD Provenance Example: Practitioner Name Amendment](Provenance-provenance-practitioner-name-update.md) | Demonstrates provenance tracking for a practitioner's name amendment, conforming to the HCPD Provenance profile. |
| [HCPD Provenance Example: Practitioner Phone Amendment](Provenance-provenance-practitioner-phone-update.md) | Demonstrates provenance tracking for a practitioner's phone number amendment, conforming to the HCPD Provenance profile. |
| [HCPD Service Coverage Area Example: Balmain (2041)](Location-example-healthconnect-service-coverage-area-balmain-1.md) | A service coverage area representing the Balmain suburb postcode (2041), used to define the geographic eligibility boundary for a healthcare service. |
| [Sydney Private Clinic: FHIR Referral Endpoint](Endpoint-example-hcpd-endpoint-referral.md) | FHIR REST endpoint for Sydney Private Clinic. Receives electronic referrals (ServiceRequest) for Dr. Emily Chen's gynaecology service. Selected via Provider Directory search: location Sydney, wait time <2 weeks. |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.

