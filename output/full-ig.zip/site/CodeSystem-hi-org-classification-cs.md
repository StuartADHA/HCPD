# HI Service Organisation Classification CodeSystem - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HI Service Organisation Classification CodeSystem**

## CodeSystem: HI Service Organisation Classification CodeSystem 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/hi-org-classification-cs | *Version*:26.0.0 |
| Active as of 2026-09-10 | *Computable Name*:HI_Org_Classification_CS |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

 
Internal code system that describes whether an organisation is a 'seed' or 'network' type in the HI Service. 

 
This CodeSystem supports the classification of organisations within provider directory systems, enabling the distinction between 'seed' organisations (primary entities in the HI Service) and 'network' organisations (subsidiary or related entities). 

 This Code system is referenced in the content logical definition of the following value sets: 

* [HI Service Organization Classification ValueSet](ValueSet-hi-org-classification-vs.md)

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "hi-org-classification-cs",
  "meta" : {
    "profile" : ["https://healthterminologies.gov.au/fhir/StructureDefinition/complete-code-system-4"]
  },
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/CodeSystem/hi-org-classification-cs",
  "version" : "26.0.0",
  "name" : "HI_Org_Classification_CS",
  "title" : "HI Service Organisation Classification CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-10",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "Internal code system that describes whether an organisation is a 'seed' or 'network' type in the HI Service.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "purpose" : "This CodeSystem supports the classification of organisations within provider directory systems, enabling the distinction between 'seed' organisations (primary entities in the HI Service) and 'network' organisations (subsidiary or related entities).",
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "caseSensitive" : true,
  "compositional" : false,
  "versionNeeded" : true,
  "content" : "complete",
  "count" : 2,
  "concept" : [{
    "code" : "seed",
    "display" : "Seed",
    "definition" : "The organisation is a 'seed' in the HI Service"
  },
  {
    "code" : "network",
    "display" : "Network",
    "definition" : "The organisation is a 'network' in the HI Service"
  }]
}

```
