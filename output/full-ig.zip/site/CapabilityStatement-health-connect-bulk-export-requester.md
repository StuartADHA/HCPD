# Health Connect Provider Directory Bulk Export Requester - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **Health Connect Provider Directory Bulk Export Requester**

## CapabilityStatement: Health Connect Provider Directory Bulk Export Requester 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/CapabilityStatement/health-connect-bulk-export-requester | *Version*:26.0.0 |
| Active as of 2026-09-10 | *Computable Name*:HealthConnectProviderDirectoryBulkExportRequester |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

 
This CapabilityStatement resource defines the expected capabilities of the [Health Connect Provider Directory Bulk Export Requester Actor](ActorDefinition-bulk-export-requester-actor-health-connect.md) when conforming to this implementation guide. This actor is specifically designed for bulk data export operations and does not support standard FHIR REST search interactions. The listed FHIR profiles and operations describe the capabilities required for initiating bulk exports and processing the returned data. 

 [Raw OpenAPI-Swagger Definition file](health-connect-bulk-export-requester.openapi.json) | [Download](health-connect-bulk-export-requester.openapi.json) 

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "health-connect-bulk-export-requester",
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/CapabilityStatement/health-connect-bulk-export-requester",
  "version" : "26.0.0",
  "name" : "HealthConnectProviderDirectoryBulkExportRequester",
  "title" : "Health Connect Provider Directory Bulk Export Requester",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-10",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "This CapabilityStatement resource defines the expected capabilities of the [Health Connect Provider Directory Bulk Export Requester Actor](ActorDefinition-bulk-export-requester-actor-health-connect.html) when conforming to this implementation guide. This actor is specifically designed for bulk data export operations and does not support standard FHIR REST search interactions. The listed FHIR profiles and operations describe the capabilities required for initiating bulk exports and processing the returned data.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "kind" : "requirements",
  "fhirVersion" : "4.0.1",
  "format" : ["json"],
  "_format" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
      "valueCode" : "SHALL"
    }]
  }],
  "rest" : [{
    "mode" : "client",
    "security" : {
      "service" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/restful-security-service",
          "code" : "OAuth",
          "display" : "OAuth"
        }]
      }],
      "description" : "All interactions SHALL be secured using OAuth protocols. It SHALL support authentication, authorisation, and audit logging in accordance with local policy and regulatory requirements."
    },
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "Parameters",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-export-request-parameters|26.0.0",
      "documentation" : "This section defines the supported interactions for submitting [HCPD Export Request Parameters](StructureDefinition-hcpd-export-request-parameters.html) resources as search instructions for bulk data export operations. The client SHALL be able to form properly structured Parameters resources containing _outputFormat, _type, _typeFilter, and optionally _since parameters to control bulk data export scope and format. The server validates these parameters before executing the bulk export.",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type",
        "documentation" : "Submit HCPD Export Request Parameters as search instructions for bulk data export operations"
      }],
      "versioning" : "versioned",
      "readHistory" : false,
      "searchInclude" : ["Provenance:target",
      "Organization:partOf",
      "Location:organization",
      "Location:endpoint",
      "HealthcareService:location",
      "HealthcareService:organization",
      "HealthcareService:endpoint",
      "PractitionerRole:practitioner",
      "PractitionerRole:service",
      "PractitionerRole:organization",
      "PractitionerRole:location",
      "PractitionerRole:endpoint"],
      "searchRevInclude" : ["Location:organization",
      "Provenance:target",
      "HealthcareService:location",
      "PractitionerRole:service",
      "PractitionerRole:practitioner",
      "HealthcareService:endpoint",
      "Location:endpoint",
      "PractitionerRole:endpoint"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "_outputFormat",
        "type" : "string",
        "documentation" : "Specifies the output format for bulk export. Fixed to application/fhir+ndjson."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "_type",
        "type" : "string",
        "documentation" : "Comma-separated list of resource types to include in the bulk export (e.g. Organization,Location,HealthcareService,Practitioner,PractitionerRole,Endpoint,Provenance)."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "_typeFilter",
        "type" : "string",
        "documentation" : "FHIR search expression applied to a specific resource type to filter which resources are included in the export. One _typeFilter SHALL be provided for each resource type specified in _type. Supported filter expressions include: Location?address-state, Location?address-postalcode, Location?address-city, Location?near, Organization?identifier, Organization?name, HealthcareService?service-type, PractitionerRole?location.address-city, PractitionerRole?location.address-postalcode."
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHOULD"
        }],
        "name" : "_since",
        "type" : "date",
        "documentation" : "Only resources updated since the specified instant (ISO 8601) will be included in the export. Used for delta/incremental extracts."
      }]
    },
    {
      "type" : "Binary",
      "documentation" : "This section defines the required capabilities for retrieving Binary resources containing bulk exported data files. After submitting export parameters and receiving export completion notification, the client SHALL be able to retrieve the Binary resources containing the exported data in ndjson format.",
      "interaction" : [{
        "code" : "read",
        "documentation" : "Read Binary resources containing bulk exported data files"
      }],
      "versioning" : "versioned",
      "readHistory" : false
    }],
    "operation" : [{
      "name" : "export",
      "definition" : "http://hl7.org/fhir/uv/bulkdata/OperationDefinition/export|3.0.0",
      "documentation" : "This operation enables the client to initiate bulk data export requests by submitting [HCPD Export Request Parameters](StructureDefinition-hcpd-export-request-parameters.html) resources to the Health Connect Provider Directory Responder. The operation SHALL accept parameters including _outputFormat, _type, _typeFilter, and optionally _since to control bulk data export scope and format. The operation SHALL return URLs to ndjson files containing the requested resource types. Bulk data extraction returns all resources regardless of active status or suppression; implementers SHALL respect the suppressed and deactivated-by extensions on returned resources, filtering these resources before displaying them to end consumers."
    }]
  }]
}

```
