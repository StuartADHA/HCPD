# HCPD Service Coverage Area Example: Balmain (2041) - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Service Coverage Area Example: Balmain (2041)**

## Example Location: HCPD Service Coverage Area Example: Balmain (2041)

Last updated: 2026-09-10 10:00:00+1000

Profile: [HCPD Service Coverage Area](StructureDefinition-hcpd-service-coverage-area.md)

Balmain Service Coverage Area

-------

| | |
| :--- | :--- |
| Status: | Active |
| Description: | Coverage area for healthcare services available to residents of Balmain and surrounding postcodes in the Inner West of Sydney. |
| Address: | Balmain NSW 2041 AU |
| Managed By: | [null (National Organisation Identifier: 8003626566707032)](Organization-example-healthconnect-organization-1.md) |
| Suppression Indicator for Visibility: | * suppressedBy: Organisation initiated
 |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "example-healthconnect-service-coverage-area-balmain-1",
  "meta" : {
    "lastUpdated" : "2026-09-10T10:00:00+10:00",
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-service-coverage-area"]
  },
  "extension" : [{
    "extension" : [{
      "url" : "suppressedBy",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
          "code" : "organisation-initiated"
        }]
      }
    }],
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed"
  }],
  "status" : "active",
  "name" : "Balmain Service Coverage Area",
  "description" : "Coverage area for healthcare services available to residents of Balmain and surrounding postcodes in the Inner West of Sydney.",
  "address" : {
    "city" : "Balmain",
    "state" : "NSW",
    "postalCode" : "2041",
    "country" : "AU"
  },
  "managingOrganization" : {
    "reference" : "Organization/example-healthconnect-organization-1"
  }
}

```
