# HCPD Endpoint Example: HL7 FHIR Messaging - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Endpoint Example: HL7 FHIR Messaging**

## Example Endpoint: HCPD Endpoint Example: HL7 FHIR Messaging

Information Source: [http://ns.electronichealth.net.au/id/source/pca](http://ns.electronichealth.net.au/id/source/pca)

Profile: [HCPD Endpoint](StructureDefinition-hcpd-endpoint.md)

Sydney General Hospital FHIR Messaging Endpoint (HL7 FHIR Messaging (Endpoint Connection Type#hl7-fhir-msg)): https://example.org/smd-sydneyhospital/secure-messaging/endpoint

-------

| | |
| :--- | :--- |
| Status: | Off |
| Address: | [https://example.org/smd-sydneyhospital/secure-messaging/endpoint](https://example.org/smd-sydneyhospital/secure-messaging/endpoint) |
| Connection Type: | [Endpoint Connection Type: hl7-fhir-msg](http://terminology.hl7.org/7.4.0/CodeSystem-endpoint-connection-type.html#endpoint-connection-type-hl7-fhir-msg)(HL7 FHIR Messaging) |
| Payload Type: | Any |
| Mime Type: | * application/pdf
* application/fhir+xml
* application/fhir+json
 |
| Contact Detail | [hl7-fhir-message-support@sydneyhospital.org.au](mailto:hl7-fhir-message-support@sydneyhospital.org.au) |
| Other Ids: | * Resource identifier/EP-NHSD-001234567890
* Organization Identifier/EP001234567890
 |
| Suppression Indicator for Visibility: | * suppressedBy: Organisation initiated
 |
| [Encryption Certificate PEM X509](http://hl7.org.au/fhir/6.0.0/StructureDefinition-encryption-certificate-pem-x509.html) | LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSURYVENDQWtXZ0F3SUJBZ0lKQU1mK0R6UjBWV... |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "example-hcpd-endpoint-hl7-fhir-messaging",
  "meta" : {
    "source" : "http://ns.electronichealth.net.au/id/source/pca",
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-endpoint"]
  },
  "extension" : [{
    "extension" : [{
      "url" : "suppressedBy",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
          "code" : "organisation-initiated"
        }]
      }
    }],
    "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed"
  },
  {
    "url" : "http://hl7.org.au/fhir/StructureDefinition/encryption-certificate-pem-x509",
    "valueString" : "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSURYVENDQWtXZ0F3SUJBZ0lKQU1mK0R6UjBWV..."
  }],
  "identifier" : [{
    "system" : "http://ns.electronichealth.net.au/smd/target",
    "value" : "SMD001234567890"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "RI"
      }]
    },
    "system" : "http://ns.electronichealth.net.au/id/source/nhsd",
    "value" : "EP-NHSD-001234567890"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "XX",
        "display" : "Organization Identifier"
      }]
    },
    "system" : "http://digitalhealth.gov.au/fhir/hcpd/id/hcpd-local-identifier",
    "value" : "EP001234567890"
  }],
  "status" : "off",
  "connectionType" : {
    "system" : "http://terminology.hl7.org/CodeSystem/endpoint-connection-type",
    "code" : "hl7-fhir-msg",
    "display" : "HL7 FHIR Messaging"
  },
  "name" : "Sydney General Hospital FHIR Messaging Endpoint",
  "contact" : [{
    "system" : "email",
    "value" : "hl7-fhir-message-support@sydneyhospital.org.au",
    "use" : "work"
  }],
  "payloadType" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/endpoint-payload-type",
      "code" : "any",
      "display" : "Any"
    }]
  }],
  "payloadMimeType" : ["application/pdf",
  "application/fhir+xml",
  "application/fhir+json"],
  "address" : "https://example.org/smd-sydneyhospital/secure-messaging/endpoint"
}

```
