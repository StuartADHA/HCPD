# Health Connect Provider Directory API Overview - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* **Health Connect Provider Directory API Overview**

## Health Connect Provider Directory API Overview

### Overview

The Health Connect Australia Provider Directory (the Directory) API gives FHIR-based access to provider and organisation directory data. Clients can search it, read individual records, and export in bulk.

This API is the national implementation of the Health Connect Australia Provider Directory FHIR Implementation Guide.

This specification defines how clients interact with the APIs in practice, focusing on supported operations, validation rules, and operational requirements for integration. The Health Connect Australia Provider Directory FHIR IG remains the normative source of truth for resource structure and semantics.

Detailed behaviour for each capability is described on its own page:

* [Search API technical specification](search-api.md) - real-time search and read behaviour. Use the Search API for real-time queries and interactive lookups.
* [Export API technical specification](export-api.md) - asynchronous bulk data export behaviour. Use the Export API for large-scale extracts and local data synchronisation.

### API features and capabilities

The public API does two things: real-time search and read, and asynchronous bulk export.

Search locates practitioners, organisations, services and the resources linked to them, using standard FHIR search parameters with paging and filtering.

Export returns large datasets asynchronously through the FHIR Bulk Data Access `$export` pattern, for clients keeping a local copy of the directory.

### Supported resources

The public API provides access to the following FHIR resources:

* `Organization`
* `Practitioner`
* `PractitionerRole`
* `HealthcareService`
* `Location`
* `Endpoint`
* `Provenance`

All resources conform to Health Connect Australia Provider Directory FHIR profiles, including constraints on structure, cardinality, search parameters, and terminology. For the profiles, extensions, search parameters and terminology that apply to each resource type, see the [Implementation Guide home page](index.md).

### Environments and base URLs

| | | |
| :--- | :--- | :--- |
| SVT | `https://svt.pd.healthconnect.digitalhealth.gov.au/api/v1/fhir` | Vendor test environment |
| PROD | `https://pd.healthconnect.digitalhealth.gov.au/api/v1/fhir` | Live environment |

Environment access is arranged as part of client onboarding.

#### Endpoint path convention

All examples in these API pages are path-only and are relative to the environment base URL above.

Example:

* Full URL: `https://healthconnect.digitalhealth.gov.au/api/v1/fhir/Organization?name=clinic`
* Path-only form used in examples: `/Organization?name=clinic`

### Authentication and authorisation

All API requests must include a valid OAuth2 bearer token (JWT) issued by the Health Connect Authorisation Service (HCAS), presented as `Authorization: Bearer <jwt>`.

#### Required scopes by operation

Clients must present a valid JWT token containing the required scope on every request:

| | |
| :--- | :--- |
| Search operations | `search` |
| Read operations | `read` |
| Export kickoff, polling, and file download operations | `export` |

Presenting a token that is not valid or has expired results in a `401 Unauthorized` response.

Presenting a token without the correct scope for a particular operation results in a `403 Forbidden` response.

Example:

```
GET /Organization?identifier=8003626566707032
Authorization: Bearer <jwt>
X-Request-ID: <uuid>
Accept: application/fhir+json

```

#### Client registration and token issuance

Registration, token issuance, token lifetime and renewal, and authorisation error conditions are covered in the [National Digital Health Authorisation Service Developer Guide](https://implementer.digitalhealth.gov.au/resources/hca/national-digital-health-authorisation-service-developer-guide).

### Record status

A record is either active or inactive. `Practitioner`, `PractitionerRole`, `Organization` and `HealthcareService` carry a boolean `active`; `Location` and `Endpoint` carry `status`.

Search returns active records by default. Inactive records are returned only when the state is asked for explicitly. See [Data visibility rules for search](search-api.md#data-visibility-rules-for-search) for the permitted values on each type and how to request them.

Records may be suppressed by the upstream systems. Suppressed records are never returned in any search. Their status updates are included in incremental exports so that client systems can remove them locally. See [Visibility rules for export](export-api.md#visibility-rules-for-export).

### Error handling

All errors are returned as a FHIR `OperationOutcome`. Every `OperationOutcome` also carries the request correlation identifier as an additional informational issue, so that a client-side failure can be correlated with server-side logs for traceability.

```
{
  "resourceType": "OperationOutcome",
  "issue": [
    {
      "severity": "error",
      "code": "invalid",
      "diagnostics": "An error message here"
    },
    {
      "severity": "information",
      "code": "informational",
      "diagnostics": "X-Request-ID: 9c63ec77-8d78-4bf1-a170-9909b33a786b"
    }
  ]
}

```

### Elements not supported

The Directory will not store, and the API will not return the following `Practitioner` elements:

* `genderIdentity extension`
* `gender`
* `birthDate`
* `photo`
* `address`
* `AUPBSPrescriberNumber identifier`

If FHIR allows searching by these restricted parameters, the search will be rejected. See [Restricted search parameters](search-api.md#restricted-search-parameters).

Use `rsg` in place of gender and gender identity. See the [Practitioner's Recorded Sex or Gender](SearchParameter-practitioner-rsg.md) search parameter.

The PBS prescriber number is identified by the system `http://ns.electronichealth.net.au/id/medicare-prescriber-number`.

#### HTTP status mapping

| | | |
| :--- | :--- | :--- |
| 400 | Bad Request | Invalid FHIR query or parameters; restricted search parameter; paging beyond the result threshold |
| 401 | Unauthorized | Missing or invalid token |
| 403 | Forbidden | Missing required scope; policy restriction; unsupported resource type in an export request |
| 404 | Not Found | Resource not found or not visible |
| 409 | Conflict | Duplicate or inconsistent data |
| 429 | Too Many Requests | Rate limit exceeded |
| 500 | Server Error | Internal system failure |
| 503 | Service Unavailable | Temporary system outage |

Note that an empty search result is **not** an error. A search that matches nothing returns `200 OK` with a `Bundle` of `total: 0`. See [No matching records](search-api.md#no-matching-records).

#### Rate limits

Request rate limits and per-client quotas will be introduced in a future release. When implemented, clients exceeding a limit should expect `429 Too Many Requests` and should back off before retrying. The limits and recommended backoff behaviour will be documented before release.

Export status polling is already limited to one request per status endpoint every 120 seconds - see [Polling and completion](export-api.md#polling-and-completion).

### Glossary

| | |
| :--- | :--- |
| Active record | A record whose`active`element is`true`(or, for`Location`and`Endpoint`, whose`status`is`active`). Returned by default in search results and standard exports. |
| Inactive record | A record whose`active`element is`false`(or, for`Location`,`status = inactive`; for`Endpoint`,`status = off`). Excluded from default search results and standard exports, and retrievable by explicitly requesting the inactive state. |
| Suppressed record | A record excluded from outward visibility. Suppressed records cannot be searched or returned through the Search API. Their status updates are included in incremental exports so client systems can remove them locally. |
| HCAS | Health Connect Authorisation Service. |
| HI Service | Healthcare Identifiers Service. |
| HPI-I | Healthcare Provider Identifier - Individual. |
| HPI-O | Healthcare Provider Identifier - Organisation. |
| PCA | Provider Connect Australia. |
| RSG | Recorded Sex or Gender. |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.

