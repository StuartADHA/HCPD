# Capability Statements - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **Capability Statements**

## Capability Statements

The following CapabilityStatements define the specific capabilities that different types of systems are expected to have in order to comply with this implementation guide. Systems conforming to this implementation guide are expected to declare conformance to one or more of the following capability statements.

* [Health Connect Provider Directory Requester](CapabilityStatement-health-connect-provider-directory-requester.md)

This CapabilityStatement describes the basic rules for the Health Connect Provider Directory Requester Actor that is responsible for making queries to retrieve information from the [Health Connect Provider Directory Responder Actor](ActorDefinition-responder-actor-health-connect.md).

* [Health Connect Provider Directory Bulk Export Requester](CapabilityStatement-health-connect-bulk-export-requester.md)

This CapabilityStatement describes the specific rules for the [Health Connect Provider Directory Bulk Export Requester Actor](ActorDefinition-bulk-export-requester-actor-health-connect.md) that is responsible for initiating bulk data export operations. This actor submits properly formatted export parameters to the Health Connect Provider Directory Responder and processes the returned bulk data files. Implementers **SHALL** respect the `suppressed` and `deactivated-by` extensions on returned resources, filtering these resources before displaying them to end consumers of the HCPD.

* [Health Connect Provider Directory Responder](CapabilityStatement-health-connect-provider-directory-responder.md)

This CapabilityStatement describes the basic rules for the [Health Connect Provider Directory Responder Actor](ActorDefinition-responder-actor-health-connect.md) that is responsible for providing responses to queries submitted by a Health Connect Provider Directory Requester Actor. The complete list of FHIR profiles, RESTful operations, and search parameters supported by Health Connect Provider Directory Responder are defined in this CapabilityStatement.

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.

