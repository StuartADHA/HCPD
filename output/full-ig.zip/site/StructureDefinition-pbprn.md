# Peak Body Professional Registration Number (PBPRN) - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **Peak Body Professional Registration Number (PBPRN)**

## Data Type Profile: Peak Body Professional Registration Number (PBPRN) 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/cc/StructureDefinition/pbprn | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:Peak_Body_Professional_Registration_Number |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

 
This identifier profile defines a peak body (non-Ahpra) professional registration number allocated to a healthcare practitioner. 

No data is entered directly into Health Connect; all Directory content is sourced from authoritative systems including [PCA](https://developer.digitalhealth.gov.au/fhir/provider-connect-australia/current/index.html?src=/), HI-Service, and NHSD.

### Peak Body Professional Registration Number (PBPRN)

The Peak Body Professional Registration Number profile defines an identifier for a healthcare practitioner’s professional registration, as recorded in the Health Connect Provider Directory context (as received from HI services). This identifier is used to capture the registration number assigned by a professional association or peak body, particularly for practitioners who are **not Ahpra-registered**, and is recorded against a Practitioner's HPI-I record.

### Usage notes

* This is a profile of the `identifier` element on [HCPD Practitioner](StructureDefinition-hcpd-practitioner.md) and [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md).
* Use this profile when a practitioner's professional registration number is issued by a non-Ahpra professional association or peak body.
* **Cardinality differences**: HCPD Practitioner allows 0 to many PRN identifiers (`0..*`), while HCPD PractitionerRole allows only 0 to 1 PRN identifier (`0..1`).
* In this identifier profile the assigning system is **mandatory** but is not fixed. This is by design as this identifier may be used to represent many different non-Ahpra peak bodies. See [Supported Peak Body Systems](pbprn-systems.md) for the full list of valid `system` URIs.
* The PRN should be used in addition to, or instead of, an Ahpra registration number, depending on the practitioner’s registration status.
* Ensure that the system and value are populated according to the assigning authority’s requirements for accurate identification and interoperability.
* The PRN enables implementers to distinguish between different types of practitioner registration numbers and to support Directory queries, reconciliation, and validation.

#### Key requirements

* The profile fixes the `type` element to the v2 identifier code `PRN` (Provider number) from the v2-0203 code system (this is implemented in the profile as `type = $v2-0203-int#PRN`). Implementations **SHOULD** use the following coding when constructing the `type` element: 

```
  {
      "coding": [
          {
              "system": "http://terminology.hl7.org/CodeSystem/v2-0203",
              "code": "PRN",
              "display": "Provider number"
          }
      ]
  }

```

 
* The `value` element is mandatory (cardinality 1..) and holds the practitioner's registration number as assigned by the authority (for example `1234567`).
* The `assigner` element is not constrained by this profile (it may be populated to reference the issuing organisation where available, but it is not required). Implementers are encouraged to populate `assigner.display` to improve provenance and traceability when the issuing Organization resource is not available.
* A warning-level invariant `inv-01-system-or-assigner` checks that a `system` or `assigner` (or both) is present to ensure proper identification of the authoritative body that issued the registration number.

Implementers must ensure that the Peak Body Registration Number is used only for valid, assigned registration numbers and that all required elements are present and correct. This supports accurate practitioner identification and data integrity across the Health Connect Provider Directory.

**Usages:**

* Use this DataType Profile: [HCPD Practitioner](StructureDefinition-hcpd-practitioner.md) and [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/au.gov.digitalhealth.fhir.hcpd|current/StructureDefinition/StructureDefinition-pbprn.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-pbprn.csv), [Excel](StructureDefinition-pbprn.xlsx), [Schematron](StructureDefinition-pbprn.sch) 

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "pbprn",
  "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/pbprn",
  "version" : "26.0.0",
  "name" : "Peak_Body_Professional_Registration_Number",
  "title" : "Peak Body Professional Registration Number (PBPRN)",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "This identifier profile defines a peak body (non-Ahpra) professional registration number allocated to a healthcare practitioner.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "type" : "Identifier",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Identifier|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Identifier",
      "path" : "Identifier",
      "short" : "Peak Body Professional Registration Number",
      "definition" : "Professional Registration Number that the practitioner has with Professional association / Peak body association (for non-Ahpra registered practitioners), as recorded against the HPI-I record."
    },
    {
      "id" : "Identifier.type",
      "path" : "Identifier.type",
      "short" : "Coded identifier type for professional registration number",
      "min" : 1,
      "fixedCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "PRN"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Identifier.type.text",
      "path" : "Identifier.type.text",
      "patternString" : "Peak Body Professional Registration Number"
    },
    {
      "id" : "Identifier.system",
      "path" : "Identifier.system",
      "short" : "Professional registration number system.",
      "definition" : "Namespace for the professional registration number.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Identifier.value",
      "path" : "Identifier.value",
      "short" : "Professional registration number value.",
      "definition" : "Professional registration number value.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Identifier.assigner",
      "path" : "Identifier.assigner",
      "mustSupport" : true
    },
    {
      "id" : "Identifier.assigner.display",
      "path" : "Identifier.assigner.display",
      "short" : "Text alternative for the Organization",
      "min" : 1,
      "mustSupport" : true
    }]
  }
}

```
