# Health Connect Provider Directory Responder - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **Health Connect Provider Directory Responder**

## CapabilityStatement: Health Connect Provider Directory Responder 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/CapabilityStatement/health-connect-provider-directory-responder | *Version*:26.0.0 |
| Active as of 2026-09-10 | *Computable Name*:HealthConnectProviderDirectoryResponder |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

 
This CapabilityStatement resource defines the expected capabilities of the [Health Connect Provider Directory Responder Actor](ActorDefinition-responder-actor-health-connect.md) when conforming to this implementation guide. The listed FHIR profiles, RESTful operations, and search parameters describe only those capabilities exposed for responding to Requester Actor requests. The Health Connect Provider Directory Responder supports additional internal and publishing operations that are not shown here; these are out of scope for this IG and are documented separately for publishing systems. The requirements of the Health Connect Provider Directory Responder may also be impacted by the rules of local jurisdictions or other contextual requirements. 

 [Raw OpenAPI-Swagger Definition file](health-connect-provider-directory-responder.openapi.json) | [Download](health-connect-provider-directory-responder.openapi.json) 

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "health-connect-provider-directory-responder",
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/CapabilityStatement/health-connect-provider-directory-responder",
  "version" : "26.0.0",
  "name" : "HealthConnectProviderDirectoryResponder",
  "title" : "Health Connect Provider Directory Responder",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-10",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "This CapabilityStatement resource defines the expected capabilities of the [Health Connect Provider Directory Responder Actor](ActorDefinition-responder-actor-health-connect.html) when conforming to this implementation guide. The listed FHIR profiles, RESTful operations, and search parameters describe only those capabilities exposed for responding to Requester Actor requests. The Health Connect Provider Directory Responder supports additional internal and publishing operations that are not shown here; these are out of scope for this IG and are documented separately for publishing systems. The requirements of the Health Connect Provider Directory Responder may also be impacted by the rules of local jurisdictions or other contextual requirements.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "kind" : "instance",
  "implementation" : {
    "description" : "Health Connect Provider Directory Responder FHIR Server",
    "url" : "http://digitalhealth.gov.au/fhir/hcpd"
  },
  "fhirVersion" : "4.0.1",
  "format" : ["json"],
  "_format" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
      "valueCode" : "SHALL"
    }]
  }],
  "rest" : [{
    "mode" : "server",
    "security" : {
      "service" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/restful-security-service",
          "code" : "OAuth",
          "display" : "OAuth"
        }]
      }],
      "description" : "All interactions SHALL be secured using OAuth protocols. It SHALL support authentication, authorisation, and audit logging in accordance with local policy and regulatory requirements."
    },
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "Provenance",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-provenance|26.0.0",
      "documentation" : "HC Provenance resources track the lineage of data retrieved, updated, or verified from external systems of record.",
      "interaction" : [{
        "code" : "read",
        "documentation" : "Read HC Provenance records"
      },
      {
        "code" : "search-type",
        "documentation" : "Search HC Provenance records by various parameters"
      }],
      "versioning" : "versioned",
      "readHistory" : false,
      "searchInclude" : ["Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "target",
        "definition" : "http://hl7.org/fhir/SearchParameter/Provenance-target|4.0.1",
        "type" : "reference"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "Organization",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-organization|26.0.0",
      "documentation" : "This section defines the supported interactions for the [HCPD Organization](StructureDefinition-hcpd-organization.html) profile of the Organization resource type.",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type"
      }],
      "versioning" : "versioned",
      "searchInclude" : ["Organization:partOf"],
      "searchRevInclude" : ["Location:organization", "Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "identifier",
        "definition" : "http://hl7.org/fhir/SearchParameter/Organization-identifier|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "name",
        "definition" : "http://hl7.org/fhir/SearchParameter/Organization-name|4.0.1",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "type",
        "definition" : "http://hl7.org/fhir/SearchParameter/Organization-type|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "active",
        "definition" : "http://hl7.org/fhir/SearchParameter/Organization-active|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "suppressed",
        "definition" : "http://digitalhealth.gov.au/fhir/cc/SearchParameter/suppressed|26.0.0",
        "type" : "token"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "Location",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location|26.0.0",
      "documentation" : "This section describes the supported interactions for the [HCPD Location](StructureDefinition-hcpd-location.html) profile. Each Location resource conforming to this profile identifies a physical or virtual place associated with healthcare services in the Health Connect Provider Directory, enabling clients to discover, filter, and reference service delivery sites.",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type"
      }],
      "versioning" : "versioned",
      "searchInclude" : ["Location:organization", "Location:endpoint"],
      "searchRevInclude" : ["HealthcareService:location", "Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "locmailaddress",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/location-locmailaddress|26.0.0",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "locationamenities",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/location-amenities|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "name",
        "definition" : "http://hl7.org/fhir/SearchParameter/Location-name|4.0.1",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "address",
        "definition" : "http://hl7.org/fhir/SearchParameter/Location-address|4.0.1",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "type",
        "definition" : "http://hl7.org/fhir/SearchParameter/Location-type|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "locationphysicaltype",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/location-physicaltype|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "near",
        "definition" : "http://hl7.org/fhir/SearchParameter/Location-near|4.0.1",
        "type" : "special"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "status",
        "definition" : "http://hl7.org/fhir/SearchParameter/Location-status|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "suppressed",
        "definition" : "http://digitalhealth.gov.au/fhir/cc/SearchParameter/suppressed|26.0.0",
        "type" : "token"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "HealthcareService",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-healthcareservice|26.0.0",
      "documentation" : "This section describes the supported interactions for the [HCPD Healthcare Service](StructureDefinition-hcpd-healthcareservice.html) profile. Each HealthcareService resource conforming to this profile identifies a healthcare service in the Health Connect Provider Directory, enabling clients to discover, filter, and reference healthcare services that are provided.",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type"
      }],
      "versioning" : "versioned",
      "searchInclude" : ["HealthcareService:location",
      "HealthcareService:organization",
      "HealthcareService:endpoint",
      "HealthcareService:organization"],
      "searchRevInclude" : ["PractitionerRole:service", "Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "languages",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/languages|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "hsbilling",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/healthcareservice-billing|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "allday",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/allday|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "daysofweek",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/daysofweek|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "starttime",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/starttime|26.0.0",
        "type" : "number"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "endtime",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/endtime|26.0.0",
        "type" : "number"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "service-type",
        "definition" : "http://hl7.org/fhir/SearchParameter/HealthcareService-service-type|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "active",
        "definition" : "http://hl7.org/fhir/SearchParameter/HealthcareService-active|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "suppressed",
        "definition" : "http://digitalhealth.gov.au/fhir/cc/SearchParameter/suppressed|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "healthcareservice-type-display",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/healthcareservice-type-display|26.0.0",
        "type" : "string"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "PractitionerRole",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitionerrole|26.0.0",
      "documentation" : "This section defines the supported interactions for the [HCPD Practitioner Role](StructureDefinition-hcpd-practitionerrole.html) profile of the PractitionerRole resource type. Each PractitionerRole resource conforming to the [HCPD Practitioner Role](StructureDefinition-hcpd-practitionerrole.html) profile describes a practitioner in a role at a healthcare service.",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type"
      }],
      "versioning" : "versioned",
      "searchInclude" : ["PractitionerRole:practitioner",
      "PractitionerRole:service",
      "PractitionerRole:organization",
      "PractitionerRole:location",
      "PractitionerRole:endpoint"],
      "searchRevInclude" : ["Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "languages",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/languages|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "allday",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/allday|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "daysofweek",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/daysofweek|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "starttime",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/starttime|26.0.0",
        "type" : "number"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "endtime",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/endtime|26.0.0",
        "type" : "number"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "identifier",
        "definition" : "http://hl7.org/fhir/SearchParameter/PractitionerRole-identifier|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "role",
        "definition" : "http://hl7.org/fhir/SearchParameter/PractitionerRole-role|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "active",
        "definition" : "http://hl7.org/fhir/SearchParameter/PractitionerRole-active|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "suppressed",
        "definition" : "http://digitalhealth.gov.au/fhir/cc/SearchParameter/suppressed|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "practitionerrole-code-display",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/practitionerrole-code-display|26.0.0",
        "type" : "string"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "Practitioner",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-practitioner|26.0.0",
      "documentation" : "This section describes the supported interactions for the [HCPD Practitioner](StructureDefinition-hcpd-practitioner.html) profile. Each Practitioner resource conforming to this profile represents an individual healthcare provider registered in the Health Connect Provider Directory, enabling clients to search, identify, and reference practitioners and their associated roles and service locations.",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type"
      }],
      "versioning" : "versioned",
      "searchRevInclude" : ["PractitionerRole:practitioner", "Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "identifier",
        "definition" : "http://hl7.org/fhir/SearchParameter/Practitioner-identifier|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "regprof",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/practitioner-regprof|26.0.0",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "rsg",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/practitioner-rsg|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "identifier-r5",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/practitioner-identifier-r5|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "name",
        "definition" : "http://hl7.org/fhir/SearchParameter/Practitioner-name|4.0.1",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "active",
        "definition" : "http://hl7.org/fhir/SearchParameter/Practitioner-active|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "suppressed",
        "definition" : "http://digitalhealth.gov.au/fhir/cc/SearchParameter/suppressed|26.0.0",
        "type" : "token"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "Endpoint",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-endpoint|26.0.0",
      "documentation" : "This section describes the supported interactions for the [HCPD Endpoint](StructureDefinition-hcpd-endpoint.html) profile. Each Endpoint resource conforming to this profile provides connection details for electronic services available through the Health Connect Provider Directory, allowing clients to discover and interact with service endpoints in a standardised way.",
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type"
      }],
      "versioning" : "versioned",
      "searchRevInclude" : ["HealthcareService:endpoint",
      "Location:endpoint",
      "PractitionerRole:endpoint",
      "Provenance:target"],
      "searchParam" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "epurl",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/endpoint-url|26.0.0",
        "type" : "uri"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "payloadmimetype",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/endpoint-payloadmimetype|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "hcepi",
        "definition" : "http://digitalhealth.gov.au/fhir/hcpd/SearchParameter/endpoint-hcepi|26.0.0",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "name",
        "definition" : "http://hl7.org/fhir/SearchParameter/Endpoint-name|4.0.1",
        "type" : "string"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "connection-type",
        "definition" : "http://hl7.org/fhir/SearchParameter/Endpoint-connection-type|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "payload-type",
        "definition" : "http://hl7.org/fhir/SearchParameter/Endpoint-payload-type|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "status",
        "definition" : "http://hl7.org/fhir/SearchParameter/Endpoint-status|4.0.1",
        "type" : "token"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
          "valueCode" : "SHALL"
        }],
        "name" : "suppressed",
        "definition" : "http://digitalhealth.gov.au/fhir/cc/SearchParameter/suppressed|26.0.0",
        "type" : "token"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/capabilitystatement-expectation",
        "valueCode" : "SHALL"
      }],
      "type" : "Parameters",
      "profile" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-export-request-parameters|26.0.0",
      "documentation" : "This resource declares support for processing [HCPD Export Request Parameters](StructureDefinition-hcpd-export-request-parameters.html) resources as input to bulk data export operations. Parameters resources conforming to this profile are used to control the scope, format, and filtering criteria for bulk exports. These resources are processed as part of the $export operation and are not directly stored or searchable.",
      "versioning" : "versioned",
      "readHistory" : false,
      "searchInclude" : ["Provenance:target",
      "Organization:partOf",
      "Location:organization",
      "Location:endpoint",
      "HealthcareService:location",
      "HealthcareService:organization",
      "HealthcareService:endpoint",
      "PractitionerRole:practitioner",
      "PractitionerRole:service",
      "PractitionerRole:organization",
      "PractitionerRole:location",
      "PractitionerRole:endpoint"],
      "searchRevInclude" : ["Location:organization",
      "Provenance:target",
      "HealthcareService:location",
      "PractitionerRole:service",
      "PractitionerRole:practitioner",
      "HealthcareService:endpoint",
      "Location:endpoint",
      "PractitionerRole:endpoint"]
    }],
    "operation" : [{
      "name" : "export",
      "definition" : "http://hl7.org/fhir/uv/bulkdata/OperationDefinition/export|3.0.0",
      "documentation" : "This bulk data export operation expects request parameters conforming to the [HCPD Export Request Parameters](StructureDefinition-hcpd-export-request-parameters.html) profile which defines the required parameter structure for _outputFormat, _type, _typeFilter, and optional _since parameters. The server returns URLs to ndjson files containing the requested resource types. Bulk data extraction returns all resources regardless of active status or suppression; implementers SHALL respect the suppressed and deactivated-by extensions on returned resources, filtering these resources before displaying them to end consumers."
    }]
  }]
}

```
