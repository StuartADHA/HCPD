# HCPD Endpoint - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Endpoint**

## Resource Profile: HCPD Endpoint 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-endpoint | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:HCPD_Endpoint |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

 
This profile defines a Health Connect Provider Directory entry for a technical endpoint. 

No data is entered directly into Health Connect; all Directory content is sourced from authoritative systems including [PCA](https://developer.digitalhealth.gov.au/fhir/provider-connect-australia/current/index.html?src=/), HI-Service, and NHSD.

### Extensions

Extensions introduced in this profile:

* Endpoint: [AU Receiving Facility](http://hl7.org.au/fhir/StructureDefinition/au-receivingfacility)
* Endpoint: [AU Receiving Application](http://hl7.org.au/fhir/StructureDefinition/au-receivingapplication)
* Endpoint: [Encryption Certificate PEM X509](http://hl7.org.au/fhir/StructureDefinition/encryption-certificate-pem-x509)
* Endpoint: [Suppressed](StructureDefinition-suppressed.md)
* Endpoint: [Deactivated](StructureDefinition-deactivated.md)

### Visibility and Suppression

The HCPD Endpoint profile supports the [Suppressed](StructureDefinition-suppressed.md) extension, however its application is conceptually driven by organizational visibility decisions. When an [HCPD Organization](StructureDefinition-hcpd-organization.md) elects to hide their visibility from those searching the Health Connect Provider Directory system by applying the suppressed extension with an `organisation-initiated` code, all associated Endpoint resources (whether referenced from HealthcareService, Location, or PractitionerRole) are automatically suppressed and excluded from Provider Directory listings. This cascading suppression ensures that when an organization chooses to hide their visibility, related endpoints "come for the ride" and are similarly hidden from display, maintaining consistency across the directory.

### Usage notes

The following guidance expands on operational and implementation expectations for this Endpoint profile.

* Purpose: An `Endpoint` in Health Connect describes how to communicate with a service (address, protocol, payloads and contact details). Directory consumers use this information to establish connections, and operational tooling uses it to monitor and validate connectivity.

#### Guidance on the use of endpoints

The HCPD IG offers flexibility with the use of endpoints. The IG supports referencing an endpoint from the HealthcareService, Location & PractitionerRole resources. The recommended hierarchy for when endpoints **SHOULD** be applied is as follows:

* When a HealthcareService, with it's associated referenced Location and PractitionerRoles exist within the same space then an endpoint at this level is suggested.
* When a Location requires differentiation from the referenced HealthcareService due to operational or business requirements, then referencing an endpoint at this level may make sense for the particular use case.
* If a high degree of granular communication is required then referencing an endpoint from the PractitionerRole resource could be applicable.

#### Implementation requirements vs. processing

Implementers SHALL process all elements marked as Must Support (MS) in this profile to be conformant. However, certain elements that are mandatory do not need to be processed by Health Connect Provider Directory Requester Actors.

#### Initial endpoint scope and future expansion

Health Connect initially expects published `Endpoint` resources to describe Secure Messaging endpoints (SMD-capable targets and related secure messaging transports). Requesters and search clients should expect SMD-specific metadata and prioritise handling SMD attributes (SMD Target Identifier, encryption certificate, and routing identifiers). Over time, clients may be able to handle additional protocol metadata (for example, FHIR REST endpoint details) as publishers begin to expose FHIR and other transport types.

#### Identifiers and stable handles

The Endpoint profile uses two stable identifier slices for Directory management and routing:

* [HCPD Local Identifier (HCPD-LI)](StructureDefinition-hcpd-local-identifier.md) - Unique identifier attributed by the HCPD system.
* [HCPD SMD Target Identifier](StructureDefinition-hcpd-smd-target-identifier.md) - a slice used only when the endpoint (or associated practitioner/service) supports Secure Messaging Delivery (SMD). When present the SMD identifier SHALL be globally unique and SHALL be treated as an immutable routing handle for secure point‑to‑point or hub‑mediated messaging. Publishers SHOULD only populate this slice for endpoints that actually support SMD.

### Reciprocal relationships

In FHIR, linkage to resources is owned by the referencing resources (`HealthcareService.endpoint`, `PractitionerRole.endpoint`, `Location.endpoint`). The Endpoint resource itself has no back‑reference slots to those resources. Consequently:

* Reciprocity cannot be enforced within the Endpoint profile (there is no standard element on Endpoint to list referencing HealthcareService / Location / PractitionerRole resources).
* Directory governance MUST ensure that when a referencing resource adds or removes an Endpoint, any operational expectations (availability, deprecation, auditing) are handled in process.

#### Invariants

##### Invariant: inv-ep-01-status-values

Description: Endpoint.`status` must be `active`, `suspended`, or `off`. The `error` and `test` statuses are not used in HCPD.

Implementation note: This rule is enforced as an error - HCPD only recognises active, suspended, and off states for an Endpoint. Publishing systems MUST NOT set `status` to `error` or `test`. When an Endpoint is no longer available it should be set to `off`; `suspended` may be used when the endpoint is temporarily unavailable.

**Usages:**

* Refer to this Profile: [HCPD HealthcareService](StructureDefinition-hcpd-healthcareservice.md), [HCPD Location](StructureDefinition-hcpd-location.md), [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md) and [HCPD Provenance](StructureDefinition-hcpd-provenance.md)
* Examples for this Profile: [Sydney General Hospital FHIR Messaging Endpoint](Endpoint-example-hcpd-endpoint-hl7-fhir-messaging.md) and [Sydney Private Clinic – FHIR Referral Endpoint](Endpoint-example-hcpd-endpoint-referral.md)
* CapabilityStatements using this Profile: [Health Connect Provider Directory Requester](CapabilityStatement-health-connect-provider-directory-requester.md) and [Health Connect Provider Directory Responder](CapabilityStatement-health-connect-provider-directory-responder.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/au.gov.digitalhealth.fhir.hcpd|current/StructureDefinition/StructureDefinition-hcpd-endpoint.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-hcpd-endpoint.csv), [Excel](StructureDefinition-hcpd-endpoint.xlsx), [Schematron](StructureDefinition-hcpd-endpoint.sch) 

### Notes:

### Search parameters

This IG defines and introduces several search parameters in addition to those inherited from R4, that make it easier to find and filter `HCPD Endpoint` resources in Health Connect implementations.

#### Search parameters defined in this IG

The following search parameters are **defined by this IG** and **SHOULD** be supported:

* [`hcepi`](SearchParameter-endpoint-hcepi.md) (Endpoint.identifier where type = Resource Identifier) 
* Find endpoint records by the HCPD identifier assigned in Health Connect. Uses token matching for exact value matching.
* Example: `GET /Endpoint?hcepi=EP001234567890`
 
* [`payloadmimetype`](SearchParameter-endpoint-payloadmimetype.md) (Endpoint.payloadMimeType) 
* Search for endpoints that advertise support for a specific MIME type for payloads.
 
* Typical values present in this IG's example data are: 
* `application/pdf`
* `application/fhir+xml`
* `application/fhir+json`
* Example: `GET /Endpoint?payloadmimetype=application%2Ffhir%2Bjson`
 
* [`epurl`](SearchParameter-endpoint-url.md) (alias used in this IG for Endpoint.address) 
* Convenience alias used in this IG's documentation to search by endpoint address.
* Example: `GET /Endpoint?epurl=https://smd.sydneyhospital.org.au/secure-messaging/endpoint`
 
* [`suppressed`](SearchParameter-suppressed.md) (Endpoint.extension where url = suppressedBy extension) 
* Search for endpoints by their suppression status. Use token semantics with a code from the [Responsible Party Type CodeSystem](CodeSystem-responsible-party-type.md).
* Example (system|code): `GET /Endpoint?suppressed=http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type|practitioner-initiated`
* Example (code only): `GET /Endpoint?suppressed=practitioner-initiated`
* Example (system only): `GET /Endpoint?suppressed=http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type|`
 

#### Search parameters from R4

The following search parameters are **inherited from FHIR R4** and have been deemed useful for implementation within this IG. They **SHOULD** be supported:

* [`name (R4)`](https://hl7.org/fhir/R4/SearchParameter-registry.html#name) (Endpoint.name) 
* Search for endpoints by name (partial matches may be supported).
* Example: `GET /Endpoint?name=My%20GP%20Service`
 
* [`connection-type (R4)`](https://hl7.org/fhir/R4/SearchParameter-registry.html#connection-type) (Endpoint.connectionType) 
* Search for endpoints by connection type (for example, `hl7-fhir-rest` or other interface codes).
* Example: `GET /Endpoint?connection-type=http://terminology.hl7.org.au/CodeSystem/endpoint-connection-type|secure-messaging`
 
* [`payload-type (R4)`](https://hl7.org/fhir/R4/SearchParameter-registry.html#payload-type) (Endpoint.payloadType) 
* Search for endpoints by payload type (CodeableConcept). Use [AU PD Endpoint payload type ValueSet codes](http://hl7.org.au/fhir/pd/ValueSet/endpoint-payload-type) where applicable.
* Example: `GET /Endpoint?payload-type=http://hl7.org.au/fhir/pd/CodeSystem/endpoint-payload-type|some-payload`
 
* [`status (R4)`](https://hl7.org/fhir/R4/endpoint.html#search) (Endpoint.status) 
* Filter endpoints by their operational status. Use token semantics with one of the defined status values: `active`, `suspended`, `error`, `off`, `entered-in-error`, `test`.
* Example: `GET /Endpoint?status=active`
 

**Note:** Support for _id is mandatory for a responder and optional for a requester. Where the expectation for a search parameter differs between actors, the table below will reflect the stronger conformance requirement.

* Parameter(s): _id
  * Conformance: **SHOULD**
  * Type(s): `token`
  * Requirements (when used alone or in combination): 
* Parameter(s): status (R4)
  * Conformance: **SHOULD**
  * Type(s): `token`
  * Requirements (when used alone or in combination): 
* Parameter(s): hcepi
  * Conformance: **SHOULD**
  * Type(s): `token`
  * Requirements (when used alone or in combination): 
* Parameter(s): name (R4)
  * Conformance: **SHOULD**
  * Type(s): `string`
  * Requirements (when used alone or in combination): 
* Parameter(s): connection-type (R4)
  * Conformance: **SHOULD**
  * Type(s): `token`
  * Requirements (when used alone or in combination): 
* Parameter(s): payload-type (R4)
  * Conformance: **SHOULD**
  * Type(s): `token`
  * Requirements (when used alone or in combination): 
* Parameter(s): epurl
  * Conformance: **SHOULD**
  * Type(s): `uri`
  * Requirements (when used alone or in combination): 
* Parameter(s): suppressed
  * Conformance: **SHOULD**
  * Type(s): `token`
  * Requirements (when used alone or in combination): 
* Parameter(s): payloadmimetype
  * Conformance: **SHOULD**
  * Type(s): `token`
  * Requirements (when used alone or in combination): 
* Parameter(s): name+connection-type
  * Conformance: **SHOULD**
  * Type(s): `string`+`token`
  * Requirements (when used alone or in combination): 
* Parameter(s): name+payload-type
  * Conformance: **SHOULD**
  * Type(s): `string`+`token`
  * Requirements (when used alone or in combination): 
* Parameter(s): connection-type+payloadmimetype
  * Conformance: **SHOULD**
  * Type(s): `token`+`token`
  * Requirements (when used alone or in combination): 

### Search reverse include parameters

This implementation supports the following `_revinclude` parameters when searching for Endpoint resources:

* `_revinclude=HealthcareService:endpoint` - Include HealthcareService resources that reference this Endpoint
* `_revinclude=Location:endpoint` - Include Location resources that reference this Endpoint
* `_revinclude=PractitionerRole:endpoint` - Include PractitionerRole resources that reference this Endpoint
* `_revinclude=Provenance:target` - Include Provenance resources that track changes to this Endpoint

#### Example usage

```
GET /Endpoint/303?_revinclude=HealthcareService:endpoint&_revinclude=Location:endpoint

```

This query returns the Endpoint resource along with all HealthcareServices and Locations that use this Endpoint.

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "hcpd-endpoint",
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-endpoint",
  "version" : "26.0.0",
  "name" : "HCPD_Endpoint",
  "title" : "HCPD Endpoint",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "This profile defines a Health Connect Provider Directory entry for a technical endpoint.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Endpoint",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Endpoint|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Endpoint",
      "path" : "Endpoint",
      "short" : "Health Connect Endpoint",
      "definition" : "Endpoint defined for use in Health Connect.",
      "constraint" : [{
        "key" : "inv-01-status-values",
        "severity" : "error",
        "human" : "Endpoint.status must be 'active', 'suspended', or 'off'. The 'error' and 'test' statuses are not used in HCPD.",
        "expression" : "status = 'active' or status = 'suspended' or status = 'off'",
        "source" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-endpoint|26.0.0"
      }]
    },
    {
      "id" : "Endpoint.extension",
      "path" : "Endpoint.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "rules" : "open"
      }
    },
    {
      "id" : "Endpoint.extension:receiving-facility",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Endpoint.extension",
      "sliceName" : "receiving-facility",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org.au/fhir/StructureDefinition/au-receivingfacility|6.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.extension:receiving-application",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Endpoint.extension",
      "sliceName" : "receiving-application",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org.au/fhir/StructureDefinition/au-receivingapplication|6.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.extension:encryption-certificate-pem-x509",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Endpoint.extension",
      "sliceName" : "encryption-certificate-pem-x509",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org.au/fhir/StructureDefinition/encryption-certificate-pem-x509|6.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.extension:suppressed",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Endpoint.extension",
      "sliceName" : "suppressed",
      "short" : "indicates whether the Endpoint should be hidden.",
      "definition" : "A coded value, when present, indicates whether the Endpoint should be hidden from display in the Provider Directory.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://digitalhealth.gov.au/fhir/cc/StructureDefinition/suppressed|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.extension:suppressed.extension:suppressedBy",
      "path" : "Endpoint.extension.extension",
      "sliceName" : "suppressedBy"
    },
    {
      "id" : "Endpoint.extension:suppressed.extension:suppressedBy.value[x].coding",
      "path" : "Endpoint.extension.extension.value[x].coding",
      "max" : "1",
      "fixedCoding" : {
        "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
        "code" : "organisation-initiated"
      },
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.extension:deactivated",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:ignore"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:ignore"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Endpoint.extension",
      "sliceName" : "deactivated",
      "short" : "Indicates if Endpoint service is deactivated",
      "definition" : "When present, this extension marks the Endpoint as deactivated, and deactivation automatically cascades to all child resources.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/deactivated|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.extension:deactivated.extension:deactivatedBy",
      "path" : "Endpoint.extension.extension",
      "sliceName" : "deactivatedBy"
    },
    {
      "id" : "Endpoint.extension:deactivated.extension:deactivatedBy.value[x].coding",
      "path" : "Endpoint.extension.extension.value[x].coding",
      "max" : "1",
      "fixedCoding" : {
        "system" : "http://digitalhealth.gov.au/fhir/cc/CodeSystem/responsible-party-type",
        "code" : "organisation-initiated"
      },
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.identifier",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Endpoint.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "type"
        },
        {
          "type" : "value",
          "path" : "system"
        }],
        "rules" : "open"
      },
      "short" : "Unique identifier of the endpoint record",
      "min" : 2,
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.identifier:HCPD_SMD_Target_Identifier",
      "path" : "Endpoint.identifier",
      "sliceName" : "HCPD_SMD_Target_Identifier",
      "short" : "SMD Target Identifier",
      "definition" : "Secure Messaging Delivery target identifier for this endpoint",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-smd-target-identifier|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.identifier:HCPD_Source_Identifier",
      "path" : "Endpoint.identifier",
      "sliceName" : "HCPD_Source_Identifier",
      "short" : "HC Endpoint Identifier attributed from source system. Source for Endpoint: NHSD.",
      "definition" : "Unique identifier for the healthcare endpoint attributed from source system. Not exposed externally but can be used for system reference or internal business logic.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-source-identifier|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.identifier:HCPD_Local_Identifier",
      "path" : "Endpoint.identifier",
      "sliceName" : "HCPD_Local_Identifier",
      "short" : "Identifier attributed by the HCPD system for the Endpoint",
      "definition" : "Unique identifier for the healthcare endpoint attributed from source system. Not a displayable field but can be used for system reference or internal business logic.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-local-identifier|26.0.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.status",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Endpoint.status",
      "short" : "Only endpoints with status ‘Active’ are exposed externally.",
      "definition" : "To ensure that only the endpoint with status ‘Active’ are discoverable and displayed on the directory, when searched. Others are retained for auditing and reporting purpose only",
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.connectionType",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Endpoint.connectionType",
      "short" : "To specify the service interface types",
      "definition" : "Protocol/Profile/Standard the endpoint supports.",
      "mustSupport" : true,
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://hl7.org.au/fhir/pd/ValueSet/service-interfaces|2.1.0-ci-build"
      }
    },
    {
      "id" : "Endpoint.name",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Endpoint.name",
      "short" : "To enable consistent and correct identification of the endpoint",
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.payloadType",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Endpoint.payloadType",
      "short" : "Endpoint payload type",
      "definition" : "REndpoint payload types that need to be transmitted over secure messaging, e.g. Discharge Summary, e-Referral, referral response message, acknowledgment etc.",
      "mustSupport" : true,
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://hl7.org.au/fhir/pd/ValueSet/endpoint-payload-type|2.1.0-ci-build"
      }
    },
    {
      "id" : "Endpoint.payloadMimeType",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Endpoint.payloadMimeType",
      "mustSupport" : true
    },
    {
      "id" : "Endpoint.address",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/responder-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:handle"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://digitalhealth.gov.au/fhir/hcpd/ActorDefinition/bulk-export-requester-actor-health-connect|26.0.0"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Endpoint.address",
      "short" : "URL address of the endpoint",
      "mustSupport" : true
    }]
  }
}

```
