# Bulk Data Extraction - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**Guidance**](guidance.md)
* **Bulk Data Extraction**

## Bulk Data Extraction

### Overview

Bulk data extraction provides an efficient mechanism for Health Connect Provider Directory consumers to retrieve large datasets outside of real-time query patterns. This specification defines how client systems can request complete copies or incremental updates of provider directory data using the [FHIR Bulk Data Access specification](http://hl7.org/fhir/uv/bulkdata/).

The Health Connect Provider Directory supports bulk data extraction for enterprise integration scenarios.

#### Background

FHIR Bulk Data extraction consists of several key components:

* **Data scope selection** - Defining which resources and data subsets to extract
* **Asynchronous processing** - Managing long-running export operations with status tracking
* **NDJSON format** - Standardised new-line delimited JSON output format
* **Secure file retrieval** - Downloading completed extracts with appropriate authorisation

**Note:** Bulk export requests require a FHIR Parameters resource in the request body to specify the export parameters. This allows for complex parameter combinations and ensures proper encoding of multiple `_typeFilter` values.

#### Process workflow

The following diagram illustrates the 3 broad steps involved in performing an asynchronous bulk export. Navigating to each of the hyperlinks yields further detail about how each is performed.

`

### Health Connect Provider Directory bulk data specifics

#### The scope of the data selection

When performing a bulk data extraction, the Parameters resource must include a `_type` parameter listing the resource types to export, as well as a `_typeFilter` parameter for every resource type specified. The `_typeFilter` defines filtering conditions that apply only to resources of its corresponding type, and only resources matching these conditions will be included in the export.

#### Supported resource types

The Health Connect Provider Directory supports bulk export for all resource types defined in this implementation guide.

### Functions provided

This service supports the standard FHIR asynchronous request pattern allowing clients to submit large queries that require significant server-side processing, with results being made available for retrieval at a later time.

This function is provided by the `$export` operation that implements the FHIR Bulk Data Access specification ([https://hl7.org/fhir/uv/bulkdata/](https://hl7.org/fhir/uv/bulkdata/)) bulk export pattern.

#### Extract types and scheduling

The Health Connect Provider Directory supports two primary extract variations:

1. **Snapshot Extracts**- Large snapshots based on the supplied criteria
1. **Delta Updates**- Incremental changes since a particular time

Both extract types are ad-hoc and can be initiated at any time.

**The following four key sub-functions are supported:**

* Initiate a batch export - refer to the [Batch Export Request Submission](BatchRequestSubmission.md) page
* Polling requests to retrieve the status of the batch export - refer to the [Batch Export Request Status](BatchRequestStatus.md) page
* Retrieval requests to retrieve the results of the batch export - refer to the [Batch Export Retrieve Results](BatchRequestResults.md) page
* Cancellation requests to cancel a batch export request - refer to the [Batch Export Request Delete](BatchRequestDelete.md) page

### Primary extraction approaches

The Health Connect Provider Directory supports extraction approaches using standard FHIR bulk data parameters:

#### 1. Snapshot and delta extracts

* **Primary Filter**: Resource type selection using `_type` and filtering using `_typeFilter`
* **Use Cases**: Data synchronization and replication for local systems
* **Key Parameters**: `_type`, `_typeFilter`, `_since`

#### 2. Geographical centric extraction

* **Primary Filter**: Location-based filtering using `_typeFilter`
* **Use Cases**: Regional health planning, local referral networks, proximity-based service discovery
* **Key Parameters**: `_typeFilter=Location?address-state=[STATE]`, `_typeFilter=Location?near=[LAT]|[LNG]|[DISTANCE]`

#### 3. Organization centric extraction

* **Primary Filter**: Organization identifier or name filtering
* **Use Cases**: Organizational data synchronization, corporate structure analysis
* **Key Parameters**: `_typeFilter=Organization?identifier=[SYSTEM]|[VALUE]`, `_typeFilter=Organization?name=[NAME]`

#### 4. Service-Type centric extraction

* **Primary Filter**: Healthcare service type filtering
* **Use Cases**: Service-specific planning, specialist network analysis
* **Key Parameters**: `_typeFilter=HealthcareService?service-type=[SYSTEM]|[CODE]`

**Note: Multiple `_typeFilter` parameters can be combined for complex filtering scenarios**

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.

