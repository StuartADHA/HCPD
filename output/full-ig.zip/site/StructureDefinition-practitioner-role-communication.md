# Practitioner Role Communication - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **Practitioner Role Communication**

## Extension: Practitioner Role Communication 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/cc/StructureDefinition/practitioner-role-communication | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:PractitionerRole_Communication |
| **Copyright/Legal**: This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) | |

Practitioner Role Communication. This extension captures communication preferences and capabilities for a practitioner in a given role.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [HCPD PractitionerRole](StructureDefinition-hcpd-practitionerrole.md)
* Examples for this Extension: [PractitionerRole/example-healthconnect-practitionerrole-1](PractitionerRole-example-healthconnect-practitionerrole-1.md) and [PractitionerRole/example-healthconnect-practitionerrole-2](PractitionerRole-example-healthconnect-practitionerrole-2.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/au.gov.digitalhealth.fhir.hcpd|current/StructureDefinition/StructureDefinition-practitioner-role-communication.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-practitioner-role-communication.csv), [Excel](StructureDefinition-practitioner-role-communication.xlsx), [Schematron](StructureDefinition-practitioner-role-communication.sch) 

#### Terminology Bindings

#### Constraints

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "practitioner-role-communication",
  "url" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/practitioner-role-communication",
  "version" : "26.0.0",
  "name" : "PractitionerRole_Communication",
  "title" : "Practitioner Role Communication",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "Practitioner Role Communication. This extension captures communication preferences and capabilities for a practitioner in a given role.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "PractitionerRole"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Practitioner role communication preferences",
      "definition" : "This extension applies to PractitionerRole, and represents a language the practitioner can use in patient communication when acting in a role at a HealthcareService."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://digitalhealth.gov.au/fhir/cc/StructureDefinition/practitioner-role-communication"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://healthterminologies.gov.au/fhir/ValueSet/common-languages-australia-2"
      }
    }]
  }
}

```
