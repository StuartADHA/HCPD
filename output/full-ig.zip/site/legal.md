# Licence and Legal - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* **Licence and Legal**

## Licence and Legal

### Disclaimer

The Australian Digital Health Agency (“the Agency”) makes the information and other material (“Information”) in this document available in good faith but without any representation or warranty as to its accuracy or completeness. The Agency cannot accept any responsibility for the consequences of any use of the Information. As the Information is of a general nature only, it is up to any person using or relying on the Information to ensure that it is accurate, complete and suitable for the circumstances of its use.

### Document control

This document is maintained in electronic form and is uncontrolled in printed form. It is the responsibility of the user to verify that this copy is the latest revision.

### Creative Commons 4.0 licence

This work is licensed under a Creative Commons Attribution 4.0 International License.

Please refer to the full license agreement at: [https://creativecommons.org/licenses/by/4.0](https://creativecommons.org/licenses/by/4.0).

This license allows you to distribute, remix, adapt, and build upon this material in any medium or format, as long as attribution is given to the creator.

### Regenstrief Institute (LOINC)

This material contains content from LOINC ([http://loinc.org](http://loinc.org)). LOINC is copyright © Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the license at [http://loinc.org/license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

### IHTSDO (SNOMED CT)

This material includes SNOMED Clinical Terms® (SNOMED CT®) which is used by permission of the International Health Terminology Standards Development Organisation (IHTSDO). All rights reserved. SNOMED CT® was originally created by The College of American Pathologists. “SNOMED” and “SNOMED CT” are registered trademarks of the [IHTSDO](http://www.ihtsdo.org/).

### HL7 FHIR

This product includes all or a portion of material that is HL7 FHIR Copyright © 2011+ HL7 licensed under Creative Commons "No Rights Reserved".

### HL7 International

This document includes excerpts of HL7™ International standards and other HL7 International material. HL7 International is the publisher and holder of copyright in the excerpts. The publication, reproduction and use of such excerpts is governed by the [HL7 IP Policy](http://www.hl7.org/legal/ippolicy.cfm) and the HL7 International License Agreement. HL7 and CDA are trademarks of Health Level Seven International and are registered with the United States Patent and Trademark Office. FHIR is a registered trademark of Health Level Seven International.

This product includes all or a portion of the HL7 Vocabulary, or is derived from the HL7 Vocabulary, subject to a license from Health Level Seven International. Your use of the HL7 Vocabulary also is subject to this license, a copy of which is accessible through the following link: [http://www.hl7.org/permalink/?VocabTables](http://www.hl7.org/permalink/?VocabTables). The current complete HL7 Vocabulary is also available through this link. The HL7 Vocabulary is copyright © 1989-2010, Health Level Seven International. All rights reserved. THE HL7 VOCABULARY IS PROVIDED "AS IS." ANY EXPRESS OR IMPLIED WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

### Third-party Artefacts and Terminologies

Australian Digital Health Agency FHIR Implementation Guides contain and reference intellectual property owned by third parties ("Third Party IP"). Acceptance of these License Terms does not grant any rights with respect to Third Party IP. The licensee alone is responsible for identifying and obtaining any necessary licences or authorisations to utilise Third Party IP in connection with the specification or otherwise.

This publication includes IP covered under the following statements.

* Copyright © 2026 Australian Digital Health Agency - All rights reserved. This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/).

* [HI Services Identifier Status Code System](CodeSystem-hi-services-identifier-status-cs.md): [Caring Hands Home Support](Organization-example-healthconnect-organization-2.md), [HI_Services_Identifier_Status](StructureDefinition-hi-services-identifier-status.md)... Show 5 more, [HI_Services_Identifier_Status_VS](ValueSet-hi-services-identifier-status-vs.md), [Organization/example-healthconnect-organization-1](Organization-example-healthconnect-organization-1.md), [Practitioner/example-balmain-practitioner-1](Practitioner-example-balmain-practitioner-1.md), [Practitioner/example-healthconnect-practitioner-1](Practitioner-example-healthconnect-practitioner-1.md) and [Practitioner/external-hcpd-practitioner-record](Practitioner-external-hcpd-practitioner-record.md)


* HL7 Australia© 2018+; Licensed Under Creative Commons No Rights Reserved.

* [Australian Endpoint Payload Types](https://build.fhir.org/ig/hl7au/au-fhir-pd/CodeSystem-endpoint-payload-type.html): [HCPD_Endpoint](StructureDefinition-hcpd-endpoint.md)
* [Australian Secure Message Service Interfaces](https://build.fhir.org/ig/hl7au/au-fhir-pd/CodeSystem-smd-interfaces.html): [HCPD_Endpoint](StructureDefinition-hcpd-endpoint.md)
* [Location Type AU](http://hl7.org.au/fhir/6.0.0/CodeSystem-au-location-type.html): [HCPD_Location](StructureDefinition-hcpd-location.md), [Sydney CBD Mobile Unit Service Area](Location-example-healthconnect-mobile-unit-coverage-area-1.md) and [Virtual Telehealth Service](Location-example-healthconnect-virtual-telehealth-service-1.md)
* [IdentifierType AU](http://hl7.org.au/fhir/6.0.0/CodeSystem-au-v2-0203.html): [HCPD_HPIO_Identifier](StructureDefinition-hcpd-hpio.md), [Mobile Healthcare Unit - Sydney CBD](Location-example-healthconnect-mobile-healthcare-unit-1.md)... Show 8 more, [Organization/example-healthconnect-organization-1](Organization-example-healthconnect-organization-1.md), [Practitioner/example-balmain-practitioner-1](Practitioner-example-balmain-practitioner-1.md), [Practitioner/example-healthconnect-practitioner-1](Practitioner-example-healthconnect-practitioner-1.md), [PractitionerRole/example-healthconnect-practitionerrole-1](PractitionerRole-example-healthconnect-practitionerrole-1.md), [PractitionerRole/example-healthconnect-practitionerrole-2](PractitionerRole-example-healthconnect-practitionerrole-2.md), [Sydney CBD Mobile Unit Service Area](Location-example-healthconnect-mobile-unit-coverage-area-1.md), [Sydney Central Medical Centre](Location-example-healthconnect-medical-centre-location-1.md) and [Virtual Telehealth Service](Location-example-healthconnect-virtual-telehealth-service-1.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.2.0/CodeSystem-ISO3166Part1.html): [Active_Period](StructureDefinition-active-period.md), [Alternate_Name](StructureDefinition-alternate-name.md)... Show 59 more, [Amenity](StructureDefinition-amenity.md), [Deactivated](StructureDefinition-deactivated.md), [HCPD_Alternate_Postal_Address](StructureDefinition-hcpd-alternate-postal-address.md), [HCPD_Endpoint](StructureDefinition-hcpd-endpoint.md), [HCPD_Export_Request_Parameters](StructureDefinition-hcpd-export-request-parameters.md), [HCPD_HPII_Identifier](StructureDefinition-hcpd-hpii.md), [HCPD_HPIO_Identifier](StructureDefinition-hcpd-hpio.md), [HCPD_HSPO_Identifier](StructureDefinition-hcpd-hspo.md), [HCPD_HealthcareService](StructureDefinition-hcpd-healthcareservice.md), [HCPD_ImplementationGuide](index.md), [HCPD_Local_Identifier](StructureDefinition-hcpd-local-identifier.md), [HCPD_Location](StructureDefinition-hcpd-location.md), [HCPD_Organization](StructureDefinition-hcpd-organization.md), [HCPD_Practitioner](StructureDefinition-hcpd-practitioner.md), [HCPD_PractitionerRole](StructureDefinition-hcpd-practitionerrole.md), [HCPD_Provenance](StructureDefinition-hcpd-provenance.md), [HCPD_SMD_Target_Identifier](StructureDefinition-hcpd-smd-target-identifier.md), [HCPD_Service_Coverage_Area](StructureDefinition-hcpd-service-coverage-area.md), [HCPD_Source_Identifier](StructureDefinition-hcpd-source-identifier.md), [HI_Org_Classification_CS](CodeSystem-hi-org-classification-cs.md), [HI_Org_Classification_VS](ValueSet-hi-org-classification-vs.md), [HI_Service_Organisation_Classification](StructureDefinition-hi-org-classification.md), [HI_Services_Identifier_Status](StructureDefinition-hi-services-identifier-status.md), [HI_Services_Identifier_Status_CS](CodeSystem-hi-services-identifier-status-cs.md), [HI_Services_Identifier_Status_VS](ValueSet-hi-services-identifier-status-vs.md), [HealthConnectProviderDirectoryBulkExportRequester](CapabilityStatement-health-connect-bulk-export-requester.md), [HealthConnectProviderDirectoryBulkExportRequesterActorHealthConnect](ActorDefinition-bulk-export-requester-actor-health-connect.md), [HealthConnectProviderDirectoryRequester](CapabilityStatement-health-connect-provider-directory-requester.md), [HealthConnectProviderDirectoryResponder](CapabilityStatement-health-connect-provider-directory-responder.md), [IAR_Levels_Of_Care](StructureDefinition-iar-levels-of-care.md), [New_Patient_Availability](StructureDefinition-new-patient-availability.md), [Peak_Body_Professional_Registration_Number](StructureDefinition-pbprn.md), [PractitionerRole_Communication](StructureDefinition-practitioner-role-communication.md), [Referral_Information_For_Referrer](StructureDefinition-referral-information-for-referrer.md), [RequesterActorHealthConnect](ActorDefinition-requester-actor-health-connect.md), [ResponderActorHealthConnect](ActorDefinition-responder-actor-health-connect.md), [ResponsiblePartyType_CS](CodeSystem-responsible-party-type.md), [ResponsiblePartyType_VS](ValueSet-responsible-party-type.md), [SearchParameterAllDay](SearchParameter-allday.md), [SearchParameterAlternatePostalAddress](SearchParameter-location-locmailaddress.md), [SearchParameterDaysOfWeek](SearchParameter-daysofweek.md), [SearchParameterEndTime](SearchParameter-endtime.md), [SearchParameterEndpointIdentifierHC](SearchParameter-endpoint-hcepi.md), [SearchParameterEndpointPayloadMimeType](SearchParameter-endpoint-payloadmimetype.md), [SearchParameterEndpointUrl](SearchParameter-endpoint-url.md), [SearchParameterHealthcareServiceBilling](SearchParameter-healthcareservice-billing.md), [SearchParameterHealthcareServiceTypeDisplay](SearchParameter-healthcareservice-type-display.md), [SearchParameterLanguages](SearchParameter-languages.md), [SearchParameterLocationAmenities](SearchParameter-location-amenities.md), [SearchParameterLocationPhysicalType](SearchParameter-location-physicaltype.md), [SearchParameterPractitionerIdentifierR5](SearchParameter-practitioner-identifier-r5.md), [SearchParameterPractitionerRSG](SearchParameter-practitioner-rsg.md), [SearchParameterPractitionerRegProf](SearchParameter-practitioner-regprof.md), [SearchParameterPractitionerRoleCodeDisplay](SearchParameter-practitionerrole-code-display.md), [SearchParameterStartTime](SearchParameter-starttime.md), [SearchParameterSuppressed](SearchParameter-suppressed.md), [ServiceProvision_CS](CodeSystem-service-provision-cs.md), [Service_Provision_Code_VS](ValueSet-service-provision-code-vs.md) and [Suppressed](StructureDefinition-suppressed.md)


* This content is licensed under a Creative Commons Attribution 4.0 International License. See [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/) 

* [Responsible Party Type](CodeSystem-responsible-party-type.md): [Balmain Service Coverage Area](Location-example-healthconnect-service-coverage-area-balmain-1.md), [Deactivated](StructureDefinition-deactivated.md)... Show 18 more, [HCPD_Endpoint](StructureDefinition-hcpd-endpoint.md), [HCPD_HealthcareService](StructureDefinition-hcpd-healthcareservice.md), [HCPD_Location](StructureDefinition-hcpd-location.md), [HCPD_Organization](StructureDefinition-hcpd-organization.md), [HCPD_Practitioner](StructureDefinition-hcpd-practitioner.md), [HCPD_Service_Coverage_Area](StructureDefinition-hcpd-service-coverage-area.md), [Northside Community Health Centre – General Practice & Aged Care](HealthcareService-example-healthconnect-healthcareservice-2.md), [Organization/example-healthconnect-organization-1](Organization-example-healthconnect-organization-1.md), [Practitioner/example-balmain-practitioner-1](Practitioner-example-balmain-practitioner-1.md), [Practitioner/example-healthconnect-practitioner-1](Practitioner-example-healthconnect-practitioner-1.md), [Practitioner/external-hcpd-practitioner-record](Practitioner-external-hcpd-practitioner-record.md), [PractitionerRole/example-healthconnect-practitionerrole-2](PractitionerRole-example-healthconnect-practitionerrole-2.md), [ResponsiblePartyType_VS](ValueSet-responsible-party-type.md), [Suppressed](StructureDefinition-suppressed.md), [Sydney CBD Mobile Unit Service Area](Location-example-healthconnect-mobile-unit-coverage-area-1.md), [Sydney Central Medical Centre](Location-example-healthconnect-medical-centre-location-1.md), [Sydney General Hospital FHIR Messaging Endpoint](Endpoint-example-hcpd-endpoint-hl7-fhir-messaging.md) and [Sydney Private Clinic – FHIR Referral Endpoint](Endpoint-example-hcpd-endpoint-referral.md)
* [HI Service Organisation Classification CodeSystem](CodeSystem-hi-org-classification-cs.md): [Caring Hands Home Support](Organization-example-healthconnect-organization-2.md), [HCPD_HSPO_Identifier](StructureDefinition-hcpd-hspo.md), [HI_Org_Classification_VS](ValueSet-hi-org-classification-vs.md), [HI_Service_Organisation_Classification](StructureDefinition-hi-org-classification.md) and [Organization/example-healthconnect-organization-1](Organization-example-healthconnect-organization-1.md)
* [Service Provision CodeSystem](CodeSystem-service-provision-cs.md): [HCPD_HealthcareService](StructureDefinition-hcpd-healthcareservice.md), [Healthcare service with Residential Aged Care service type](HealthcareService-example-healthconnect-healthcareservice-1.md), [Northside Community Health Centre – General Practice & Aged Care](HealthcareService-example-healthconnect-healthcareservice-2.md) and [Service_Provision_Code_VS](ValueSet-service-provision-code-vs.md)


* This is an example set based on ASTM Standard, E1762-95 (2013) HL7 RoleClass OID 2.16.840.1.113883.5.110, HL7 Role Code 2.16.840.1.113883.5.111, HL7 ParticipationType OID: 2.16.840.1.113883.5.90, HL7 ParticipationFunction codes at OID: 2.16.840.1.113883.5.88, and HL7 Security and Privacy Domain Analysis Model roles classes.

* [Contract Signer Type Codes](http://terminology.hl7.org/7.4.0/CodeSystem-contractsignertypecodes.html): [Provenance/provenance-practitioner-name-update](Provenance-provenance-practitioner-name-update.md) and [Provenance/provenance-practitioner-phone-update](Provenance-provenance-practitioner-phone-update.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [HCPD_HealthcareService](StructureDefinition-hcpd-healthcareservice.md), [Healthcare service with Residential Aged Care service type](HealthcareService-example-healthconnect-healthcareservice-1.md), [Northside Community Health Centre – General Practice & Aged Care](HealthcareService-example-healthconnect-healthcareservice-2.md), [PractitionerRole/example-healthconnect-practitionerrole-1](PractitionerRole-example-healthconnect-practitionerrole-1.md) and [PractitionerRole/example-healthconnect-practitionerrole-2](PractitionerRole-example-healthconnect-practitionerrole-2.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Contact entity type](http://terminology.hl7.org/7.4.0/CodeSystem-contactentity-type.html): [Healthcare service with Residential Aged Care service type](HealthcareService-example-healthconnect-healthcareservice-1.md) and [Northside Community Health Centre – General Practice & Aged Care](HealthcareService-example-healthconnect-healthcareservice-2.md)
* [Endpoint Connection Type](http://terminology.hl7.org/7.4.0/CodeSystem-endpoint-connection-type.html): [HCPD_Endpoint](StructureDefinition-hcpd-endpoint.md), [Sydney General Hospital FHIR Messaging Endpoint](Endpoint-example-hcpd-endpoint-hl7-fhir-messaging.md) and [Sydney Private Clinic – FHIR Referral Endpoint](Endpoint-example-hcpd-endpoint-referral.md)
* [Endpoint Payload Type](http://terminology.hl7.org/7.4.0/CodeSystem-endpoint-payload-type.html): [Sydney General Hospital FHIR Messaging Endpoint](Endpoint-example-hcpd-endpoint-hl7-fhir-messaging.md) and [Sydney Private Clinic – FHIR Referral Endpoint](Endpoint-example-hcpd-endpoint-referral.md)
* [Location type](http://terminology.hl7.org/7.4.0/CodeSystem-location-physical-type.html): [Sydney Central Medical Centre](Location-example-healthconnect-medical-centre-location-1.md)
* [Provenance participant type](http://terminology.hl7.org/7.4.0/CodeSystem-provenance-participant-type.html): [Provenance/provenance-practitioner-name-update](Provenance-provenance-practitioner-name-update.md) and [Provenance/provenance-practitioner-phone-update](Provenance-provenance-practitioner-phone-update.md)
* [identifierType](http://terminology.hl7.org/7.4.0/CodeSystem-v2-0203.html): [HCPD_HPII_Identifier](StructureDefinition-hcpd-hpii.md), [HCPD_Local_Identifier](StructureDefinition-hcpd-local-identifier.md)... Show 15 more, [HCPD_Source_Identifier](StructureDefinition-hcpd-source-identifier.md), [Healthcare service with Residential Aged Care service type](HealthcareService-example-healthconnect-healthcareservice-1.md), [Mobile Healthcare Unit - Sydney CBD](Location-example-healthconnect-mobile-healthcare-unit-1.md), [Northside Community Health Centre – General Practice & Aged Care](HealthcareService-example-healthconnect-healthcareservice-2.md), [Peak_Body_Professional_Registration_Number](StructureDefinition-pbprn.md), [Practitioner/example-balmain-practitioner-1](Practitioner-example-balmain-practitioner-1.md), [Practitioner/example-healthconnect-practitioner-1](Practitioner-example-healthconnect-practitioner-1.md), [Practitioner/external-hcpd-practitioner-record](Practitioner-external-hcpd-practitioner-record.md), [PractitionerRole/example-healthconnect-practitionerrole-1](PractitionerRole-example-healthconnect-practitionerrole-1.md), [PractitionerRole/example-healthconnect-practitionerrole-2](PractitionerRole-example-healthconnect-practitionerrole-2.md), [Sydney CBD Mobile Unit Service Area](Location-example-healthconnect-mobile-unit-coverage-area-1.md), [Sydney Central Medical Centre](Location-example-healthconnect-medical-centre-location-1.md), [Sydney General Hospital FHIR Messaging Endpoint](Endpoint-example-hcpd-endpoint-hl7-fhir-messaging.md), [Sydney Private Clinic – FHIR Referral Endpoint](Endpoint-example-hcpd-endpoint-referral.md) and [Virtual Telehealth Service](Location-example-healthconnect-virtual-telehealth-service-1.md)
* [ActCode](http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActCode.html): [HCPD_Provenance](StructureDefinition-hcpd-provenance.md)
* [DataOperation](http://terminology.hl7.org/7.4.0/CodeSystem-v3-DataOperation.html): [HCPD_Provenance](StructureDefinition-hcpd-provenance.md), [Provenance/provenance-practitioner-name-update](Provenance-provenance-practitioner-name-update.md) and [Provenance/provenance-practitioner-phone-update](Provenance-provenance-practitioner-phone-update.md)
* [DocumentCompletion](http://terminology.hl7.org/7.4.0/CodeSystem-v3-DocumentCompletion.html): [HCPD_Provenance](StructureDefinition-hcpd-provenance.md)
* [ParticipationType](http://terminology.hl7.org/7.4.0/CodeSystem-v3-ParticipationType.html): [HCPD_Provenance](StructureDefinition-hcpd-provenance.md)
* [RoleCode](http://terminology.hl7.org/7.4.0/CodeSystem-v3-RoleCode.html): [HCPD_Location](StructureDefinition-hcpd-location.md) and [Mobile Healthcare Unit - Sydney CBD](Location-example-healthconnect-mobile-healthcare-unit-1.md)


 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.

