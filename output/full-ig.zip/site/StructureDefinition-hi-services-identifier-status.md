# HI Services Identifier Status - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HI Services Identifier Status**

## Extension: HI Services Identifier Status 

| | |
| :--- | :--- |
| *Official URL*:http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-services-identifier-status | *Version*:26.0.0 |
| Active as of 2026-10-19 | *Computable Name*:HI_Services_Identifier_Status |
| **Copyright/Legal**: Copyright © 2025 Australian Digital Health Agency - All rights reserved. This content is licensed under a Creative Commons Attribution 4.0 International License. See https://creativecommons.org/licenses/by/4.0/. | |

Indicates the status of the Australian Healthcare Services Identifier.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [HCPD Healthcare Provider Identifier (HCPD HPI-I)](StructureDefinition-hcpd-hpii.md), [HCPD Healthcare Provider Identifier - Organisation (HCPD HPI-O)](StructureDefinition-hcpd-hpio.md) and [HCPD Healthcare Support Service Provider - Organisation (HCPD HSP-O)](StructureDefinition-hcpd-hspo.md)
* Examples for this Extension: [Organization/example-healthconnect-organization-1](Organization-example-healthconnect-organization-1.md), [Caring Hands Home Support](Organization-example-healthconnect-organization-2.md), [Practitioner/example-balmain-practitioner-1](Practitioner-example-balmain-practitioner-1.md), [Practitioner/example-healthconnect-practitioner-1](Practitioner-example-healthconnect-practitioner-1.md) and [Practitioner/external-hcpd-practitioner-record](Practitioner-external-hcpd-practitioner-record.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/au.gov.digitalhealth.fhir.hcpd|current/StructureDefinition/StructureDefinition-hi-services-identifier-status.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-hi-services-identifier-status.csv), [Excel](StructureDefinition-hi-services-identifier-status.xlsx), [Schematron](StructureDefinition-hi-services-identifier-status.sch) 

#### Terminology Bindings

#### Constraints

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "hi-services-identifier-status",
  "url" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-services-identifier-status",
  "version" : "26.0.0",
  "name" : "HI_Services_Identifier_Status",
  "title" : "HI Services Identifier Status",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-19T13:36:04+10:00",
  "publisher" : "Australian Digital Health Agency",
  "contact" : [{
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au/"
    },
    {
      "system" : "email",
      "value" : "help@digitalhealth.gov.au"
    }]
  },
  {
    "name" : "Australian Digital Health Agency",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.digitalhealth.gov.au",
      "use" : "work"
    },
    {
      "system" : "email",
      "value" : "mailto:help@digitalhealth.gov.au",
      "use" : "work"
    }]
  }],
  "description" : "Indicates the status of the Australian Healthcare Services Identifier.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "AU",
      "display" : "Australia"
    }]
  }],
  "copyright" : "Copyright © 2025 Australian Digital Health Agency - All rights reserved. This content is licensed under a Creative Commons Attribution 4.0 International License. See https://creativecommons.org/licenses/by/4.0/.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Identifier"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Indicates the status of the Australian Healthcare Services Identifier.",
      "definition" : "The status of the Australian Healthcare Services Identifier at the last date of verification by HI services. Only services with status 'Active' should be displayed & discoverable externally, whereas the record of services with any other status are retained for internal auditing, tracking, reporting & analytics purposes."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-services-identifier-status"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Extension.value[x]:valueCoding",
      "path" : "Extension.value[x]",
      "sliceName" : "valueCoding",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Coding"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://digitalhealth.gov.au/fhir/hcpd/ValueSet/hi-services-identifier-status-vs|26.0.0"
      }
    }]
  }
}

```
