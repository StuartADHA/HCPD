# HCPD Location Example: Virtual Telehealth Service - Health Connect Australia Provider Directory FHIR Implementation Guide v26.0.0

 ![](assets/images/adha-logo-light.svg) 

# Health Connect Australia Provider Directory FHIR Implementation Guide

26.0.0
![](assets/images/aus.svg)

*  [FHIR IGs](https://implementer.digitalhealth.gov.au/fhir-resources) 
*  [Implementer Hub](https://implementer.digitalhealth.gov.au/) 
*  [Agency site](https://www.digitalhealth.gov.au) 

* [**Table of Contents**](toc.md)
* [**FHIR Artefacts**](artifacts.md)
* **HCPD Location Example: Virtual Telehealth Service**

## Example Location: HCPD Location Example: Virtual Telehealth Service

Last updated: 2025-09-01 14:45:30+0000

Profile: [HCPD Location](StructureDefinition-hcpd-location.md)

Virtual Telehealth Service (Virtual) (LSPN: 565656)

-------

| | |
| :--- | :--- |
| Status: | Active |
| Alias: | Ye Old Virtual Telehealth Service |
| Type: | Virtual |
| Contact Detail | * [+61 2 8000 0000](tel:+61280000000)
* [telehealth-support@mockhealth.au](mailto:telehealth-support@mockhealth.au)
* [https://example.com/telehealth.mockservice.au/session/virtual-123](https://example.com/telehealth.mockservice.au/session/virtual-123)
* [https://example.com/telehealth.mockservice/consult](https://example.com/telehealth.mockservice/consult)
 |
| Managed By: | [null (National Organisation Identifier: 8003626566707032)](Organization-example-healthconnect-organization-1.md) |
| Other Ids: | * Organization identifier/c1e61f66-151f-42e2-8c61-7ae40951b5e3
* Resource Identifier/hcpd-SI-4244
 |

 ![](assets/images/adha-logo-light.svg) 

IG © 2026+ [Australian Digital Health Agency](https://www.digitalhealth.gov.au/). Package au.gov.digitalhealth.fhir.hcpd#26.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2026-10-19

Links: [Table of Contents](toc.md) | [QA Report](qa.md) | [Version History](https://fhir.digitalhealth.gov.au/dh/history.html) | [Report an issue or propose a change](mailto:help@digitalhealth.gov.au) 

Publisher: [Australian Digital Health Agency](https://www.digitalhealth.gov.au) | ABN: 84 425 496 912, Level 25, 175 Liverpool Street, Sydney, NSW 2000 | Phone: [1300 901 001](tel:1300901001) | Email: [help@digitalhealth.gov.au](mailto:help@digitalhealth.gov.au) | [https://www.digitalhealth.gov.au](https://www.digitalhealth.gov.au) | [Privacy policy](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/privacy-policy) | [Terms of Use](https://www.digitalhealth.gov.au/about-us/policies-privacy-and-reporting/terms-of-use)

![](cc0.png)
The Australian Digital Health Agency acknowledges the Traditional Custodians of Country throughout Australia, and their continuing connection to land, sea and community. We pay our respects to them and their cultures, and to Elders, past and present.



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "example-healthconnect-virtual-telehealth-service-1",
  "meta" : {
    "lastUpdated" : "2025-09-01T14:45:30Z",
    "profile" : ["http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hcpd-location"]
  },
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org.au/CodeSystem/v2-0203",
        "code" : "LSPN",
        "display" : "Location Specific Practice Number"
      }],
      "text" : "LSPN"
    },
    "system" : "http://ns.electronichealth.net.au/id/location-specific-practice-number",
    "value" : "565656"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "XX",
        "display" : "Organization identifier"
      }]
    },
    "system" : "http://digitalhealth.gov.au/fhir/hcpd/id/hcpd-local-identifier",
    "value" : "c1e61f66-151f-42e2-8c61-7ae40951b5e3"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "RI",
        "display" : "Resource Identifier"
      }]
    },
    "system" : "http://example.org/fhir/identifier/location",
    "value" : "hcpd-SI-4244"
  }],
  "status" : "active",
  "name" : "Virtual Telehealth Service",
  "alias" : ["Ye Old Virtual Telehealth Service"],
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org.au/CodeSystem/location-type",
      "code" : "VI",
      "display" : "Virtual"
    }]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "+61 2 8000 0000",
    "use" : "work"
  },
  {
    "system" : "email",
    "value" : "telehealth-support@mockhealth.au",
    "use" : "work"
  },
  {
    "system" : "url",
    "value" : "https://example.com/telehealth.mockservice.au/session/virtual-123",
    "use" : "work"
  },
  {
    "system" : "url",
    "value" : "https://example.com/telehealth.mockservice/consult",
    "use" : "work"
  }],
  "managingOrganization" : {
    "reference" : "Organization/example-healthconnect-organization-1"
  }
}

```
